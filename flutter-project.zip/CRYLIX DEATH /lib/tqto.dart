// lib/tqto.dart
import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import 'app_theme.dart';

// ═══════════════════════════════════════════════════════════
// TQTO PAGE
// ═══════════════════════════════════════════════════════════
class TqtoPage extends StatelessWidget {
  const TqtoPage({super.key});

  final List<Map<String, String>> contributors = const [
    {
      'name': '4vell',
      'role': 'Developer',
      'avatar': 'https://files.catbox.moe/ha79bo.jpeg',
      'contact': 'https://t.me/MarbelNovaX',
    },
    {
      'name': 'Leonix',
      'role': 'Dev Atreus',
      'avatar': 'https://files.catbox.moe/tdxjmk.jpg',
      'contact': 'https://t.me/YugaxNaspad',
    },
    {
      'name': 'Fathan',
      'role': 'Friends',
      'avatar': 'https://files.catbox.moe/xcb4t7.jpg',
      'contact': 'https://t.me/fathandev',
    },
    {
      'name': 'Stardust',
      'role': 'Support',
      'avatar': 'https://files.catbox.moe/i1mt3r.jpg',
      'contact': 'https://t.me/',
    },
  ];

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<AppPalette>(
      valueListenable: AppTheme.current,
      builder: (context, C, _) {
        return ValueListenableBuilder<ThemeStyle>(
          valueListenable: AppTheme.currentStyle,
          builder: (context, style, __) {
            final isComic = style == ThemeStyle.comic3d;

            return Scaffold(
              backgroundColor: C.bgDeep,
              body: Container(
                decoration: isComic
                    ? BoxDecoration(color: C.bg)
                    : BoxDecoration(
                        gradient: LinearGradient(
                          begin: Alignment.topCenter,
                          end: Alignment.bottomCenter,
                          colors: [C.bg, C.bgDark, C.bgDeep],
                        ),
                      ),
                child: Stack(
                  children: [
                    if (isComic)
                      Positioned.fill(
                        child: IgnorePointer(
                          child: CustomPaint(
                            painter: _ComicHalftonePainter(
                                color: C.primaryLo.withOpacity(0.12)),
                          ),
                        ),
                      ),
                    SafeArea(
                      child: Column(
                        children: [
                          _buildTopBar(context, C, isComic),
                          const SizedBox(height: 4),
                          _buildTitle(C, isComic),
                          const SizedBox(height: 12),
                          _buildStatsBar(C, isComic),
                          const SizedBox(height: 14),
                          Expanded(
                            child: GridView.builder(
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 14, vertical: 4),
                              physics: const BouncingScrollPhysics(),
                              gridDelegate:
                                  const SliverGridDelegateWithFixedCrossAxisCount(
                                crossAxisCount: 2,
                                crossAxisSpacing: 12,
                                mainAxisSpacing: 12,
                                childAspectRatio: 0.82,
                              ),
                              itemCount: contributors.length,
                              itemBuilder: (context, index) {
                                final item = contributors[index];
                                return _ContributorCard(
                                  C: C,
                                  isComic: isComic,
                                  name: item['name']!,
                                  role: item['role']!,
                                  avatarUrl: item['avatar']!,
                                  contactUrl: item['contact']!,
                                  index: index,
                                );
                              },
                            ),
                          ),
                          const SizedBox(height: 8),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            );
          },
        );
      },
    );
  }

  Widget _buildTopBar(
      BuildContext context, AppPalette C, bool isComic) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
      child: Container(
        height: 54,
        decoration: isComic
            ? BoxDecoration(
                color: C.bgDark,
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: Colors.black, width: 4),
                boxShadow: const [
                  BoxShadow(
                    color: Colors.black,
                    offset: Offset(5, 5),
                    blurRadius: 0,
                  ),
                ],
              )
            : BoxDecoration(
                borderRadius: BorderRadius.circular(10),
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [C.bg, C.bgDark],
                ),
                border: Border.all(color: C.textSub, width: 1),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.6),
                    offset: const Offset(0, 3),
                    blurRadius: 6,
                  ),
                ],
              ),
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 10),
          child: Row(
            children: [
              GestureDetector(
                onTap: () => Navigator.pop(context),
                child: Container(
                  width: 36,
                  height: 36,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    gradient: isComic
                        ? null
                        : LinearGradient(
                            colors: [C.textSub, C.bgDark]),
                    color: isComic ? C.accent : null,
                    border: Border.all(
                        color: isComic ? Colors.black : C.textSub,
                        width: isComic ? 3 : 1),
                  ),
                  child: Icon(Icons.arrow_back_ios_new_rounded,
                      color: isComic ? Colors.white : C.accent,
                      size: 14),
                ),
              ),
              const SizedBox(width: 10),
              if (!isComic) _PulseDot(color: C.primaryHi, size: 6),
              if (!isComic) const SizedBox(width: 10),
              Expanded(
                child: Text(
                  'SPECIAL FAMILY',
                  style: TextStyle(
                    color: isComic ? Colors.black : C.accent,
                    fontFamily: isComic ? 'Bangers' : 'Orbitron',
                    fontWeight: FontWeight.w900,
                    fontSize: isComic ? 18 : 13,
                    letterSpacing: isComic ? 2 : 2,
                    shadows: isComic
                        ? null
                        : const [
                            Shadow(
                              color: Colors.black,
                              offset: Offset(0, 1),
                              blurRadius: 2,
                            ),
                          ],
                  ),
                  overflow: TextOverflow.ellipsis,
                ),
              ),
              Container(
                padding: const EdgeInsets.symmetric(
                    horizontal: 9, vertical: 4),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(isComic ? 8 : 5),
                  gradient: isComic
                      ? null
                      : LinearGradient(
                          colors: [C.accentHi, C.primaryLo]),
                  color: isComic ? C.accent : null,
                  border: Border.all(
                      color: isComic ? Colors.black : C.accent,
                      width: isComic ? 2.5 : 1),
                ),
                child: Text(
                  '${contributors.length} MEMBER',
                  style: TextStyle(
                    color: isComic ? Colors.white : C.bgDeep,
                    fontFamily: isComic ? 'Bangers' : 'Orbitron',
                    fontWeight: FontWeight.w900,
                    fontSize: isComic ? 11 : 9,
                    letterSpacing: 1,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildTitle(AppPalette C, bool isComic) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 14),
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 18, horizontal: 20),
        decoration: isComic
            ? BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: Colors.black, width: 4),
                boxShadow: const [
                  BoxShadow(
                    color: Colors.black,
                    offset: Offset(5, 5),
                    blurRadius: 0,
                  ),
                ],
              )
            : BoxDecoration(
                borderRadius: BorderRadius.circular(14),
                gradient: LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [C.bg, C.bgDark],
                ),
                border: Border.all(color: C.textSub, width: 1.2),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.5),
                    offset: const Offset(0, 4),
                    blurRadius: 8,
                  ),
                ],
              ),
        child: Column(
          children: [
            isComic
                ? Text(
                    'THANK YOU',
                    style: TextStyle(
                      color: C.bgDeep,
                      fontSize: 30,
                      fontWeight: FontWeight.w900,
                      fontFamily: 'Bangers',
                      letterSpacing: 4,
                    ),
                  )
                : Stack(
                    alignment: Alignment.center,
                    children: [
                      Transform.translate(
                        offset: const Offset(2, 2),
                        child: Text(
                          'THANK YOU',
                          style: TextStyle(
                            color: Colors.black.withOpacity(0.7),
                            fontSize: 26,
                            fontWeight: FontWeight.w900,
                            fontFamily: 'Orbitron',
                            letterSpacing: 6,
                          ),
                        ),
                      ),
                      Text(
                        'THANK YOU',
                        style: TextStyle(
                          color: C.accent,
                          fontSize: 26,
                          fontWeight: FontWeight.w900,
                          fontFamily: 'Orbitron',
                          letterSpacing: 6,
                          shadows: [
                            Shadow(
                              color: C.accentHi,
                              offset: const Offset(0, -1),
                              blurRadius: 3,
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
            const SizedBox(height: 8),
            Container(
              padding:
                  const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(isComic ? 8 : 3),
                color: isComic
                    ? C.primaryHi
                    : C.primaryLo.withOpacity(0.6),
                border: Border.all(
                  color: isComic ? Colors.black : C.accent.withOpacity(0.7),
                  width: isComic ? 3 : 1,
                ),
              ),
              child: Text(
                'TO ALL CONTRIBUTORS',
                style: TextStyle(
                  color: isComic ? Colors.white : C.accentShine,
                  fontSize: isComic ? 12 : 9,
                  fontFamily: isComic ? 'Bangers' : 'Orbitron',
                  fontWeight: FontWeight.w900,
                  letterSpacing: isComic ? 1.5 : 2,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildStatsBar(AppPalette C, bool isComic) {
    final creatorCount = contributors
        .where((c) =>
            c['role']!.toLowerCase() == 'creator' ||
            c['role']!.toLowerCase() == 'ceo' ||
            c['role']!.toLowerCase() == 'maker')
        .length;
    final supportCount = contributors
        .where((c) => c['role']!.toLowerCase() == 'support')
        .length;

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 14),
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 10),
        decoration: isComic
            ? BoxDecoration(
                color: C.bgDark,
                borderRadius: BorderRadius.circular(14),
                border: Border.all(color: Colors.black, width: 4),
                boxShadow: const [
                  BoxShadow(
                    color: Colors.black,
                    offset: Offset(5, 5),
                    blurRadius: 0,
                  ),
                ],
              )
            : BoxDecoration(
                borderRadius: BorderRadius.circular(12),
                color: C.bgDark,
                border: Border.all(color: C.textSub, width: 1),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.5),
                    offset: const Offset(0, 3),
                    blurRadius: 6,
                  ),
                ],
              ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          children: [
            _statItem(C, isComic,
                Icons.star_rounded,
                '$creatorCount',
                'CREATOR',
                C.accentHi),
            _statItem(C, isComic,
                Icons.support_agent_rounded,
                '$supportCount',
                'SUPPORT',
                C.accent),
            _statItem(C, isComic,
                Icons.favorite_rounded,
                '∞',
                'THANKS',
                C.primaryHi),
          ],
        ),
      ),
    );
  }

  Widget _statItem(AppPalette C, bool isComic, IconData icon,
      String value, String label, Color color) {
    return Column(
      children: [
        Container(
          width: 40,
          height: 40,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: isComic ? color : color.withOpacity(0.15),
            border: Border.all(
              color: isComic ? Colors.black : color.withOpacity(0.5),
              width: isComic ? 3 : 1.2,
            ),
          ),
          child: Icon(icon, color: Colors.white, size: 18),
        ),
        const SizedBox(height: 6),
        Text(
          value,
          style: TextStyle(
            color: isComic ? Colors.white : color,
            fontWeight: FontWeight.w900,
            fontSize: isComic ? 18 : 14,
            fontFamily: isComic ? 'Bangers' : 'Orbitron',
            letterSpacing: 0.8,
          ),
        ),
        const SizedBox(height: 2),
        Text(
          label,
          style: TextStyle(
            color: isComic
                ? Colors.white.withOpacity(0.6)
                : C.text.withOpacity(0.55),
            fontSize: isComic ? 10 : 8,
            fontFamily: isComic ? 'ComicNeue' : 'ShareTechMono',
            letterSpacing: 1,
            fontWeight: FontWeight.w700,
          ),
        ),
      ],
    );
  }
}

// ═══════════════════════════════════════════════════════════
// CONTRIBUTOR CARD
// ═══════════════════════════════════════════════════════════
class _ContributorCard extends StatelessWidget {
  final AppPalette C;
  final bool isComic;
  final String name;
  final String role;
  final String avatarUrl;
  final String contactUrl;
  final int index;

  const _ContributorCard({
    required this.C,
    required this.isComic,
    required this.name,
    required this.role,
    required this.avatarUrl,
    required this.contactUrl,
    required this.index,
  });

  Color _roleColor(String r) {
    switch (r.toLowerCase()) {
      case 'creator':
      case 'maker':
        return C.accentHi;
      case 'ceo':
        return C.accentShine;
      case 'support':
        return C.accent;
      default:
        return C.primaryHi;
    }
  }

  @override
  Widget build(BuildContext context) {
    final roleColor = _roleColor(role);

    if (isComic) {
      return Container(
        decoration: BoxDecoration(
          color: C.bgDark,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: Colors.black, width: 4),
          boxShadow: const [
            BoxShadow(
              color: Colors.black,
              offset: Offset(5, 5),
              blurRadius: 0,
            ),
          ],
        ),
        padding: const EdgeInsets.all(12),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Stack(
              alignment: Alignment.center,
              children: [
                Container(
                  width: 62,
                  height: 62,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: roleColor,
                    border: Border.all(color: Colors.black, width: 4),
                  ),
                ),
                Container(
                  margin: const EdgeInsets.all(4),
                  width: 54,
                  height: 54,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: Colors.white,
                    border: Border.all(color: Colors.black, width: 3),
                  ),
                  child: ClipOval(
                    child: Image.network(
                      avatarUrl,
                      width: 48,
                      height: 48,
                      fit: BoxFit.cover,
                      errorBuilder: (_, __, ___) => Container(
                        color: Colors.white,
                        child: Icon(
                          Icons.person_rounded,
                          color: C.bgDeep,
                          size: 26,
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 10),
            Text(
              name,
              style: TextStyle(
                color: C.text,
                fontWeight: FontWeight.w900,
                fontSize: 16,
                fontFamily: 'Bangers',
                letterSpacing: 1,
                shadows: const [
                  Shadow(
                    color: Colors.black,
                    offset: Offset(1, 1),
                    blurRadius: 0,
                  ),
                ],
              ),
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 4),
            Container(
              padding: const EdgeInsets.symmetric(
                  horizontal: 8, vertical: 2),
              decoration: BoxDecoration(
                color: roleColor,
                borderRadius: BorderRadius.circular(6),
                border: Border.all(color: Colors.black, width: 2),
              ),
              child: Text(
                role.toUpperCase(),
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 10,
                  fontFamily: 'Bangers',
                  fontWeight: FontWeight.w900,
                  letterSpacing: 1,
                ),
              ),
            ),
            const SizedBox(height: 10),
            _ContactButton(
              C: C,
              isComic: true,
              color: roleColor,
              onTap: () async {
                final Uri uri = Uri.parse(contactUrl);
                if (await canLaunchUrl(uri)) {
                  await launchUrl(uri,
                      mode: LaunchMode.externalApplication);
                }
              },
            ),
          ],
        ),
      );
    }

    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(12),
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [C.bg, C.bgDark],
        ),
        border: Border.all(color: C.textSub, width: 1),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.5),
            offset: const Offset(0, 4),
            blurRadius: 8,
          ),
        ],
      ),
      child: Stack(
        children: [
          Padding(
            padding: const EdgeInsets.all(12),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Container(
                  width: 62,
                  height: 62,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    gradient: LinearGradient(
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                      colors: [
                        roleColor.withOpacity(0.7),
                        roleColor.withOpacity(0.3),
                        C.bgDark,
                      ],
                    ),
                    boxShadow: [
                      BoxShadow(
                        color: roleColor.withOpacity(0.4),
                        blurRadius: 12,
                      ),
                      BoxShadow(
                        color: Colors.black.withOpacity(0.7),
                        offset: const Offset(0, 3),
                        blurRadius: 6,
                      ),
                    ],
                  ),
                  child: Container(
                    margin: const EdgeInsets.all(3),
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: C.bgDark,
                      border: Border.all(
                          color: Colors.black.withOpacity(0.5), width: 1),
                    ),
                    child: ClipOval(
                      child: Image.network(
                        avatarUrl,
                        width: 56,
                        height: 56,
                        fit: BoxFit.cover,
                        errorBuilder: (_, __, ___) => Container(
                          width: 56,
                          height: 56,
                          color: C.bgDark,
                          child: Icon(
                            Icons.person_rounded,
                            color: roleColor.withOpacity(0.6),
                            size: 26,
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
                const SizedBox(height: 10),
                Text(
                  name,
                  style: TextStyle(
                    color: C.text,
                    fontWeight: FontWeight.w900,
                    fontSize: 13,
                    fontFamily: 'Orbitron',
                    letterSpacing: 0.5,
                  ),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  textAlign: TextAlign.center,
                ),
                const SizedBox(height: 4),
                Container(
                  padding: const EdgeInsets.symmetric(
                      horizontal: 8, vertical: 2),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(3),
                    color: roleColor.withOpacity(0.2),
                    border: Border.all(
                        color: roleColor.withOpacity(0.6), width: 1),
                  ),
                  child: Text(
                    role.toUpperCase(),
                    style: TextStyle(
                      color: roleColor,
                      fontSize: 8,
                      fontFamily: 'Orbitron',
                      fontWeight: FontWeight.w900,
                      letterSpacing: 1.2,
                    ),
                  ),
                ),
                const SizedBox(height: 10),
                _ContactButton(
                  C: C,
                  isComic: false,
                  color: roleColor,
                  onTap: () async {
                    final Uri uri = Uri.parse(contactUrl);
                    if (await canLaunchUrl(uri)) {
                      await launchUrl(uri,
                          mode: LaunchMode.externalApplication);
                    }
                  },
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════
// CONTACT BUTTON
// ═══════════════════════════════════════════════════════════
class _ContactButton extends StatefulWidget {
  final AppPalette C;
  final bool isComic;
  final Color color;
  final VoidCallback onTap;
  const _ContactButton({
    required this.C,
    required this.isComic,
    required this.color,
    required this.onTap,
  });

  @override
  State<_ContactButton> createState() => _ContactButtonState();
}

class _ContactButtonState extends State<_ContactButton> {
  bool _pressed = false;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTapDown: (_) => setState(() => _pressed = true),
      onTapUp: (_) {
        setState(() => _pressed = false);
        widget.onTap();
      },
      onTapCancel: () => setState(() => _pressed = false),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 80),
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 7),
        transform: widget.isComic
            ? Matrix4.translationValues(
                _pressed ? 3 : 0, _pressed ? 3 : 0, 0)
            : Matrix4.translationValues(
                _pressed ? 1 : 0, _pressed ? 1 : 0, 0),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(widget.isComic ? 10 : 6),
          gradient: widget.isComic
              ? null
              : LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: _pressed
                      ? [
                          widget.color.withOpacity(0.4),
                          widget.color.withOpacity(0.2),
                        ]
                      : [
                          widget.color.withOpacity(0.7),
                          widget.color.withOpacity(0.4),
                        ],
                ),
          color: widget.isComic ? widget.color : null,
          border: Border.all(
            color: widget.isComic
                ? Colors.black
                : widget.color.withOpacity(0.8),
            width: widget.isComic ? 3 : 1.2,
          ),
          boxShadow: _pressed
              ? []
              : (widget.isComic
                  ? const [
                      BoxShadow(
                        color: Colors.black,
                        offset: Offset(3, 3),
                        blurRadius: 0,
                      ),
                    ]
                  : [
                      BoxShadow(
                        color: widget.color.withOpacity(0.3),
                        blurRadius: 6,
                      ),
                    ]),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(
              Icons.chat_rounded,
              color: Colors.white,
              size: widget.isComic ? 14 : 12,
            ),
            const SizedBox(width: 5),
            Text(
              'CONTACT',
              style: TextStyle(
                color: Colors.white,
                fontSize: widget.isComic ? 11 : 9,
                fontWeight: FontWeight.w900,
                fontFamily: widget.isComic ? 'Bangers' : 'Orbitron',
                letterSpacing: 1,
                shadows: widget.isComic
                    ? const [
                        Shadow(
                          color: Colors.black,
                          offset: Offset(1, 1),
                          blurRadius: 0,
                        ),
                      ]
                    : null,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════
// PULSE DOT
// ═══════════════════════════════════════════════════════════
class _PulseDot extends StatefulWidget {
  final Color color;
  final double size;
  const _PulseDot({required this.color, this.size = 8});

  @override
  State<_PulseDot> createState() => _PulseDotState();
}

class _PulseDotState extends State<_PulseDot>
    with SingleTickerProviderStateMixin {
  late AnimationController _c;

  @override
  void initState() {
    super.initState();
    _c = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 900),
    )..repeat(reverse: true);
  }

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _c,
      builder: (_, __) {
        final o = 0.4 + _c.value * 0.6;
        return Container(
          width: widget.size,
          height: widget.size,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            gradient: RadialGradient(
              center: const Alignment(-0.35, -0.35),
              colors: [
                Colors.white.withOpacity(o),
                widget.color.withOpacity(o),
                widget.color.withOpacity(0.5 * o),
              ],
              stops: const [0.0, 0.4, 1.0],
            ),
            boxShadow: [
              BoxShadow(
                color: widget.color.withOpacity(0.8 * o),
                blurRadius: widget.size * 1.5,
                spreadRadius: widget.size * 0.3,
              ),
            ],
          ),
        );
      },
    );
  }
}

// ═══════════════════════════════════════════════════════════
// COMIC HALFTONE PAINTER
// ═══════════════════════════════════════════════════════════
class _ComicHalftonePainter extends CustomPainter {
  final Color color;
  const _ComicHalftonePainter({required this.color});

  @override
  void paint(Canvas canvas, Size size) {
    const spacing = 22.0;
    final paint = Paint()..color = color;
    for (double x = 0; x < size.width + spacing; x += spacing) {
      for (double y = 0; y < size.height + spacing; y += spacing) {
        canvas.drawCircle(Offset(x, y), 2.5, paint);
      }
    }
  }

  @override
  bool shouldRepaint(_ComicHalftonePainter old) => old.color != color;
}