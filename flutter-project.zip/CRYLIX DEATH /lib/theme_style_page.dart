// lib/theme_style_page.dart
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'app_theme.dart';

class ThemeStylePage extends StatelessWidget {
  const ThemeStylePage({super.key});

  @override
  Widget build(BuildContext context) {
    return StyleBuilder(
      builder: (context, C, kit) {
        final isComic = kit.style == ThemeStyle.comic3d;

        return Scaffold(
          backgroundColor: C.bgDeep,
          appBar: AppBar(
            backgroundColor: C.bgDark,
            elevation: 0,
            iconTheme: IconThemeData(color: C.accent),
            title: Text(
              'THEME STYLE',
              style: TextStyle(
                color: isComic ? C.comicText : C.accentHi,
                fontSize: isComic ? 20 : 15,
                fontWeight: FontWeight.w900,
                fontFamily: isComic ? 'Bangers' : 'Orbitron',
                letterSpacing: isComic ? 2 : 3,
                shadows: isComic
                    ? [
                        Shadow(
                          color: C.comicTextOutline,
                          offset: const Offset(2, 2),
                          blurRadius: 0,
                        ),
                      ]
                    : const [
                        Shadow(
                          color: Colors.black,
                          offset: Offset(0, 2),
                          blurRadius: 4,
                        ),
                      ],
              ),
            ),
          ),
          body: Container(
            decoration: BoxDecoration(
              gradient: isComic
                  ? null
                  : LinearGradient(
                      begin: Alignment.topCenter,
                      end: Alignment.bottomCenter,
                      colors: [C.bg, C.bgDark, C.bgDeep],
                    ),
              color: isComic ? C.bg : null,
            ),
            child: ListView(
              padding: const EdgeInsets.all(16),
              children: [
                _buildInfoBanner(C, isComic),
                const SizedBox(height: 16),
                ...ThemeStyleInfo.all.map(
                  (info) => Padding(
                    padding: const EdgeInsets.only(bottom: 14),
                    child: _StyleCard(
                      info: info,
                      isActive: kit.style == info.style,
                      C: C,
                      isComic: isComic,
                      onTap: () async {
                        HapticFeedback.mediumImpact();
                        await AppTheme.setStyle(info.style);
                      },
                    ),
                  ),
                ),
                const SizedBox(height: 20),
                _buildPreview(C, kit.style, isComic),
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _buildInfoBanner(AppPalette C, bool isComic) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: C.bgDark,
        borderRadius: BorderRadius.circular(isComic ? 14 : 12),
        border: Border.all(
          color: isComic ? Colors.black : C.accent.withOpacity(0.4),
          width: isComic ? 3 : 1.5,
        ),
        boxShadow: isComic
            ? const [
                BoxShadow(
                  color: Colors.black,
                  offset: Offset(4, 4),
                  blurRadius: 0,
                ),
              ]
            : null,
      ),
      child: Row(
        children: [
          Icon(Icons.info_outline, color: C.accent, size: 20),
          const SizedBox(width: 12),
          Expanded(
            child: Text(
              'Ganti style visual app. Kombinasikan dengan palette warna di menu Theme.',
              style: TextStyle(
                color: isComic
                    ? C.comicText.withOpacity(0.85)
                    : C.text.withOpacity(0.8),
                fontSize: 11,
                fontFamily: isComic ? 'ComicNeue' : 'ShareTechMono',
                height: 1.5,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildPreview(AppPalette C, ThemeStyle style, bool isComic) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.only(left: 4, bottom: 10),
          child: Text(
            'PREVIEW',
            style: TextStyle(
              color: C.accent,
              fontSize: isComic ? 13 : 11,
              fontWeight: FontWeight.w900,
              fontFamily: isComic ? 'Bangers' : 'Orbitron',
              letterSpacing: isComic ? 1.5 : 2,
            ),
          ),
        ),
        Container(
          padding: const EdgeInsets.all(16),
          decoration: isComic
              ? BoxDecoration(
                  color: C.bgDark,
                  borderRadius: BorderRadius.circular(18),
                  border: Border.all(color: Colors.black, width: 4),
                  boxShadow: const [
                    BoxShadow(
                      color: Colors.black,
                      offset: Offset(6, 6),
                      blurRadius: 0,
                    ),
                  ],
                )
              : BoxDecoration(
                  borderRadius: BorderRadius.circular(14),
                  gradient: LinearGradient(
                    colors: [C.bg, C.bgDark, C.bgDeep],
                  ),
                  border: Border.all(
                      color: C.accent.withOpacity(0.5), width: 1.5),
                  boxShadow: [
                    BoxShadow(
                      color: C.accent.withOpacity(0.2),
                      blurRadius: 20,
                    ),
                  ],
                ),
          child: Column(
            children: [
              Text(
                'CONTOH TAMPILAN',
                style: TextStyle(
                  color: isComic ? C.comicText : C.text,
                  fontSize: isComic ? 18 : 16,
                  fontWeight: FontWeight.w900,
                  fontFamily: isComic ? 'Bangers' : 'Orbitron',
                  letterSpacing: isComic ? 1 : 3,
                  shadows: isComic
                      ? [
                          Shadow(
                            color: C.comicTextOutline,
                            offset: const Offset(2, 2),
                            blurRadius: 0,
                          ),
                        ]
                      : const [
                          Shadow(
                            color: Colors.black,
                            offset: Offset(0, 2),
                            blurRadius: 4,
                          ),
                        ],
                ),
              ),
              const SizedBox(height: 14),
              Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
                decoration: isComic
                    ? BoxDecoration(
                        color: C.primaryHi,
                        borderRadius: BorderRadius.circular(14),
                        border: Border.all(color: Colors.black, width: 3),
                        boxShadow: const [
                          BoxShadow(
                            color: Colors.black,
                            offset: Offset(3, 3),
                            blurRadius: 0,
                          ),
                        ],
                      )
                    : BoxDecoration(
                        borderRadius: BorderRadius.circular(10),
                        gradient: LinearGradient(
                          colors: [C.primaryHi, C.primary],
                        ),
                        boxShadow: [
                          BoxShadow(
                            color: C.primaryHi.withOpacity(0.5),
                            blurRadius: 15,
                          ),
                        ],
                      ),
                child: Text(
                  'TOMBOL',
                  style: TextStyle(
                    color: isComic
                        ? C.contrastTextOn(C.primaryHi)
                        : Colors.white,
                    fontSize: isComic ? 15 : 13,
                    fontWeight: FontWeight.w900,
                    fontFamily: isComic ? 'Bangers' : 'Orbitron',
                    letterSpacing: isComic ? 1 : 2,
                    shadows: isComic
                        ? [
                            Shadow(
                              color: C.contrastTextOn(C.primaryHi) ==
                                      Colors.white
                                  ? Colors.black
                                  : Colors.white,
                              offset: const Offset(1, 1),
                              blurRadius: 0,
                            ),
                          ]
                        : null,
                  ),
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}

// ═══════════════════════════════════════════════════════════
// STYLE CARD
// ═══════════════════════════════════════════════════════════
class _StyleCard extends StatelessWidget {
  final ThemeStyleInfo info;
  final bool isActive;
  final AppPalette C;
  final bool isComic;
  final VoidCallback onTap;

  const _StyleCard({
    required this.info,
    required this.isActive,
    required this.C,
    required this.isComic,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final previewComic = info.style == ThemeStyle.comic3d;

    final cardColor = previewComic
        ? (isActive ? C.primaryHi : C.bgDark)
        : null;
    final textColor = previewComic
        ? (isActive ? C.contrastTextOn(C.primaryHi) : C.comicText)
        : (isActive ? Colors.white : C.text);
    final descColor = previewComic
        ? (isActive
            ? C.contrastTextOn(C.primaryHi).withOpacity(0.75)
            : C.comicTextSub)
        : C.text.withOpacity(0.7);

    return GestureDetector(
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        padding: const EdgeInsets.all(16),
        decoration: previewComic
            ? BoxDecoration(
                color: cardColor,
                borderRadius: BorderRadius.circular(18),
                border: Border.all(color: Colors.black, width: 4),
                boxShadow: const [
                  BoxShadow(
                    color: Colors.black,
                    offset: Offset(5, 5),
                    blurRadius: 0,
                  ),
                ],
              )
            : BoxDecoration(
                borderRadius: BorderRadius.circular(14),
                gradient: LinearGradient(
                  colors: isActive
                      ? [C.primaryHi, C.primary]
                      : [C.bg, C.bgDark, C.bgDeep],
                ),
                border: Border.all(
                  color: isActive
                      ? C.accent
                      : C.primaryLo.withOpacity(0.5),
                  width: isActive ? 2 : 1,
                ),
                boxShadow: isActive
                    ? [
                        BoxShadow(
                          color: C.primaryHi.withOpacity(0.4),
                          blurRadius: 20,
                        ),
                      ]
                    : null,
              ),
        child: Row(
          children: [
            Container(
              width: 52,
              height: 52,
              decoration: previewComic
                  ? BoxDecoration(
                      color: isActive
                          ? C.contrastTextOn(C.primaryHi)
                          : C.primaryHi,
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(color: Colors.black, width: 3),
                    )
                  : BoxDecoration(
                      shape: BoxShape.circle,
                      gradient: RadialGradient(
                        colors: [
                          (isActive ? C.accent : C.primaryHi)
                              .withOpacity(0.4),
                          (isActive ? C.accent : C.primaryHi)
                              .withOpacity(0.1),
                        ],
                      ),
                      border: Border.all(
                        color: isActive
                            ? C.accent
                            : C.primaryHi.withOpacity(0.5),
                        width: 2,
                      ),
                      boxShadow: [
                        BoxShadow(
                          color: (isActive ? C.accent : C.primaryHi)
                              .withOpacity(0.4),
                          blurRadius: 12,
                        ),
                      ],
                    ),
              child: Icon(
                info.icon,
                color: previewComic
                    ? (isActive
                        ? C.contrastTextOn(C.contrastTextOn(C.primaryHi))
                        : C.contrastTextOn(C.primaryHi))
                    : (isActive ? C.accentShine : C.text),
                size: 26,
              ),
            ),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Flexible(
                        child: Text(
                          info.name,
                          style: TextStyle(
                            color: textColor,
                            fontSize: previewComic ? 17 : 15,
                            fontWeight: FontWeight.w900,
                            fontFamily:
                                previewComic ? 'Bangers' : 'Orbitron',
                            letterSpacing: previewComic ? 1 : 2,
                            shadows: previewComic
                                ? [
                                    Shadow(
                                      color: textColor == Colors.white
                                          ? Colors.black
                                          : Colors.white,
                                      offset: const Offset(1, 1),
                                      blurRadius: 0,
                                    ),
                                  ]
                                : null,
                          ),
                        ),
                      ),
                      if (isActive) ...[
                        const SizedBox(width: 8),
                        Icon(
                          Icons.check_circle_rounded,
                          color: previewComic
                              ? textColor
                              : Colors.white,
                          size: 18,
                        ),
                      ],
                    ],
                  ),
                  const SizedBox(height: 4),
                  Text(
                    info.description,
                    style: TextStyle(
                      color: descColor,
                      fontSize: 10,
                      fontFamily:
                          previewComic ? 'ComicNeue' : 'ShareTechMono',
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}