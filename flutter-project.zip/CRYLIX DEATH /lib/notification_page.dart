// lib/notification_page.dart
import 'dart:convert';
import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'package:url_launcher/url_launcher.dart';
import 'app_theme.dart';
import 'api_config.dart';

// ═══════════════════════════════════════════════════════════
// GLOBAL PULSE
// ═══════════════════════════════════════════════════════════
class _Pulse {
  static final ValueNotifier<double> v = ValueNotifier<double>(0);
  static bool _started = false;
  static void ensureStarted() {
    if (_started) return;
    _started = true;
    _run();
  }
  static Future<void> _run() async {
    final sw = Stopwatch()..start();
    while (true) {
      await Future<void>.delayed(const Duration(milliseconds: 80));
      final t = (sw.elapsedMilliseconds % 1600) / 1600.0;
      v.value = t < 0.5 ? t * 2 : (1 - t) * 2;
    }
  }
}

class _Led extends StatelessWidget {
  final Color color;
  final double size;
  final bool blink;
  const _Led({required this.color, this.size = 8, this.blink = false});

  @override
  Widget build(BuildContext context) {
    final isComic = AppTheme.currentStyle.value == ThemeStyle.comic3d;
    if (isComic) {
      return Container(
        width: size,
        height: size,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          color: color,
          border: Border.all(color: Colors.black, width: size * 0.18),
        ),
      );
    }
    if (!blink) return _dot(1.0);
    return ValueListenableBuilder<double>(
      valueListenable: _Pulse.v,
      builder: (_, v, __) => _dot(0.45 + v * 0.55),
    );
  }

  Widget _dot(double opacity) => Container(
        width: size, height: size,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          gradient: RadialGradient(
            center: const Alignment(-0.35, -0.35),
            colors: [
              Colors.white.withOpacity(0.85 * opacity),
              color.withOpacity(opacity),
              color.withOpacity(0.55 * opacity),
            ],
            stops: const [0.0, 0.4, 1.0],
          ),
          border: Border.all(color: Colors.black.withOpacity(0.85),
              width: size * 0.1),
          boxShadow: [
            BoxShadow(color: color.withOpacity(0.75 * opacity),
                blurRadius: size * 1.4, spreadRadius: size * 0.2),
            BoxShadow(color: color.withOpacity(0.35 * opacity),
                blurRadius: size * 2.6, spreadRadius: size * 0.4),
          ],
        ),
      );
}

class _Screw extends StatelessWidget {
  final AppPalette C;
  final double size;
  const _Screw({required this.C, this.size = 14});
  @override
  Widget build(BuildContext context) {
    if (AppTheme.currentStyle.value == ThemeStyle.comic3d) {
      return const SizedBox.shrink();
    }
    return Container(
      width: size, height: size,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        gradient: RadialGradient(
          center: const Alignment(-0.35, -0.35),
          colors: [C.text, C.textSub, C.bg, C.bgDark],
          stops: const [0.0, 0.35, 0.7, 1.0],
        ),
      ),
      child: Center(
        child: Transform.rotate(
          angle: 0.785,
          child: Container(
            width: size * 0.7, height: size * 0.11,
            color: Colors.black.withOpacity(0.9),
          ),
        ),
      ),
    );
  }
}

class _Rivet extends StatelessWidget {
  final AppPalette C;
  final double size;
  const _Rivet({required this.C, this.size = 10});
  @override
  Widget build(BuildContext context) {
    if (AppTheme.currentStyle.value == ThemeStyle.comic3d) {
      return const SizedBox.shrink();
    }
    return Container(
      width: size, height: size,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        gradient: RadialGradient(
          center: const Alignment(-0.35, -0.35),
          colors: [C.accentShine, C.accentHi, C.accent, C.primaryLo],
          stops: const [0.0, 0.3, 0.65, 1.0],
        ),
      ),
    );
  }
}

class _MetalPlate extends StatelessWidget {
  final AppPalette C;
  final Widget child;
  final EdgeInsets padding;
  final double radius;
  const _MetalPlate({
    required this.C,
    required this.child,
    this.padding = const EdgeInsets.all(16),
    this.radius = 16,
  });

  @override
  Widget build(BuildContext context) {
    final isComic = AppTheme.currentStyle.value == ThemeStyle.comic3d;
    if (isComic) {
      return Container(
        padding: padding,
        decoration: BoxDecoration(
          color: C.bgDark,
          borderRadius: BorderRadius.circular(radius + 4),
          border: Border.all(color: Colors.black, width: 4),
          boxShadow: const [
            BoxShadow(color: Colors.black, offset: Offset(6, 6),
                blurRadius: 0),
          ],
        ),
        child: child,
      );
    }
    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(radius),
        gradient: LinearGradient(
          begin: Alignment.topLeft, end: Alignment.bottomRight,
          colors: [C.text, C.bg, C.bgDark, C.bgDeep],
          stops: const [0.0, 0.4, 0.7, 1.0],
        ),
        boxShadow: [
          BoxShadow(color: Colors.black.withOpacity(0.75),
              offset: const Offset(0, 6), blurRadius: 12),
        ],
      ),
      padding: const EdgeInsets.all(3),
      child: Container(
        padding: padding,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(radius - 3),
          gradient: LinearGradient(
            begin: Alignment.topCenter, end: Alignment.bottomCenter,
            colors: [C.bg, C.bgDark, C.bgDeep],
          ),
          border: Border.all(color: Colors.black.withOpacity(0.5)),
        ),
        child: child,
      ),
    );
  }
}

class _IndustrialButton extends StatefulWidget {
  final AppPalette C;
  final Widget child;
  final VoidCallback? onTap;
  final Color color;
  final double height;
  const _IndustrialButton({
    required this.C,
    required this.child,
    required this.onTap,
    required this.color,
    this.height = 56,
  });

  @override
  State<_IndustrialButton> createState() => _IndustrialButtonState();
}

class _IndustrialButtonState extends State<_IndustrialButton> {
  bool _pressed = false;

  @override
  Widget build(BuildContext context) {
    final C = widget.C;
    final enabled = widget.onTap != null;
    final isComic = AppTheme.currentStyle.value == ThemeStyle.comic3d;
    final light = _lighten(widget.color);
    final dark = _darken(widget.color);

    return GestureDetector(
      onTapDown: enabled ? (_) => setState(() => _pressed = true) : null,
      onTapUp: enabled
          ? (_) {
              setState(() => _pressed = false);
              HapticFeedback.mediumImpact();
              widget.onTap?.call();
            }
          : null,
      onTapCancel: enabled ? () => setState(() => _pressed = false) : null,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 80),
        height: widget.height,
        transform: isComic
            ? Matrix4.translationValues(_pressed ? 4 : 0, _pressed ? 4 : 0, 0)
            : null,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(isComic ? 12 : 12),
          gradient: isComic
              ? null
              : LinearGradient(
                  begin: _pressed ? Alignment.bottomCenter : Alignment.topCenter,
                  end: _pressed ? Alignment.topCenter : Alignment.bottomCenter,
                  colors: _pressed ? [dark, dark, widget.color]
                      : [light, widget.color, dark],
                  stops: const [0.0, 0.5, 1.0],
                ),
          color: isComic ? widget.color : null,
          border: Border.all(
            color: isComic ? Colors.black : dark.withOpacity(0.9),
            width: isComic ? 3.5 : 1.5,
          ),
          boxShadow: isComic
              ? (_pressed ? [] : const [
                  BoxShadow(color: Colors.black, offset: Offset(4, 4),
                      blurRadius: 0),
                ])
              : (_pressed
                  ? [BoxShadow(color: Colors.black.withOpacity(0.9),
                      offset: const Offset(0, 1), blurRadius: 3)]
                  : [
                      BoxShadow(color: widget.color.withOpacity(0.45),
                          offset: const Offset(0, 5), blurRadius: 10,
                          spreadRadius: -2),
                      BoxShadow(color: Colors.black.withOpacity(0.75),
                          offset: const Offset(0, 4), blurRadius: 6),
                    ]),
        ),
        child: Stack(
          alignment: Alignment.center,
          children: [
            if (!isComic) ...[
              Positioned(top: 5, left: 5, child: _Rivet(C: C, size: 6)),
              Positioned(top: 5, right: 5, child: _Rivet(C: C, size: 6)),
              Positioned(bottom: 5, left: 5, child: _Rivet(C: C, size: 6)),
              Positioned(bottom: 5, right: 5, child: _Rivet(C: C, size: 6)),
            ],
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20),
              child: Opacity(opacity: enabled ? 1 : 0.5, child: widget.child),
            ),
          ],
        ),
      ),
    );
  }

  static Color _lighten(Color c) => Color.fromARGB(c.alpha,
      (c.red + 40).clamp(0, 255),
      (c.green + 40).clamp(0, 255),
      (c.blue + 30).clamp(0, 255));
  static Color _darken(Color c) => Color.fromARGB(c.alpha,
      (c.red - 60).clamp(0, 255),
      (c.green - 50).clamp(0, 255),
      (c.blue - 40).clamp(0, 255));
}

// ═══════════════════════════════════════════════════════════
// NOTIFICATION PAGE
// ═══════════════════════════════════════════════════════════
class NotificationPage extends StatefulWidget {
  final String sessionKey;
  final String username;
  final String role;

  const NotificationPage({
    Key? key,
    required this.sessionKey,
    required this.username,
    required this.role,
  }) : super(key: key);

  @override
  State<NotificationPage> createState() => _NotificationPageState();
}

class _NotificationPageState extends State<NotificationPage> {
  final TextEditingController _messageController = TextEditingController();
  bool _isLoading = false;

  @override
  void initState() {
    super.initState();
    _Pulse.ensureStarted();
  }

  @override
  void dispose() {
    _messageController.dispose();
    super.dispose();
  }

  Future<void> _sendReport(AppPalette C, bool isComic) async {
    final message = _messageController.text.trim();
    if (message.isEmpty) {
      _showSkeuoSnack(C, isComic, 'Harap isi pesan laporan', isError: true);
      return;
    }

    setState(() => _isLoading = true);

    try {
      final response = await http
          .post(
            Uri.parse('$baseUrl/sendReport'),
            headers: {'Content-Type': 'application/json'},
            body: jsonEncode({
              'key': widget.sessionKey,
              'username': widget.username,
              'message': message,
            }),
          )
          .timeout(const Duration(seconds: 20));

      final data = jsonDecode(response.body);
      if (response.statusCode == 200 && data['success'] == true) {
        _showSkeuoSnack(C, isComic, 'Laporan berhasil dikirim ke owner!',
            isError: false);
        _messageController.clear();
        _showSuccessDialog(C, isComic);
      } else {
        _showSkeuoSnack(C, isComic,
            'Gagal: ${data['message'] ?? 'Unknown error'}', isError: true);
      }
    } catch (e) {
      _showSkeuoSnack(C, isComic,
          'Server tidak merespon, membuka Telegram...', isError: false);
      _openTelegramChat(C, isComic);
    } finally {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  Future<void> _openTelegramChat(AppPalette C, bool isComic) async {
    const ownerUsername = 'elltzyy1_md';
    final url = 'https://t.me/$ownerUsername';
    if (await canLaunchUrl(Uri.parse(url))) {
      await launchUrl(Uri.parse(url), mode: LaunchMode.externalApplication);
    } else {
      _showSkeuoSnack(C, isComic, 'Tidak dapat membuka Telegram',
          isError: true);
    }
  }

  void _showSkeuoSnack(AppPalette C, bool isComic, String message,
      {bool isError = false}) {
    final c = isError ? C.primaryHi : C.primaryHi;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Row(
          children: [
            _Led(color: c, size: 8, blink: !isComic),
            const SizedBox(width: 12),
            Expanded(
              child: Text(
                message,
                style: TextStyle(
                  color: C.text,
                  fontSize: 12,
                  fontWeight: FontWeight.w700,
                  fontFamily: isComic ? 'ComicNeue' : 'ShareTechMono',
                  letterSpacing: 0.3,
                ),
              ),
            ),
          ],
        ),
        backgroundColor: C.bgDark,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(isComic ? 12 : 8),
          side: BorderSide(
              color: isComic ? Colors.black : c,
              width: isComic ? 3 : 1.5),
        ),
        margin: const EdgeInsets.all(16),
        duration: const Duration(seconds: 3),
      ),
    );
  }

  void _showSuccessDialog(AppPalette C, bool isComic) {
    showDialog(
      context: context,
      barrierColor: Colors.black.withOpacity(0.85),
      builder: (ctx) => Dialog(
        backgroundColor: Colors.transparent,
        insetPadding: const EdgeInsets.all(24),
        child: isComic
            ? Container(
                decoration: BoxDecoration(
                  color: C.bgDark,
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(color: Colors.black, width: 4),
                  boxShadow: const [
                    BoxShadow(
                      color: Colors.black,
                      offset: Offset(6, 6),
                      blurRadius: 0,
                    ),
                  ],
                ),
                padding: const EdgeInsets.all(24),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Container(
                      width: 70, height: 70,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: C.primaryHi,
                        border: Border.all(color: Colors.black, width: 4),
                      ),
                      child: const Icon(Icons.check_rounded,
                          color: Colors.white, size: 36),
                    ),
                    const SizedBox(height: 18),
                    const Text('LAPORAN TERKIRIM',
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          color: Colors.black,
                          fontFamily: 'Bangers',
                          fontSize: 22,
                          letterSpacing: 2,
                        )),
                    const SizedBox(height: 10),
                    Text('Pesan Anda telah diteruskan ke owner.',
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          color: C.text,
                          fontFamily: 'ComicNeue',
                          fontSize: 13,
                          height: 1.5,
                        )),
                    const SizedBox(height: 20),
                    _IndustrialButton(
                      C: C,
                      color: C.primaryHi,
                      height: 50,
                      onTap: () => Navigator.pop(ctx),
                      child: const Text('OK',
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 18,
                            fontWeight: FontWeight.w900,
                            fontFamily: 'Bangers',
                            letterSpacing: 2,
                            shadows: [
                              Shadow(color: Colors.black,
                                  offset: Offset(1, 1), blurRadius: 0),
                            ],
                          )),
                    ),
                  ],
                ),
              )
            : _MetalPlate(
                C: C,
                padding: const EdgeInsets.all(24),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Stack(
                      alignment: Alignment.center,
                      children: [
                        Container(
                          width: 60, height: 60,
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            gradient: RadialGradient(
                                colors: [C.text, C.bg, C.bgDark]),
                            border: Border.all(color: C.primaryHi, width: 2.5),
                          ),
                          child: Icon(Icons.check_rounded,
                              color: C.primaryHi, size: 30),
                        ),
                        Positioned(top: -2, right: -2,
                            child: _Led(color: C.primaryHi, size: 8,
                                blink: true)),
                      ],
                    ),
                    const SizedBox(height: 18),
                    Text('LAPORAN TERKIRIM',
                        style: TextStyle(
                          color: C.accent, fontSize: 15,
                          fontWeight: FontWeight.w900,
                          fontFamily: 'Orbitron', letterSpacing: 2.5)),
                    const SizedBox(height: 10),
                    Text('Pesan Anda telah diteruskan ke owner.',
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          color: C.text.withOpacity(0.75), fontSize: 11,
                          fontFamily: 'ShareTechMono', height: 1.5)),
                    const SizedBox(height: 20),
                    _IndustrialButton(
                      C: C, color: C.primaryHi, height: 46,
                      onTap: () => Navigator.pop(ctx),
                      child: const Text('OK',
                          style: TextStyle(
                            color: Colors.white, fontSize: 13,
                            fontWeight: FontWeight.w900,
                            fontFamily: 'Orbitron', letterSpacing: 2.5)),
                    ),
                  ],
                ),
              ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<AppPalette>(
      valueListenable: AppTheme.current,
      builder: (context, C, _) {
        return ValueListenableBuilder<ThemeStyle>(
          valueListenable: AppTheme.currentStyle,
          builder: (context, style, __) {
            final isComic = style == ThemeStyle.comic3d;

            return Scaffold(
              backgroundColor: C.bgDeep,
              body: Container(
                decoration: isComic
                    ? BoxDecoration(color: C.bg)
                    : BoxDecoration(
                        gradient: RadialGradient(
                          center: const Alignment(-0.3, -0.3),
                          radius: 1.2,
                          colors: [C.bg, C.bgDark, C.bgDeep],
                          stops: const [0.0, 0.6, 1.0],
                        ),
                      ),
                child: Stack(
                  children: [
                    if (isComic)
                      Positioned.fill(
                        child: IgnorePointer(
                          child: CustomPaint(
                            painter: _ComicHalftonePainter(
                                color: C.primaryLo.withOpacity(0.12)),
                          ),
                        ),
                      ),
                    SafeArea(
                      child: Column(
                        children: [
                          const SizedBox(height: 8),
                          _buildAppBar(C, isComic),
                          const SizedBox(height: 12),
                          Expanded(
                            child: SingleChildScrollView(
                              physics: const BouncingScrollPhysics(),
                              padding:
                                  const EdgeInsets.symmetric(horizontal: 14),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  _buildHeaderPanel(C, isComic),
                                  const SizedBox(height: 14),
                                  _buildFormPlate(C, isComic),
                                  const SizedBox(height: 14),
                                  _buildInfoPlate(C, isComic),
                                  const SizedBox(height: 30),
                                ],
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            );
          },
        );
      },
    );
  }

  Widget _buildAppBar(AppPalette C, bool isComic) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 12),
      child: Container(
        decoration: isComic
            ? BoxDecoration(
                color: C.bgDark,
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: Colors.black, width: 4),
                boxShadow: const [
                  BoxShadow(color: Colors.black, offset: Offset(5, 5),
                      blurRadius: 0),
                ],
              )
            : null,
        child: _MetalPlate(
          C: C,
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
          child: Row(
            children: [
              GestureDetector(
                onTap: () {
                  HapticFeedback.lightImpact();
                  Navigator.pop(context);
                },
                child: Container(
                  width: 40, height: 40,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(10),
                    gradient: isComic
                        ? null
                        : LinearGradient(
                            begin: Alignment.topCenter,
                            end: Alignment.bottomCenter,
                            colors: [C.textSub, C.bg, C.bgDark]),
                    color: isComic ? C.accent : null,
                    border: Border.all(
                        color: isComic ? Colors.black
                            : Colors.black.withOpacity(0.7),
                        width: isComic ? 3 : 1.2),
                  ),
                  child: Icon(Icons.arrow_back_ios_new_rounded,
                      color: isComic ? Colors.white : C.accent, size: 16),
                ),
              ),
              const SizedBox(width: 12),
              Stack(
                alignment: Alignment.center,
                children: [
                  Container(
                    width: 40, height: 40,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      gradient: isComic ? null
                          : RadialGradient(colors: [C.text, C.bg, C.bgDark]),
                      color: isComic ? C.primaryHi : null,
                      border: Border.all(
                          color: isComic ? Colors.black : C.primaryHi,
                          width: isComic ? 3 : 2),
                    ),
                    child: Icon(Icons.notifications_active_rounded,
                        color: isComic ? Colors.white : C.primaryHi, size: 20),
                  ),
                  if (!isComic)
                    Positioned(top: -2, right: -2,
                        child: _Led(color: C.primaryHi, size: 6, blink: true)),
                ],
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('NULL TR4SHER LAPORAN',
                        style: TextStyle(
                          color: isComic ? Colors.black : C.accentHi,
                          fontSize: isComic ? 16 : 13,
                          fontWeight: FontWeight.w900,
                          fontFamily: isComic ? 'Bangers' : 'Orbitron',
                          letterSpacing: isComic ? 1.5 : 2,
                          height: 1,
                          shadows: isComic ? null : [
                            Shadow(color: C.primaryLo,
                                offset: const Offset(0, 1), blurRadius: 1),
                            const Shadow(color: Colors.black,
                                offset: Offset(0, 2), blurRadius: 3),
                          ],
                        )),
                    const SizedBox(height: 3),
                    Row(
                      children: [
                        _Led(color: C.primaryHi, size: 4, blink: !isComic),
                        const SizedBox(width: 5),
                        Text('SEND TO OWNER',
                            style: TextStyle(
                              color: isComic
                                  ? Colors.black.withOpacity(0.5)
                                  : C.text.withOpacity(0.55),
                              fontSize: 8,
                              fontWeight: FontWeight.w700,
                              fontFamily:
                                  isComic ? 'ComicNeue' : 'ShareTechMono',
                              letterSpacing: 1.2)),
                      ],
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildHeaderPanel(AppPalette C, bool isComic) {
    return _MetalPlate(
      C: C,
      padding: const EdgeInsets.all(14),
      child: Row(
        children: [
          Stack(
            alignment: Alignment.center,
            children: [
              Container(
                width: 54, height: 54,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: isComic ? null
                      : RadialGradient(
                          center: const Alignment(-0.35, -0.35),
                          colors: [
                            C.primaryHi.withOpacity(0.5),
                            C.primaryHi.withOpacity(0.15),
                            Colors.black.withOpacity(0.9),
                          ],
                          stops: const [0.0, 0.5, 1.0]),
                  color: isComic ? C.primaryHi : null,
                  border: Border.all(
                      color: isComic ? Colors.black
                          : C.primaryHi.withOpacity(0.6),
                      width: isComic ? 4 : 2),
                ),
                child: Icon(Icons.campaign_rounded,
                    color: isComic ? Colors.white : C.primaryHi, size: 26),
              ),
              if (!isComic)
                Positioned(top: 0, right: 0,
                    child: _Led(color: C.accent, size: 7, blink: true)),
            ],
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('BUAT LAPORAN',
                    style: TextStyle(
                      color: isComic ? Colors.black : C.accent,
                      fontSize: isComic ? 20 : 16,
                      fontWeight: FontWeight.w900,
                      fontFamily: isComic ? 'Bangers' : 'Orbitron',
                      letterSpacing: isComic ? 1.5 : 2,
                      height: 1)),
                const SizedBox(height: 4),
                Text('Kirim pesan langsung ke owner',
                    style: TextStyle(
                      color: isComic
                          ? Colors.black.withOpacity(0.6)
                          : C.text.withOpacity(0.6),
                      fontSize: 10,
                      fontFamily: isComic ? 'ComicNeue' : 'ShareTechMono',
                      letterSpacing: 0.5)),
              ],
            ),
          ),
          if (!isComic) _Led(color: C.primaryHi, size: 8, blink: true),
        ],
      ),
    );
  }

  Widget _buildFormPlate(AppPalette C, bool isComic) {
    return _MetalPlate(
      C: C,
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              if (!isComic) _Screw(C: C, size: 12),
              if (!isComic) const SizedBox(width: 10),
              Expanded(
                child: Center(
                  child: Text('FORM LAPORAN',
                      style: TextStyle(
                        color: isComic ? Colors.black : C.accent,
                        fontSize: isComic ? 16 : 11,
                        fontWeight: FontWeight.w900,
                        fontFamily: isComic ? 'Bangers' : 'Orbitron',
                        letterSpacing: 2)),
                ),
              ),
              if (!isComic) const SizedBox(width: 10),
              if (!isComic) _Screw(C: C, size: 12),
            ],
          ),
          const SizedBox(height: 16),
          Row(
            children: [
              if (!isComic) _Rivet(C: C, size: 6),
              if (!isComic) const SizedBox(width: 6),
              Icon(Icons.edit_note_rounded,
                  color: isComic ? Colors.black : C.accent, size: 14),
              const SizedBox(width: 6),
              Text('PESAN LAPORAN',
                  style: TextStyle(
                    color: isComic ? Colors.black : C.accent,
                    fontSize: isComic ? 13 : 9,
                    fontWeight: FontWeight.w900,
                    fontFamily: isComic ? 'Bangers' : 'Orbitron',
                    letterSpacing: 1.5)),
            ],
          ),
          const SizedBox(height: 8),
          Container(
            decoration: isComic
                ? BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: Colors.black, width: 3),
                  )
                : BoxDecoration(
                    borderRadius: BorderRadius.circular(10),
                    gradient: LinearGradient(
                      begin: Alignment.topCenter,
                      end: Alignment.bottomCenter,
                      colors: [C.bgDeep, C.bgDark]),
                    border: Border.all(color: C.bgDark, width: 1.5),
                  ),
            child: TextField(
              controller: _messageController,
              maxLines: 6,
              minLines: 5,
              style: TextStyle(
                color: isComic ? Colors.black : C.accentShine,
                fontSize: 13,
                fontWeight: FontWeight.w600,
                fontFamily: isComic ? 'ComicNeue' : 'ShareTechMono',
                letterSpacing: 0.3,
                height: 1.5),
              cursorColor: isComic ? Colors.black : C.primaryHi,
              onChanged: (_) => setState(() {}),
              decoration: InputDecoration(
                hintText: 'Tuliskan laporan atau keluhan Anda...',
                hintStyle: TextStyle(
                  color: isComic
                      ? Colors.black.withOpacity(0.4)
                      : C.text.withOpacity(0.3),
                  fontSize: 12,
                  fontFamily: isComic ? 'ComicNeue' : 'ShareTechMono',
                  letterSpacing: 0.5),
                border: InputBorder.none,
                contentPadding: const EdgeInsets.all(14),
              ),
            ),
          ),
          const SizedBox(height: 12),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(isComic ? 10 : 8),
              color: isComic ? Colors.white : Colors.black.withOpacity(0.5),
              border: Border.all(
                  color: isComic ? Colors.black : C.bgDark,
                  width: isComic ? 3 : 1),
            ),
            child: Row(
              children: [
                _Led(color: C.primaryHi, size: 6, blink: !isComic),
                const SizedBox(width: 8),
                Expanded(
                  child: Text(
                    'Dikirim sebagai: ${widget.username} (${widget.role})',
                    style: TextStyle(
                      color: isComic
                          ? Colors.black.withOpacity(0.7)
                          : C.text.withOpacity(0.7),
                      fontSize: 10,
                      fontFamily:
                          isComic ? 'ComicNeue' : 'ShareTechMono',
                      letterSpacing: 0.5),
                    overflow: TextOverflow.ellipsis,
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 16),
          _IndustrialButton(
            C: C,
            color: _isLoading ? C.bg : C.primary,
            height: 54,
            onTap: _isLoading ? null : () => _sendReport(C, isComic),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                if (_isLoading)
                  SizedBox(
                    width: 18, height: 18,
                    child: CircularProgressIndicator(
                      strokeWidth: 2.5,
                      valueColor:
                          AlwaysStoppedAnimation<Color>(C.accent)),
                  )
                else
                  const Icon(Icons.send_rounded,
                      color: Colors.white, size: 18),
                const SizedBox(width: 10),
                Text(
                  _isLoading ? 'MENGIRIM...' : 'KIRIM LAPORAN',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: isComic ? 17 : 13,
                    fontWeight: FontWeight.w900,
                    fontFamily: isComic ? 'Bangers' : 'Orbitron',
                    letterSpacing: isComic ? 1.5 : 2,
                    shadows: const [
                      Shadow(color: Colors.black54,
                          offset: Offset(0, 1), blurRadius: 2),
                    ]),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildInfoPlate(AppPalette C, bool isComic) {
    return _MetalPlate(
      C: C,
      padding: const EdgeInsets.all(14),
      child: Column(
        children: [
          Row(
            children: [
              if (!isComic) _Rivet(C: C, size: 8),
              if (!isComic) const SizedBox(width: 8),
              Icon(Icons.info_outline,
                  color: isComic ? Colors.black : C.accent, size: 14),
              const SizedBox(width: 6),
              Text('INFORMASI',
                  style: TextStyle(
                    color: isComic ? Colors.black : C.accent,
                    fontSize: isComic ? 13 : 10,
                    fontWeight: FontWeight.w900,
                    fontFamily: isComic ? 'Bangers' : 'Orbitron',
                    letterSpacing: 1.5)),
            ],
          ),
          const SizedBox(height: 10),
          _infoLine(C, isComic, '• Laporan langsung diteruskan ke owner bot'),
          _infoLine(C, isComic,
              '• Pastikan pesan jelas, sopan, dan tidak spam'),
          _infoLine(C, isComic, '• Balasan akan dikirim via Telegram bot'),
          _infoLine(C, isComic,
              '• Jika server down, otomatis buka Telegram owner'),
        ],
      ),
    );
  }

  Widget _infoLine(AppPalette C, bool isComic, String text) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 3),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Expanded(
            child: Text(
              text,
              style: TextStyle(
                color: isComic
                    ? Colors.black.withOpacity(0.7)
                    : C.text.withOpacity(0.65),
                fontSize: 10,
                fontFamily: isComic ? 'ComicNeue' : 'ShareTechMono',
                height: 1.4),
            ),
          ),
        ],
      ),
    );
  }
}

class _ComicHalftonePainter extends CustomPainter {
  final Color color;
  const _ComicHalftonePainter({required this.color});

  @override
  void paint(Canvas canvas, Size size) {
    const spacing = 22.0;
    final paint = Paint()..color = color;
    for (double x = 0; x < size.width + spacing; x += spacing) {
      for (double y = 0; y < size.height + spacing; y += spacing) {
        canvas.drawCircle(Offset(x, y), 2.5, paint);
      }
    }
  }

  @override
  bool shouldRepaint(_ComicHalftonePainter old) => old.color != color;
}