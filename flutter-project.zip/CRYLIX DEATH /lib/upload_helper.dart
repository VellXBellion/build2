// lib/upload_helper.dart
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:image_picker/image_picker.dart';
import 'catbox_service.dart';

class UploadHelper {
  /// ═══════════════════════════════════════════════════════════
  /// PICK & UPLOAD IMAGE — Shortcut lengkap
  /// ═══════════════════════════════════════════════════════════
  ///
  /// [context]          - BuildContext buat dialog & snackbar
  /// [source]           - Kamera / Galeri (default: gallery)
  /// [temporary]        - true = litterbox (auto-hapus), false = catbox (permanent)
  /// [expiry]           - Kalo temporary: '1h' | '12h' | '24h' | '72h'
  /// [successMessage]   - Pesan sukses (opsional, ada default)
  /// [loadingMessage]   - Pesan loading (opsional, ada default)
  /// [showSnackbar]     - false kalo mau handle notif sendiri
  /// [imageQuality]     - 0-100 (default 80)
  /// [maxWidth]         - Max lebar piksel (default 1920)
  ///
  /// Return: URL (String) kalau sukses, null kalau gagal/cancel
  static Future<String?> pickAndUploadImage({
    required BuildContext context,
    ImageSource source = ImageSource.gallery,
    bool temporary = false,
    String expiry = '24h',
    String? successMessage,
    String? loadingMessage,
    bool showSnackbar = true,
    int imageQuality = 80,
    double maxWidth = 1920,
  }) async {
    File? pickedFile;

    try {
      // 1. Pick image dari kamera/galeri
      final picker = ImagePicker();
      final picked = await picker.pickImage(
        source: source,
        imageQuality: imageQuality,
        maxWidth: maxWidth,
      );

      // User cancel
      if (picked == null) return null;
      pickedFile = File(picked.path);

      // 2. Haptic feedback
      HapticFeedback.lightImpact();

      // 3. Show loading dialog
      if (context.mounted) {
        _showLoadingDialog(
          context,
          loadingMessage ??
              (temporary ? 'Uploading (temporary)...' : 'Uploading...'),
        );
      }

      // 4. Upload ke catbox / litterbox
      final CatboxResult result;
      if (temporary) {
        result = await CatboxService.uploadTemporary(
          pickedFile,
          expiry: expiry,
        );
      } else {
        result = await CatboxService.uploadFile(pickedFile);
      }

      // 5. Close loading dialog
      if (context.mounted) {
        Navigator.of(context, rootNavigator: true).pop();
      }

      // 6. Handle hasil
      if (result.success && result.url != null) {
        HapticFeedback.mediumImpact();

        if (showSnackbar && context.mounted) {
          _showSnack(
            context,
            successMessage ?? 'Upload berhasil!',
            isError: false,
          );
        }
        return result.url;
      } else {
        if (showSnackbar && context.mounted) {
          _showSnack(
            context,
            'Upload gagal: ${result.error ?? "Unknown error"}',
            isError: true,
          );
        }
        return null;
      }
    } catch (e) {
      // Handle error (dialog masih kebuka?)
      if (context.mounted) {
        Navigator.of(context, rootNavigator: true).pop();
      }

      if (showSnackbar && context.mounted) {
        _showSnack(context, 'Error: $e', isError: true);
      }
      return null;
    }
  }

  /// ═══════════════════════════════════════════════════════════
  /// UPLOAD FILE — Tanpa UI picker (langsung upload file)
  /// ═══════════════════════════════════════════════════════════
  static Future<String?> uploadFileDirect({
    required BuildContext context,
    required File file,
    bool temporary = false,
    String expiry = '24h',
    String? successMessage,
    String? loadingMessage,
    bool showSnackbar = true,
  }) async {
    try {
      if (!await file.exists()) {
        if (showSnackbar && context.mounted) {
          _showSnack(context, 'File tidak ditemukan', isError: true);
        }
        return null;
      }

      if (context.mounted) {
        _showLoadingDialog(
          context,
          loadingMessage ?? 'Uploading...',
        );
      }

      final CatboxResult result;
      if (temporary) {
        result = await CatboxService.uploadTemporary(file, expiry: expiry);
      } else {
        result = await CatboxService.uploadFile(file);
      }

      if (context.mounted) {
        Navigator.of(context, rootNavigator: true).pop();
      }

      if (result.success && result.url != null) {
        HapticFeedback.mediumImpact();
        if (showSnackbar && context.mounted) {
          _showSnack(
              context, successMessage ?? 'Upload berhasil!', isError: false);
        }
        return result.url;
      } else {
        if (showSnackbar && context.mounted) {
          _showSnack(
            context,
            'Upload gagal: ${result.error ?? "Unknown error"}',
            isError: true,
          );
        }
        return null;
      }
    } catch (e) {
      if (context.mounted) {
        Navigator.of(context, rootNavigator: true).pop();
      }
      if (showSnackbar && context.mounted) {
        _showSnack(context, 'Error: $e', isError: true);
      }
      return null;
    }
  }

  /// ═══════════════════════════════════════════════════════════
  /// SHOW BOTTOM SHEET — Pilih kamera / galeri
  /// ═══════════════════════════════════════════════════════════
  static Future<ImageSource?> showSourcePicker({
    required BuildContext context,
    String title = 'PILIH SUMBER FOTO',
    String cameraLabel = 'KAMERA',
    String galleryLabel = 'GALERI',
  }) async {
    return showModalBottomSheet<ImageSource>(
      context: context,
      backgroundColor: Colors.transparent,
      barrierColor: Colors.black.withOpacity(0.85),
      builder: (ctx) => Container(
        padding: const EdgeInsets.all(20),
        decoration: const BoxDecoration(
          color: Color(0xFF1C1E21),
          borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
        ),
        child: SafeArea(
          top: false,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              // Drag handle
              Container(
                width: 50,
                height: 4,
                decoration: BoxDecoration(
                  color: Colors.white24,
                  borderRadius: BorderRadius.circular(2),
                ),
              ),
              const SizedBox(height: 20),

              // Title
              Text(
                title,
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 14,
                  fontWeight: FontWeight.w900,
                  fontFamily: 'Orbitron',
                  letterSpacing: 2,
                ),
              ),
              const SizedBox(height: 20),

              // Buttons
              Row(
                children: [
                  Expanded(
                    child: _sheetBtn(
                      icon: Icons.camera_alt_rounded,
                      label: cameraLabel,
                      onTap: () => Navigator.pop(ctx, ImageSource.camera),
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: _sheetBtn(
                      icon: Icons.photo_library_rounded,
                      label: galleryLabel,
                      onTap: () => Navigator.pop(ctx, ImageSource.gallery),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  /// ═══════════════════════════════════════════════════════════
  /// FULL FLOW: Pick source → Pick image → Upload → Return URL
  /// ═══════════════════════════════════════════════════════════
  static Future<String?> pickSourceAndUpload({
    required BuildContext context,
    bool temporary = false,
    String expiry = '24h',
    String? successMessage,
    bool showSnackbar = true,
    int imageQuality = 80,
    double maxWidth = 1920,
  }) async {
    final source = await showSourcePicker(context: context);
    if (source == null) return null;

    return pickAndUploadImage(
      context: context,
      source: source,
      temporary: temporary,
      expiry: expiry,
      successMessage: successMessage,
      showSnackbar: showSnackbar,
      imageQuality: imageQuality,
      maxWidth: maxWidth,
    );
  }

  // ═══════════════════════════════════════════════════════════
  // PRIVATE HELPERS
  // ═══════════════════════════════════════════════════════════

  static void _showLoadingDialog(BuildContext context, String message) {
    showDialog(
      context: context,
      barrierDismissible: false,
      useRootNavigator: true,
      builder: (_) => PopScope(
        canPop: false,
        child: Dialog(
          backgroundColor: Colors.transparent,
          child: Container(
            padding: const EdgeInsets.all(24),
            decoration: BoxDecoration(
              color: const Color(0xFF1C1E21),
              borderRadius: BorderRadius.circular(16),
              border: Border.all(color: Colors.white12, width: 1),
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const SizedBox(
                  width: 40,
                  height: 40,
                  child: CircularProgressIndicator(
                    color: Colors.white,
                    strokeWidth: 3,
                  ),
                ),
                const SizedBox(height: 16),
                Text(
                  message,
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 13,
                    fontWeight: FontWeight.w700,
                    fontFamily: 'ShareTechMono',
                  ),
                  textAlign: TextAlign.center,
                ),
                const SizedBox(height: 8),
                const Text(
                  'Mohon tunggu sebentar...',
                  style: TextStyle(
                    color: Colors.white54,
                    fontSize: 10,
                    fontFamily: 'ShareTechMono',
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  static void _showSnack(
    BuildContext context,
    String message, {
    bool isError = false,
  }) {
    ScaffoldMessenger.of(context).hideCurrentSnackBar();
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Row(
          children: [
            Icon(
              isError
                  ? Icons.error_outline_rounded
                  : Icons.check_circle_outline_rounded,
              color: Colors.white,
              size: 18,
            ),
            const SizedBox(width: 10),
            Expanded(
              child: Text(
                message,
                style: const TextStyle(
                  fontWeight: FontWeight.w700,
                  fontSize: 12,
                ),
              ),
            ),
          ],
        ),
        backgroundColor: isError ? Colors.red[700] : Colors.green[700],
        behavior: SnackBarBehavior.floating,
        duration: Duration(seconds: isError ? 4 : 2),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
        ),
        margin: const EdgeInsets.all(16),
      ),
    );
  }

  static Widget _sheetBtn({
    required IconData icon,
    required String label,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        height: 56,
        decoration: BoxDecoration(
          color: Colors.white10,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: Colors.white24, width: 1.5),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, color: Colors.white, size: 18),
            const SizedBox(width: 8),
            Text(
              label,
              style: const TextStyle(
                color: Colors.white,
                fontSize: 12,
                fontWeight: FontWeight.w900,
                fontFamily: 'Orbitron',
                letterSpacing: 2,
              ),
            ),
          ],
        ),
      ),
    );
  }
}