// seller_page.dart — Seller Dashboard (Support Style Switcher)
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'app_theme.dart';
import 'api_config.dart';

class SellerPage extends StatefulWidget {
  final String keyToken;
  const SellerPage({super.key, required this.keyToken});

  @override
  State<SellerPage> createState() => _SellerPageState();
}

class _SellerPageState extends State<SellerPage> {
  List<dynamic> fullUserList = [];
  List<dynamic> filteredList = [];

  final List<String> roleOptions = ['full up'];
  String selectedRole = 'full up';

  int currentPage = 1;
  int itemsPerPage = 25;

  final createUsernameController = TextEditingController();
  final createPasswordController = TextEditingController();
  final createDayController = TextEditingController();
  final editUsernameController = TextEditingController();
  final editDayController = TextEditingController();

  bool isLoading = false;

  @override
  void initState() {
    super.initState();
    _fetchUsers();
  }

  @override
  void dispose() {
    createUsernameController.dispose();
    createPasswordController.dispose();
    createDayController.dispose();
    editUsernameController.dispose();
    editDayController.dispose();
    super.dispose();
  }

  Future<void> _fetchUsers() async {
    setState(() => isLoading = true);
    try {
      final res = await http.get(
          Uri.parse('$baseUrl/listUsers?key=${widget.keyToken}'));
      final data = jsonDecode(res.body);
      if (data['valid'] == true && data['authorized'] == true) {
        fullUserList = data['users'] ?? [];
        _filterAndPaginate();
      } else {
        _alert("Info", data['message'] ?? 'Gagal memuat user.');
      }
    } catch (_) {
      _alert("Error", "Gagal terhubung ke server.");
    }
    setState(() => isLoading = false);
  }

  void _filterAndPaginate() {
    setState(() {
      currentPage = 1;
      filteredList =
          fullUserList.where((u) => u['role'] == selectedRole).toList();
    });
  }

  List<dynamic> _getCurrentPageData() {
    final start = (currentPage - 1) * itemsPerPage;
    final end = start + itemsPerPage;
    return filteredList.sublist(
        start, end > filteredList.length ? filteredList.length : end);
  }

  int get totalPages => (filteredList.length / itemsPerPage).ceil();

  Future<void> _createAccount() async {
    final u = createUsernameController.text.trim();
    final p = createPasswordController.text.trim();
    final d = createDayController.text.trim();
    if (u.isEmpty || p.isEmpty || d.isEmpty) {
      _alert("Peringatan", "Semua field wajib diisi.");
      return;
    }
    setState(() => isLoading = true);
    try {
      final res = await http.get(Uri.parse(
          "$baseUrl/createAccount?key=${widget.keyToken}&newUser=$u&pass=$p&day=$d"));
      final data = jsonDecode(res.body);
      if (data['created'] == true) {
        _alert("Sukses", "✅ Akun berhasil dibuat!");
        createUsernameController.clear();
        createPasswordController.clear();
        createDayController.clear();
        _fetchUsers();
      } else {
        String msg = data['message'] ?? 'Gagal membuat akun.';
        if (data['invalidDay'] == true) msg += " (Max 30 hari untuk Reseller)";
        _alert("Gagal", "❌ $msg");
      }
    } catch (e) {
      _alert("Error", "❌ Koneksi error: $e");
    }
    setState(() => isLoading = false);
  }

  Future<void> _editUser() async {
    final u = editUsernameController.text.trim();
    final d = editDayController.text.trim();
    if (u.isEmpty || d.isEmpty) {
      _alert("Peringatan", "Semua field wajib diisi.");
      return;
    }
    setState(() => isLoading = true);
    try {
      final res = await http.get(Uri.parse(
          "$baseUrl/editUser?key=${widget.keyToken}&username=$u&addDays=$d"));
      final data = jsonDecode(res.body);
      if (data['edited'] == true) {
        _alert("Sukses", "✅ Durasi berhasil diperbarui.");
        editUsernameController.clear();
        editDayController.clear();
        _fetchUsers();
      } else {
        _alert("Gagal", "❌ ${data['message'] ?? 'Gagal mengubah durasi.'}");
      }
    } catch (e) {
      _alert("Error", "❌ Koneksi error: $e");
    }
    setState(() => isLoading = false);
  }

  void _alert(String title, String message) {
    final C = AppTheme.current.value;
    final isComic = AppTheme.currentStyle.value == ThemeStyle.comic3d;
    HapticFeedback.mediumImpact();

    showDialog(
      context: context,
      barrierColor: Colors.black.withOpacity(0.85),
      builder: (_) => Dialog(
        backgroundColor: Colors.transparent,
        child: isComic
            ? Container(
                decoration: BoxDecoration(
                  color: C.bgDark,
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(color: Colors.black, width: 4),
                  boxShadow: const [
                    BoxShadow(
                        color: Colors.black,
                        offset: Offset(6, 6),
                        blurRadius: 0),
                  ],
                ),
                padding: const EdgeInsets.all(20),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Row(
                      children: [
                        Container(
                          padding: const EdgeInsets.all(8),
                          decoration: BoxDecoration(
                            color: C.primaryHi,
                            shape: BoxShape.circle,
                            border:
                                Border.all(color: Colors.black, width: 3),
                          ),
                          child: Icon(Icons.info_outline,
                              color: C.contrastTextOn(C.primaryHi),
                              size: 18),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Text(title.toUpperCase(),
                              style: TextStyle(
                                color: C.comicText,
                                fontFamily: 'Bangers',
                                fontSize: 18,
                                letterSpacing: 2,
                              )),
                        ),
                      ],
                    ),
                    const SizedBox(height: 16),
                    Text(message,
                        textAlign: TextAlign.center,
                        style: TextStyle(
                            color: C.comicTextSub,
                            fontFamily: 'ComicNeue',
                            fontSize: 13,
                            height: 1.5)),
                    const SizedBox(height: 20),
                    _ComicDialogButton(
                        C: C, label: 'OK', onTap: () => Navigator.pop(context)),
                  ],
                ),
              )
            : AlertDialog(
                backgroundColor: C.bgDark,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(20),
                  side: BorderSide(color: C.accent.withOpacity(0.3)),
                ),
                title: Row(
                  children: [
                    Icon(Icons.info_outline, color: C.accent),
                    const SizedBox(width: 10),
                    Text(title,
                        style: TextStyle(
                            color: C.text, fontFamily: 'Orbitron')),
                  ],
                ),
                content: Text(message,
                    style: TextStyle(
                        color: C.textSub, fontFamily: 'ShareTechMono')),
                actions: [
                  TextButton(
                    onPressed: () => Navigator.pop(context),
                    child: Text('OK',
                        style: TextStyle(
                            color: C.accent, fontWeight: FontWeight.bold)),
                  ),
                ],
              ),
      ),
    );
  }

  Widget _buildInput({
    required AppPalette C,
    required bool isComic,
    required String label,
    required TextEditingController controller,
    required dynamic icon,
    TextInputType type = TextInputType.text,
    String hint = "",
  }) {
    if (isComic) {
      return Padding(
        padding: const EdgeInsets.only(bottom: 14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Padding(
              padding: const EdgeInsets.only(left: 4, bottom: 6),
              child: Text(label.toUpperCase(),
                  style: TextStyle(
                    color: C.comicText,
                    fontFamily: 'Bangers',
                    fontSize: 13,
                    letterSpacing: 1.5,
                  )),
            ),
            Container(
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(10),
                border: Border.all(color: Colors.black, width: 3),
              ),
              child: TextField(
                controller: controller,
                keyboardType: type,
                style: const TextStyle(
                    color: Colors.black,
                    fontFamily: 'ComicNeue',
                    fontWeight: FontWeight.w700,
                    fontSize: 14),
                cursorColor: Colors.black,
                decoration: InputDecoration(
                  hintText: hint,
                  hintStyle: TextStyle(
                      color: Colors.black.withOpacity(0.4),
                      fontFamily: 'ComicNeue',
                      fontSize: 12),
                  prefixIcon:
                      _DynamicIcon(icon, color: C.primaryHi, size: 18),
                  border: InputBorder.none,
                  contentPadding: const EdgeInsets.symmetric(
                      horizontal: 12, vertical: 14),
                ),
              ),
            ),
          ],
        ),
      );
    }

    return Padding(
      padding: const EdgeInsets.only(bottom: 15),
      child: TextField(
        controller: controller,
        keyboardType: type,
        style: TextStyle(color: C.text, fontFamily: 'ShareTechMono'),
        decoration: InputDecoration(
          labelText: label,
          hintText: hint,
          hintStyle: TextStyle(color: C.text.withOpacity(0.3)),
          labelStyle: TextStyle(color: C.accentHi),
          prefixIcon:
              _DynamicIcon(icon, color: C.accentHi.withOpacity(0.7), size: 18),
          filled: true,
          fillColor: C.bgDeep,
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: BorderSide(color: C.bg),
          ),
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: BorderSide(color: C.bg),
          ),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: BorderSide(color: C.accentHi, width: 2),
          ),
        ),
      ),
    );
  }

  Widget _buildGlassCard({
    required AppPalette C,
    required bool isComic,
    required String title,
    required dynamic icon,
    required List<Widget> children,
  }) {
    if (isComic) {
      return Container(
        margin: const EdgeInsets.only(bottom: 20),
        padding: const EdgeInsets.all(18),
        decoration: BoxDecoration(
          color: C.bgDark,
          borderRadius: BorderRadius.circular(18),
          border: Border.all(color: Colors.black, width: 4),
          boxShadow: const [
            BoxShadow(
                color: Colors.black, offset: Offset(6, 6), blurRadius: 0),
          ],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(10),
                  decoration: BoxDecoration(
                    color: C.primaryHi,
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(color: Colors.black, width: 3),
                  ),
                  child: _DynamicIcon(icon,
                      color: C.contrastTextOn(C.primaryHi), size: 18),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Text(title,
                      style: TextStyle(
                        color: C.comicText,
                        fontSize: 18,
                        fontFamily: 'Bangers',
                        letterSpacing: 2,
                      )),
                ),
              ],
            ),
            const SizedBox(height: 18),
            ...children,
          ],
        ),
      );
    }

    return Container(
      margin: const EdgeInsets.only(bottom: 25),
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        color: C.bgDark.withOpacity(0.4),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: C.accentHi.withOpacity(0.15)),
        boxShadow: [
          BoxShadow(
              color: C.accentHi.withOpacity(0.04),
              blurRadius: 15,
              offset: const Offset(0, 5)),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: C.accent.withOpacity(0.2),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: _DynamicIcon(icon, color: C.accentHi, size: 18),
              ),
              const SizedBox(width: 12),
              Text(title,
                  style: TextStyle(
                    color: C.text,
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    fontFamily: 'Orbitron',
                    letterSpacing: 1,
                  )),
            ],
          ),
          const SizedBox(height: 20),
          ...children,
        ],
      ),
    );
  }

  Widget _buildUserItem(AppPalette C, bool isComic, Map user) {
    if (isComic) {
      return Container(
        margin: const EdgeInsets.symmetric(horizontal: 4, vertical: 6),
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: Colors.black, width: 3),
        ),
        child: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: C.primaryHi,
                shape: BoxShape.circle,
                border: Border.all(color: Colors.black, width: 2.5),
              ),
              child: Icon(Icons.person,
                  color: C.contrastTextOn(C.primaryHi), size: 18),
            ),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(user['username'],
                      style: const TextStyle(
                        color: Colors.black,
                        fontFamily: 'Bangers',
                        fontWeight: FontWeight.bold,
                        fontSize: 16,
                        letterSpacing: 1,
                      )),
                  const SizedBox(height: 2),
                  Text(
                      "ROLE: ${user['role'].toString().toUpperCase()} | EXP: ${user['expiredDate']}",
                      style: TextStyle(
                        color: Colors.black.withOpacity(0.6),
                        fontFamily: 'ComicNeue',
                        fontWeight: FontWeight.w700,
                        fontSize: 11,
                      )),
                ],
              ),
            ),
          ],
        ),
      );
    }

    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      decoration: BoxDecoration(
        color: C.bgDeep,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: C.accentHi.withOpacity(0.15)),
      ),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              color: C.accent.withOpacity(0.2),
              shape: BoxShape.circle,
            ),
            child: Icon(Icons.person, color: C.accentHi),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(user['username'],
                    style: TextStyle(
                        color: C.text,
                        fontWeight: FontWeight.bold,
                        fontSize: 16)),
                const SizedBox(height: 4),
                Text(
                    "ROLE: ${user['role'].toString().toUpperCase()} | EXP: ${user['expiredDate']}",
                    style: TextStyle(color: C.textSub, fontSize: 13)),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildPagination(AppPalette C, bool isComic) {
    if (isComic) {
      return Wrap(
        spacing: 8,
        runSpacing: 8,
        children: List.generate(totalPages, (index) {
          final page = index + 1;
          final isActive = currentPage == page;
          return GestureDetector(
            onTap: () => setState(() => currentPage = page),
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
              decoration: BoxDecoration(
                color: isActive ? C.primaryHi : C.bg,
                borderRadius: BorderRadius.circular(10),
                border: Border.all(color: Colors.black, width: 3),
                boxShadow: const [
                  BoxShadow(
                      color: Colors.black,
                      offset: Offset(2, 2),
                      blurRadius: 0),
                ],
              ),
              child: Text('$page',
                  style: TextStyle(
                    color: isActive
                        ? C.contrastTextOn(C.primaryHi)
                        : C.comicText,
                    fontWeight: FontWeight.w900,
                    fontFamily: 'Bangers',
                    fontSize: 14,
                  )),
            ),
          );
        }),
      );
    }

    return Wrap(
      spacing: 8,
      runSpacing: 8,
      children: List.generate(totalPages, (index) {
        final page = index + 1;
        return ElevatedButton(
          onPressed: () => setState(() => currentPage = page),
          style: ElevatedButton.styleFrom(
            backgroundColor:
                currentPage == page ? C.accentHi : Colors.transparent,
            foregroundColor:
                currentPage == page ? C.bgDeep : C.text.withOpacity(0.5),
            padding: const EdgeInsets.symmetric(horizontal: 16),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(8),
              side: BorderSide(color: C.accentHi.withOpacity(0.15)),
            ),
          ),
          child: Text("$page",
              style:
                  const TextStyle(fontSize: 12, fontWeight: FontWeight.bold)),
        );
      }),
    );
  }

  Widget _buildActionButton({
    required AppPalette C,
    required bool isComic,
    required String label,
    required VoidCallback onTap,
  }) {
    if (isComic) {
      return GestureDetector(
        onTap: isLoading ? null : onTap,
        child: Container(
          height: 50,
          decoration: BoxDecoration(
            color: C.primaryHi,
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: Colors.black, width: 3.5),
            boxShadow: const [
              BoxShadow(
                  color: Colors.black, offset: Offset(4, 4), blurRadius: 0),
            ],
          ),
          child: Center(
            child: isLoading
                ? SizedBox(
                    width: 20,
                    height: 20,
                    child: CircularProgressIndicator(
                        strokeWidth: 2,
                        color: C.contrastTextOn(C.primaryHi)),
                  )
                : Text(label,
                    style: TextStyle(
                      color: C.contrastTextOn(C.primaryHi),
                      fontFamily: 'Bangers',
                      fontWeight: FontWeight.bold,
                      fontSize: 16,
                      letterSpacing: 1.5,
                    )),
          ),
        ),
      );
    }

    return Container(
      height: 50,
      decoration: BoxDecoration(
        gradient: LinearGradient(colors: [C.accent, C.accentHi]),
        borderRadius: BorderRadius.circular(12),
        boxShadow: [
          BoxShadow(
              color: C.accentHi.withOpacity(0.3),
              blurRadius: 10,
              offset: const Offset(0, 4)),
        ],
      ),
      child: ElevatedButton(
        onPressed: isLoading ? null : onTap,
        style: ElevatedButton.styleFrom(
          backgroundColor: Colors.transparent,
          shadowColor: Colors.transparent,
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        ),
        child: isLoading
            ? SizedBox(
                width: 20,
                height: 20,
                child:
                    CircularProgressIndicator(strokeWidth: 2, color: C.bgDeep))
            : Text(label,
                style: TextStyle(
                    color: C.bgDeep, fontWeight: FontWeight.bold)),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<AppPalette>(
      valueListenable: AppTheme.current,
      builder: (context, C, _) {
        return ValueListenableBuilder<ThemeStyle>(
          valueListenable: AppTheme.currentStyle,
          builder: (context, style, __) {
            final isComic = style == ThemeStyle.comic3d;

            return Scaffold(
              backgroundColor: isComic ? C.bg : C.bgDeep,
              body: Stack(
                children: [
                  Positioned.fill(
                    child: isComic
                        ? Container(
                            color: C.bg,
                            child: CustomPaint(
                              painter: _ComicHalftonePainter(
                                  color: C.primaryLo.withOpacity(0.12)),
                            ),
                          )
                        : Container(
                            decoration: BoxDecoration(
                              gradient: LinearGradient(
                                begin: Alignment.topCenter,
                                end: Alignment.bottomCenter,
                                colors: [
                                  C.bgDeep,
                                  C.accent.withOpacity(0.12),
                                  C.bgDeep
                                ],
                              ),
                            ),
                          ),
                  ),
                  SafeArea(
                    child: SingleChildScrollView(
                      physics: const BouncingScrollPhysics(),
                      padding: const EdgeInsets.symmetric(
                          horizontal: 20, vertical: 20),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Container(
                            padding: const EdgeInsets.all(16),
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              color: isComic ? C.primaryHi : null,
                              border: isComic
                                  ? Border.all(color: Colors.black, width: 4)
                                  : null,
                              boxShadow: isComic
                                  ? const [
                                      BoxShadow(
                                          color: Colors.black,
                                          offset: Offset(5, 5),
                                          blurRadius: 0),
                                    ]
                                  : null,
                            ),
                            child: _DynamicIcon(FontAwesomeIcons.store,
                                color: isComic
                                    ? C.contrastTextOn(C.primaryHi)
                                    : C.accentHi,
                                size: 40),
                          ),
                          const SizedBox(height: 10),
                          Text(
                            "SELLER DASHBOARD",
                            style: TextStyle(
                              color: isComic ? C.comicText : C.text,
                              fontSize: isComic ? 28 : 24,
                              fontWeight: FontWeight.bold,
                              fontFamily: isComic ? 'Bangers' : 'Orbitron',
                              letterSpacing: isComic ? 3 : 2,
                              shadows: isComic
                                  ? [
                                      Shadow(
                                          color: C.comicTextOutline
                                              .withOpacity(0.7),
                                          offset: const Offset(2, 2),
                                          blurRadius: 0),
                                    ]
                                  : [
                                      Shadow(
                                          color: C.accentHi.withOpacity(0.8),
                                          blurRadius: 10),
                                    ],
                            ),
                          ),
                          const SizedBox(height: 30),

                          _buildGlassCard(
                            C: C,
                            isComic: isComic,
                            title: "CREATE FULL UP",
                            icon: FontAwesomeIcons.userPlus,
                            children: [
                              _buildInput(
                                  C: C,
                                  isComic: isComic,
                                  label: "Username Baru",
                                  controller: createUsernameController,
                                  icon: FontAwesomeIcons.user),
                              _buildInput(
                                  C: C,
                                  isComic: isComic,
                                  label: "Password",
                                  controller: createPasswordController,
                                  icon: FontAwesomeIcons.lock),
                              _buildInput(
                                  C: C,
                                  isComic: isComic,
                                  label: "Durasi (Hari)",
                                  controller: createDayController,
                                  icon: FontAwesomeIcons.calendarDay,
                                  type: TextInputType.number,
                                  hint: "Maksimal 30 hari"),
                              const SizedBox(height: 6),
                              _buildActionButton(
                                C: C,
                                isComic: isComic,
                                label: "CREATE ACCOUNT",
                                onTap: _createAccount,
                              ),
                            ],
                          ),

                          _buildGlassCard(
                            C: C,
                            isComic: isComic,
                            title: "EXTEND DURATION",
                            icon: FontAwesomeIcons.clock,
                            children: [
                              _buildInput(
                                  C: C,
                                  isComic: isComic,
                                  label: "Username Target",
                                  controller: editUsernameController,
                                  icon: FontAwesomeIcons.userEdit,
                                  hint: "Username member"),
                              _buildInput(
                                  C: C,
                                  isComic: isComic,
                                  label: "Tambah Hari",
                                  controller: editDayController,
                                  icon: FontAwesomeIcons.calendarPlus,
                                  type: TextInputType.number,
                                  hint: "Maksimal 30 hari"),
                              const SizedBox(height: 6),
                              _buildActionButton(
                                C: C,
                                isComic: isComic,
                                label: "ADD DAYS",
                                onTap: _editUser,
                              ),
                            ],
                          ),

                          _buildGlassCard(
                            C: C,
                            isComic: isComic,
                            title: "FULL UP LIST",
                            icon: FontAwesomeIcons.users,
                            children: [
                              Container(
                                padding: const EdgeInsets.symmetric(
                                    horizontal: 12, vertical: 4),
                                decoration: BoxDecoration(
                                  color:
                                      isComic ? Colors.white : C.bgDeep,
                                  borderRadius: BorderRadius.circular(12),
                                  border: Border.all(
                                      color:
                                          isComic ? Colors.black : C.bg,
                                      width: isComic ? 3 : 1),
                                ),
                                child: DropdownButtonHideUnderline(
                                  child: DropdownButton<String>(
                                    value: selectedRole,
                                    dropdownColor:
                                        isComic ? Colors.white : C.bgDark,
                                    style: TextStyle(
                                        color: isComic
                                            ? Colors.black
                                            : C.text,
                                        fontFamily: isComic
                                            ? 'ComicNeue'
                                            : 'ShareTechMono'),
                                    items: roleOptions
                                        .map((role) => DropdownMenuItem(
                                            value: role,
                                            child:
                                                Text(role.toUpperCase())))
                                        .toList(),
                                    onChanged: (val) {
                                      if (val != null) {
                                        selectedRole = val;
                                        _filterAndPaginate();
                                      }
                                    },
                                  ),
                                ),
                              ),
                              const SizedBox(height: 16),
                              isLoading
                                  ? Center(
                                      child: CircularProgressIndicator(
                                          color: isComic
                                              ? Colors.black
                                              : C.accentHi))
                                  : Column(
                                      children: [
                                        ..._getCurrentPageData().map((u) =>
                                            _buildUserItem(C, isComic, u)),
                                        const SizedBox(height: 16),
                                        _buildPagination(C, isComic),
                                      ],
                                    ),
                            ],
                          ),
                          const SizedBox(height: 20),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            );
          },
        );
      },
    );
  }
}

// ═══════════════════════════════════════════════════════════
// COMIC DIALOG BUTTON
// ═══════════════════════════════════════════════════════════
class _ComicDialogButton extends StatelessWidget {
  final AppPalette C;
  final String label;
  final VoidCallback onTap;
  const _ComicDialogButton(
      {required this.C, required this.label, required this.onTap});

  @override
  Widget build(BuildContext context) {
    final bg = C.primaryHi;
    return GestureDetector(
      onTap: onTap,
      child: Container(
        height: 50,
        decoration: BoxDecoration(
          color: bg,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: Colors.black, width: 3.5),
          boxShadow: const [
            BoxShadow(
                color: Colors.black, offset: Offset(4, 4), blurRadius: 0),
          ],
        ),
        child: Center(
          child: Text(label,
              style: TextStyle(
                color: C.contrastTextOn(bg),
                fontFamily: 'Bangers',
                fontSize: 16,
                fontWeight: FontWeight.bold,
                letterSpacing: 2,
              )),
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════
// COMIC HALFTONE PAINTER
// ═══════════════════════════════════════════════════════════
class _ComicHalftonePainter extends CustomPainter {
  final Color color;
  const _ComicHalftonePainter({required this.color});

  @override
  void paint(Canvas canvas, Size size) {
    const spacing = 22.0;
    final paint = Paint()..color = color;
    for (double x = 0; x < size.width + spacing; x += spacing) {
      for (double y = 0; y < size.height + spacing; y += spacing) {
        canvas.drawCircle(Offset(x, y), 2.5, paint);
      }
    }
  }

  @override
  bool shouldRepaint(_ComicHalftonePainter old) => old.color != color;
}

// ═══════════════════════════════════════════════════════════
// DYNAMIC ICON
// ═══════════════════════════════════════════════════════════
class _DynamicIcon extends StatelessWidget {
  final dynamic icon;
  final double? size;
  final Color? color;
  const _DynamicIcon(this.icon, {this.size, this.color});

  @override
  Widget build(BuildContext context) {
    if (icon == null) return const SizedBox.shrink();
    if (icon is IconData && icon.fontPackage == 'font_awesome_flutter') {
      return FaIcon(icon, size: size, color: color);
    } else if (icon is IconData) {
      return Icon(icon, size: size, color: color);
    }
    return const SizedBox.shrink();
  }
}