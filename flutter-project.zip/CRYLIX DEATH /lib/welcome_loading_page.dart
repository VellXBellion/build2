// lib/welcome_loading_page.dart
import 'dart:async';
import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'app_theme.dart';

class WelcomeLoadingPage extends StatefulWidget {
  final Widget nextPage;
  final String username;
  final int durationSeconds;

  const WelcomeLoadingPage({
    super.key,
    required this.nextPage,
    required this.username,
    this.durationSeconds = 4,
  });

  @override
  State<WelcomeLoadingPage> createState() => _WelcomeLoadingPageState();
}

class _WelcomeLoadingPageState extends State<WelcomeLoadingPage>
    with TickerProviderStateMixin {
  late AnimationController _pulseCtrl;
  late AnimationController _progressCtrl;
  late AnimationController _fadeCtrl;
  late Animation<double> _fadeAnim;

  int _progress = 0;
  String _statusText = 'INITIALIZING SYSTEM...';
  Timer? _statusTimer;

  final List<Map<String, dynamic>> _statusSteps = [
    {'p': 0, 'text': 'BOOTING CORE...'},
    {'p': 20, 'text': 'LOADING MODULES...'},
    {'p': 40, 'text': 'VERIFYING SESSION...'},
    {'p': 60, 'text': 'CONNECTING SERVER...'},
    {'p': 80, 'text': 'FINALIZING...'},
    {'p': 100, 'text': 'WELCOME!'},
  ];

  @override
  void initState() {
    super.initState();

    _pulseCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1200),
    )..repeat(reverse: true);

    _fadeCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 600),
    );
    _fadeAnim = CurvedAnimation(parent: _fadeCtrl, curve: Curves.easeOut);
    _fadeCtrl.forward();

    _progressCtrl = AnimationController(
      vsync: this,
      duration: Duration(seconds: widget.durationSeconds),
    )..forward();

    _progressCtrl.addListener(() {
      final newProgress = (_progressCtrl.value * 100).toInt();
      if (newProgress != _progress) {
        setState(() => _progress = newProgress);
        for (final step in _statusSteps.reversed) {
          if (_progress >= step['p']) {
            if (_statusText != step['text']) {
              setState(() => _statusText = step['text']);
            }
            break;
          }
        }
      }
    });

    _progressCtrl.addStatusListener((status) {
      if (status == AnimationStatus.completed) {
        _goToNext();
      }
    });
  }

  void _goToNext() {
    if (!mounted) return;
    Navigator.of(context).pushReplacement(
      PageRouteBuilder(
        pageBuilder: (_, __, ___) => widget.nextPage,
        transitionDuration: const Duration(milliseconds: 600),
        transitionsBuilder: (_, anim, __, child) =>
            FadeTransition(opacity: anim, child: child),
      ),
    );
  }

  @override
  void dispose() {
    _pulseCtrl.dispose();
    _progressCtrl.dispose();
    _fadeCtrl.dispose();
    _statusTimer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<AppPalette>(
      valueListenable: AppTheme.current,
      builder: (context, C, _) {
        return ValueListenableBuilder<ThemeStyle>(
          valueListenable: AppTheme.currentStyle,
          builder: (context, style, __) {
            final isComic = style == ThemeStyle.comic3d;

            return PopScope(
              canPop: false,
              child: Scaffold(
                backgroundColor: C.bgDeep,
                body: Container(
                  decoration: isComic
                      ? BoxDecoration(color: C.bg)
                      : BoxDecoration(
                          gradient: RadialGradient(
                            center: const Alignment(-0.3, -0.3),
                            radius: 1.3,
                            colors: [C.bg, C.bgDark, C.bgDeep],
                            stops: const [0.0, 0.6, 1.0],
                          ),
                        ),
                  child: Stack(
                    children: [
                      if (isComic)
                        Positioned.fill(
                          child: IgnorePointer(
                            child: CustomPaint(
                              painter: _ComicHalftonePainter(
                                  color: C.primaryLo.withOpacity(0.12)),
                            ),
                          ),
                        ),
                      SafeArea(
                        child: FadeTransition(
                          opacity: _fadeAnim,
                          child: Column(
                            children: [
                              const Spacer(flex: 2),
                              _buildLogo(C, isComic),
                              const SizedBox(height: 40),
                              _buildWelcomeText(C, isComic),
                              const Spacer(),
                              _buildProgressBar(C, isComic),
                              const SizedBox(height: 24),
                              _buildStatusText(C, isComic),
                              const SizedBox(height: 40),
                              _buildBottomInfo(C, isComic),
                              const SizedBox(height: 20),
                            ],
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            );
          },
        );
      },
    );
  }

  Widget _buildLogo(AppPalette C, bool isComic) {
    return AnimatedBuilder(
      animation: _pulseCtrl,
      builder: (_, __) {
        final pulse = 0.95 + _pulseCtrl.value * 0.1;

        return Transform.scale(
          scale: isComic ? 1.0 : pulse,
          child: Container(
            width: 140,
            height: 140,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: isComic
                  ? null
                  : RadialGradient(
                      center: const Alignment(-0.3, -0.3),
                      colors: [C.text, C.bg, C.bgDark, C.bgDeep],
                    ),
              color: isComic ? C.primaryHi : null,
              border: Border.all(
                  color: isComic ? Colors.black : C.accent,
                  width: isComic ? 5 : 3),
              boxShadow: isComic
                  ? const [
                      BoxShadow(
                        color: Colors.black,
                        offset: Offset(7, 7),
                        blurRadius: 0,
                      ),
                    ]
                  : [
                      BoxShadow(
                        color: Colors.black.withOpacity(0.9),
                        offset: const Offset(0, 10),
                        blurRadius: 20,
                      ),
                      BoxShadow(
                        color: C.accent.withOpacity(
                            0.5 + _pulseCtrl.value * 0.3),
                        blurRadius: 30 + _pulseCtrl.value * 20,
                        spreadRadius: 2,
                      ),
                    ],
            ),
            child: Center(
              child: ClipOval(
                child: Image.asset(
                  'assets/images/logo.jpg',
                  width: 120,
                  height: 120,
                  fit: BoxFit.cover,
                  errorBuilder: (_, __, ___) => Icon(
                    Icons.shield_moon_outlined,
                    color: isComic
                        ? C.contrastTextOn(C.primaryHi)
                        : C.accentShine,
                    size: 60,
                  ),
                ),
              ),
            ),
          ),
        );
      },
    );
  }

  Widget _buildWelcomeText(AppPalette C, bool isComic) {
    return Column(
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            _PulseLed(color: C.primaryHi, isComic: isComic),
            const SizedBox(width: 10),
            Text(
              'Welcome Back',
              style: TextStyle(
                color: isComic
                    ? C.comicText.withOpacity(0.9)
                    : C.accent.withOpacity(0.9),
                fontSize: isComic ? 16 : 11,
                fontWeight: FontWeight.w900,
                fontFamily: isComic ? 'Bangers' : 'Orbitron',
                letterSpacing: isComic ? 3 : 4,
                shadows: isComic
                    ? [
                        Shadow(
                          color: C.comicTextOutline,
                          offset: const Offset(1, 1),
                          blurRadius: 0,
                        ),
                      ]
                    : const [
                        Shadow(
                          color: Colors.black,
                          offset: Offset(0, 1),
                          blurRadius: 2,
                        ),
                      ],
              ),
            ),
            const SizedBox(width: 10),
            _PulseLed(color: C.accent, isComic: isComic),
          ],
        ),
        const SizedBox(height: 12),
        Text(
          widget.username.toUpperCase(),
          style: TextStyle(
            color: isComic ? C.comicText : C.text,
            fontSize: isComic ? 32 : 28,
            fontWeight: FontWeight.w900,
            fontFamily: isComic ? 'Bangers' : 'Orbitron',
            letterSpacing: isComic ? 3 : 3,
            shadows: isComic
                ? [
                    Shadow(
                      color: C.comicTextOutline,
                      offset: const Offset(2, 2),
                      blurRadius: 0,
                    ),
                  ]
                : [
                    const Shadow(
                      color: Colors.black,
                      offset: Offset(0, 2),
                      blurRadius: 4,
                    ),
                    Shadow(
                      color: C.accent.withOpacity(0.6),
                      blurRadius: 20,
                    ),
                  ],
          ),
          textAlign: TextAlign.center,
          maxLines: 1,
          overflow: TextOverflow.ellipsis,
        ),
        const SizedBox(height: 8),
        Text(
          'CONFLICT ',
          style: TextStyle(
            color: isComic
                ? C.comicTextSub
                : C.text.withOpacity(0.55),
            fontSize: isComic ? 12 : 11,
            fontFamily: isComic ? 'ComicNeue' : 'ShareTechMono',
            letterSpacing: 1.5,
            fontWeight: FontWeight.w700,
          ),
        ),
      ],
    );
  }

  Widget _buildProgressBar(AppPalette C, bool isComic) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 40),
      child: Column(
        children: [
          Container(
            height: isComic ? 22 : 18,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(isComic ? 11 : 9),
              gradient: isComic
                  ? null
                  : LinearGradient(
                      begin: Alignment.topCenter,
                      end: Alignment.bottomCenter,
                      colors: [C.bgDeep, C.bgDark],
                    ),
              color: isComic ? C.contrastTextOn(C.bg) : null,
              border: Border.all(
                  color: isComic
                      ? Colors.black
                      : C.accent.withOpacity(0.4),
                  width: isComic ? 4 : 1.5),
              boxShadow: isComic
                  ? null
                  : [
                      BoxShadow(
                        color: Colors.black.withOpacity(0.9),
                        offset: const Offset(0, 3),
                        blurRadius: 6,
                      ),
                    ],
            ),
            child: Stack(
              children: [
                FractionallySizedBox(
                  widthFactor: _progress / 100,
                  child: Container(
                    decoration: BoxDecoration(
                      borderRadius:
                          BorderRadius.circular(isComic ? 11 : 9),
                      gradient: isComic
                          ? null
                          : LinearGradient(colors: [
                              C.primary,
                              C.primaryHi,
                              C.accent,
                            ]),
                      color: isComic ? C.primaryHi : null,
                      boxShadow: isComic
                          ? null
                          : [
                              BoxShadow(
                                color: C.primaryHi.withOpacity(0.7),
                                blurRadius: 12,
                                spreadRadius: 1,
                              ),
                            ],
                    ),
                  ),
                ),
                if (!isComic)
                  Positioned(
                    top: 2,
                    left: 4,
                    right: 4,
                    child: Container(
                      height: 5,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(3),
                        gradient: LinearGradient(
                          colors: [
                            Colors.white.withOpacity(0.4),
                            Colors.transparent,
                          ],
                        ),
                      ),
                    ),
                  ),
              ],
            ),
          ),
          const SizedBox(height: 12),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text(
                '$_progress',
                style: TextStyle(
                  color: isComic ? C.comicText : C.accentHi,
                  fontSize: isComic ? 40 : 36,
                  fontWeight: FontWeight.w900,
                  fontFamily: isComic ? 'Bangers' : 'Orbitron',
                  letterSpacing: 2,
                  height: 1,
                  shadows: isComic
                      ? [
                          Shadow(
                            color: C.comicTextOutline,
                            offset: const Offset(2, 2),
                            blurRadius: 0,
                          ),
                        ]
                      : [
                          Shadow(
                            color: C.accent.withOpacity(0.8),
                            blurRadius: 15,
                          ),
                          const Shadow(
                            color: Colors.black,
                            offset: Offset(0, 2),
                            blurRadius: 4,
                          ),
                        ],
                ),
              ),
              Text(
                '%',
                style: TextStyle(
                  color: isComic ? C.comicText : C.accent,
                  fontSize: isComic ? 24 : 20,
                  fontWeight: FontWeight.w900,
                  fontFamily: isComic ? 'Bangers' : 'Orbitron',
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildStatusText(AppPalette C, bool isComic) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        SizedBox(
          width: 12,
          height: 12,
          child: CircularProgressIndicator(
            strokeWidth: 2,
            color: isComic ? C.comicText : C.accent,
          ),
        ),
        const SizedBox(width: 12),
        Text(
          _statusText,
          style: TextStyle(
            color: isComic ? C.comicText : C.primaryHi,
            fontSize: isComic ? 14 : 11,
            fontWeight: FontWeight.w900,
            fontFamily: isComic ? 'Bangers' : 'Orbitron',
            letterSpacing: isComic ? 2 : 2.5,
            shadows: isComic
                ? [
                    Shadow(
                      color: C.comicTextOutline,
                      offset: const Offset(1, 1),
                      blurRadius: 0,
                    ),
                  ]
                : [
                    Shadow(
                      color: C.primaryHi.withOpacity(0.5),
                      blurRadius: 8,
                    ),
                  ],
          ),
        ),
      ],
    );
  }

  Widget _buildBottomInfo(AppPalette C, bool isComic) {
    return Column(
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            _PulseLed(color: C.accent, size: 5, isComic: isComic),
            const SizedBox(width: 6),
            Text(
              'SECURE CONNECTION',
              style: TextStyle(
                color: isComic
                    ? C.comicTextSub
                    : C.text.withOpacity(0.4),
                fontSize: isComic ? 11 : 8,
                fontFamily: isComic ? 'ComicNeue' : 'ShareTechMono',
                letterSpacing: 2,
                fontWeight: FontWeight.w700,
              ),
            ),
          ],
        ),
        const SizedBox(height: 8),
        Text(
          'Zasa Fungky',
          style: TextStyle(
            color: isComic
                ? C.comicTextSub
                : C.accent.withOpacity(0.5),
            fontSize: isComic ? 12 : 9,
            fontFamily: isComic ? 'Bangers' : 'Orbitron',
            letterSpacing: 3,
            fontWeight: FontWeight.w900,
          ),
        ),
      ],
    );
  }
}

// ═══════════════════════════════════════════════════════════
// HELPER: Pulse LED
// ═══════════════════════════════════════════════════════════
class _PulseLed extends StatefulWidget {
  final Color color;
  final double size;
  final bool isComic;
  const _PulseLed({
    required this.color,
    this.size = 8,
    this.isComic = false,
  });

  @override
  State<_PulseLed> createState() => _PulseLedState();
}

class _PulseLedState extends State<_PulseLed>
    with SingleTickerProviderStateMixin {
  late AnimationController _c;

  @override
  void initState() {
    super.initState();
    _c = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 900),
    )..repeat(reverse: true);
  }

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (widget.isComic) {
      return Container(
        width: widget.size,
        height: widget.size,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          color: widget.color,
          border: Border.all(
              color: Colors.black, width: widget.size * 0.18),
        ),
      );
    }
    return AnimatedBuilder(
      animation: _c,
      builder: (_, __) {
        final o = 0.4 + _c.value * 0.6;
        return Container(
          width: widget.size,
          height: widget.size,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            gradient: RadialGradient(
              center: const Alignment(-0.35, -0.35),
              colors: [
                Colors.white.withOpacity(o),
                widget.color.withOpacity(o),
                widget.color.withOpacity(0.5 * o),
              ],
              stops: const [0.0, 0.4, 1.0],
            ),
            boxShadow: [
              BoxShadow(
                color: widget.color.withOpacity(0.8 * o),
                blurRadius: widget.size * 1.5,
                spreadRadius: widget.size * 0.3,
              ),
            ],
          ),
        );
      },
    );
  }
}

// ═══════════════════════════════════════════════════════════
// COMIC HALFTONE PAINTER
// ═══════════════════════════════════════════════════════════
class _ComicHalftonePainter extends CustomPainter {
  final Color color;
  const _ComicHalftonePainter({required this.color});

  @override
  void paint(Canvas canvas, Size size) {
    const spacing = 22.0;
    final paint = Paint()..color = color;
    for (double x = 0; x < size.width + spacing; x += spacing) {
      for (double y = 0; y < size.height + spacing; y += spacing) {
        canvas.drawCircle(Offset(x, y), 2.5, paint);
      }
    }
  }

  @override
  bool shouldRepaint(_ComicHalftonePainter old) => old.color != color;
}