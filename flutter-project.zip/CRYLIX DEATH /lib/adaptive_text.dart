// lib/adaptive_text.dart — Text auto-adaptive ke style & palette
import 'package:flutter/material.dart';
import 'app_theme.dart';

class AText extends StatelessWidget {
  final String text;
  final double fontSize;
  final Color? color;
  final bool onDark;
  final bool onLightSurface;
  final bool bold;
  final bool outline;
  final FontWeight? fontWeight;
  final double? letterSpacing;
  final TextAlign? textAlign;
  final int? maxLines;
  final TextOverflow? overflow;

  const AText(
    this.text, {
    super.key,
    this.fontSize = 14,
    this.color,
    this.onDark = true,
    this.onLightSurface = false,
    this.bold = false,
    this.outline = false,
    this.fontWeight,
    this.letterSpacing,
    this.textAlign,
    this.maxLines,
    this.overflow,
  });

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<AppPalette>(
      valueListenable: AppTheme.current,
      builder: (_, C, __) => ValueListenableBuilder<ThemeStyle>(
        valueListenable: AppTheme.currentStyle,
        builder: (_, style, ___) {
          final isComic = style == ThemeStyle.comic3d;
          Color c;
          if (color != null) {
            c = color!;
          } else if (onLightSurface) {
            c = isComic ? Colors.black : C.text;
          } else {
            c = isComic ? C.comicText : C.text;
          }

          final family = isComic ? 'Bangers' : 'Orbitron';
          List<Shadow>? shadows;
          if (isComic && outline) {
            final oc = (c == Colors.black) ? Colors.white : Colors.black;
            shadows = [
              Shadow(
                  color: oc, offset: const Offset(1.5, 1.5), blurRadius: 0),
            ];
          } else if (!isComic) {
            shadows = const [
              Shadow(color: Colors.black, offset: Offset(0, 1), blurRadius: 2),
            ];
          }

          return Text(
            text,
            textAlign: textAlign,
            maxLines: maxLines,
            overflow: overflow,
            style: TextStyle(
              color: c,
              fontFamily: family,
              fontSize: isComic ? fontSize + 1 : fontSize,
              fontWeight:
                  fontWeight ?? (bold ? FontWeight.w900 : FontWeight.w700),
              letterSpacing: letterSpacing ?? (isComic ? 1 : 0.5),
              shadows: shadows,
              height: 1.2,
            ),
          );
        },
      ),
    );
  }
}