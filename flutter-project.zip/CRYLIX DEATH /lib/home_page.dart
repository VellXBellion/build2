// lib/home_page.dart
import 'dart:async';
import 'dart:convert';
import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:video_player/video_player.dart';
import 'app_theme.dart';
import 'api_config.dart';
import 'spamotp.dart';
import 'send_bug_loading.dart';

// ═══════════════════════════════════════════════════════════
// CORE UI COMPONENTS
// ═══════════════════════════════════════════════════════════

class _Led extends StatefulWidget {
  final Color color;
  final double size;
  final bool pulse;
  const _Led({required this.color, this.size = 8, this.pulse = false});

  @override
  State<_Led> createState() => _LedState();
}

class _LedState extends State<_Led> with SingleTickerProviderStateMixin {
  late AnimationController _c;
  @override
  void initState() {
    super.initState();
    _c = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1200),
    );
    if (widget.pulse) _c.repeat(reverse: true);
  }

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final isComic = AppTheme.currentStyle.value == ThemeStyle.comic3d;

    if (isComic) {
      return Container(
        width: widget.size,
        height: widget.size,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          color: widget.color,
          border: Border.all(
            color: Colors.black,
            width: widget.size * 0.18,
          ),
        ),
      );
    }

    return AnimatedBuilder(
      animation: _c,
      builder: (_, __) {
        final opacity = widget.pulse ? 0.5 + _c.value * 0.5 : 1.0;
        return Container(
          width: widget.size,
          height: widget.size,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: widget.color.withOpacity(opacity),
            boxShadow: [
              BoxShadow(
                color: widget.color.withOpacity(0.7 * opacity),
                blurRadius: widget.size * 1.2,
                spreadRadius: widget.size * 0.3,
              ),
              BoxShadow(
                color: widget.color.withOpacity(0.3 * opacity),
                blurRadius: widget.size * 2.5,
                spreadRadius: widget.size * 0.6,
              ),
              BoxShadow(
                color: Colors.white.withOpacity(0.6),
                offset: Offset(-widget.size * 0.15, -widget.size * 0.15),
                blurRadius: widget.size * 0.3,
              ),
            ],
          ),
        );
      },
    );
  }
}

class _Rivet extends StatelessWidget {
  final AppPalette C;
  final double size;
  const _Rivet({required this.C, this.size = 8});
  @override
  Widget build(BuildContext context) {
    if (AppTheme.currentStyle.value == ThemeStyle.comic3d) {
      return const SizedBox.shrink();
    }
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        gradient: RadialGradient(
          center: const Alignment(-0.4, -0.4),
          colors: [C.text, C.textSub, C.bg, C.bgDeep],
          stops: const [0.0, 0.35, 0.7, 1.0],
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.7),
            offset: const Offset(1, 1),
            blurRadius: 1.5,
          ),
          BoxShadow(
            color: Colors.white.withOpacity(0.2),
            offset: const Offset(-0.5, -0.5),
            blurRadius: 0.5,
          ),
        ],
      ),
    );
  }
}

class _Screw extends StatelessWidget {
  final AppPalette C;
  final double size;
  final double rotation;
  const _Screw({required this.C, this.size = 12, this.rotation = 0.785});
  @override
  Widget build(BuildContext context) {
    if (AppTheme.currentStyle.value == ThemeStyle.comic3d) {
      return const SizedBox.shrink();
    }
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        gradient: RadialGradient(
          center: const Alignment(-0.4, -0.4),
          colors: [C.text, C.textSub, C.bgDark, C.bgDeep],
          stops: const [0.0, 0.4, 0.75, 1.0],
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.8),
            offset: const Offset(1, 1.5),
            blurRadius: 2,
          ),
          BoxShadow(
            color: Colors.white.withOpacity(0.15),
            offset: const Offset(-0.5, -0.5),
            blurRadius: 0.5,
          ),
        ],
      ),
      child: Center(
        child: Transform.rotate(
          angle: rotation,
          child: Container(
            width: size * 0.65,
            height: 1.5,
            decoration: BoxDecoration(
              color: Colors.black.withOpacity(0.8),
              borderRadius: BorderRadius.circular(1),
            ),
          ),
        ),
      ),
    );
  }
}

class _TacticalPanel extends StatelessWidget {
  final AppPalette C;
  final Widget child;
  final EdgeInsets padding;
  final double radius;
  final Color? accent;
  final bool elevated;
  const _TacticalPanel({
    required this.C,
    required this.child,
    this.padding = const EdgeInsets.all(14),
    this.radius = 12,
    this.accent,
    this.elevated = true,
  });

  @override
  Widget build(BuildContext context) {
    final isComic = AppTheme.currentStyle.value == ThemeStyle.comic3d;
    final accentColor = accent ?? C.textSub;

    if (isComic) {
      return Container(
        padding: padding,
        decoration: BoxDecoration(
          color: C.bgDark,
          borderRadius: BorderRadius.circular(radius + 4),
          border: Border.all(color: Colors.black, width: 4),
          boxShadow: elevated
              ? const [
                  BoxShadow(
                    color: Colors.black,
                    offset: Offset(6, 6),
                    blurRadius: 0,
                  ),
                ]
              : null,
        ),
        child: child,
      );
    }

    return Container(
      padding: padding,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(radius),
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [C.bg, C.bgDark, C.bgDeep],
          stops: const [0.0, 0.5, 1.0],
        ),
        border: Border.all(
          color: accentColor,
          width: 1.2,
        ),
        boxShadow: elevated
            ? [
                BoxShadow(
                  color: Colors.black.withOpacity(0.75),
                  offset: const Offset(0, 6),
                  blurRadius: 12,
                ),
                BoxShadow(
                  color: Colors.white.withOpacity(0.05),
                  offset: const Offset(-1.5, -1.5),
                  blurRadius: 3,
                ),
                BoxShadow(
                  color: accentColor.withOpacity(0.15),
                  blurRadius: 16,
                ),
              ]
            : null,
      ),
      child: child,
    );
  }
}

class _DisplayPanel extends StatelessWidget {
  final AppPalette C;
  final Widget child;
  final EdgeInsets padding;
  final Color glowColor;
  final bool glow;
  const _DisplayPanel({
    required this.C,
    required this.child,
    this.padding = const EdgeInsets.all(12),
    this.glowColor = Colors.red,
    this.glow = false,
  });

  @override
  Widget build(BuildContext context) {
    final isComic = AppTheme.currentStyle.value == ThemeStyle.comic3d;
    final gc = glowColor;

    if (isComic) {
      return Container(
        padding: padding,
        decoration: BoxDecoration(
          color: C.bg,
          borderRadius: BorderRadius.circular(10),
          border: Border.all(color: Colors.black, width: 3),
        ),
        child: child,
      );
    }

    return Container(
      padding: padding,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(8),
        gradient: LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [C.bgDeep, C.bgDark],
        ),
        border: Border.all(
          color: glow ? gc.withOpacity(0.6) : C.bgDark,
          width: 1.5,
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.95),
            offset: const Offset(0, 3),
            blurRadius: 5,
          ),
          BoxShadow(
            color: Colors.white.withOpacity(0.08),
            offset: const Offset(0, -1),
            blurRadius: 1,
          ),
          if (glow)
            BoxShadow(
              color: gc.withOpacity(0.4),
              blurRadius: 14,
            ),
        ],
      ),
      child: child,
    );
  }
}

class _SectionHeader extends StatelessWidget {
  final AppPalette C;
  final String title;
  final IconData icon;
  final Color accent;
  final Widget? trailing;
  const _SectionHeader({
    required this.C,
    required this.title,
    required this.icon,
    this.accent = Colors.red,
    this.trailing,
  });

  @override
  Widget build(BuildContext context) {
    final isComic = AppTheme.currentStyle.value == ThemeStyle.comic3d;
    final ac = accent;

    if (isComic) {
      final textColor = C.contrastTextOn(C.primaryHi);
      return Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
        decoration: BoxDecoration(
          color: C.primaryHi,
          borderRadius: BorderRadius.circular(10),
          border: Border.all(color: Colors.black, width: 3),
          boxShadow: const [
            BoxShadow(
              color: Colors.black,
              offset: Offset(3, 3),
              blurRadius: 0,
            ),
          ],
        ),
        child: Row(
          children: [
            Icon(icon, color: textColor, size: 16),
            const SizedBox(width: 10),
            Expanded(
              child: Text(
                title,
                style: TextStyle(
                  color: textColor,
                  fontFamily: 'Bangers',
                  fontWeight: FontWeight.w900,
                  fontSize: 15,
                  letterSpacing: 1.5,
                  shadows: [
                    Shadow(
                      color: textColor == Colors.white
                          ? Colors.black
                          : Colors.white,
                      offset: const Offset(1, 1),
                      blurRadius: 0,
                    ),
                  ],
                ),
              ),
            ),
            if (trailing != null) trailing!,
          ],
        ),
      );
    }

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(6),
        gradient: LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [C.bg, C.bgDark, C.bgDeep],
        ),
        border: Border.all(color: C.bgDeep, width: 1),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.6),
            offset: const Offset(0, 2),
            blurRadius: 3,
          ),
          BoxShadow(
            color: Colors.white.withOpacity(0.08),
            offset: const Offset(0, -1),
            blurRadius: 1,
          ),
        ],
      ),
      child: Row(
        children: [
          Container(
            width: 24,
            height: 24,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(5),
              gradient: LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [ac, ac.withOpacity(0.6)],
              ),
              border: Border.all(
                color: ac.withOpacity(0.8),
                width: 1,
              ),
              boxShadow: [
                BoxShadow(
                  color: ac.withOpacity(0.4),
                  blurRadius: 6,
                ),
              ],
            ),
            child: Icon(icon, color: Colors.white, size: 13),
          ),
          const SizedBox(width: 8),
          Expanded(
            child: Text(
              title,
              style: TextStyle(
                color: C.text,
                fontFamily: 'Orbitron',
                fontWeight: FontWeight.w900,
                fontSize: 10,
                letterSpacing: 2,
                shadows: const [
                  Shadow(
                    color: Colors.black,
                    offset: Offset(0, 1),
                    blurRadius: 2,
                  ),
                ],
              ),
            ),
          ),
          if (trailing != null) trailing!,
          const SizedBox(width: 6),
          _Screw(C: C, size: 10, rotation: 0),
        ],
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════
// HOME PAGE
// ═══════════════════════════════════════════════════════════
class HomePage extends StatefulWidget {
  final String username;
  final String password;
  final String sessionKey;
  final List<Map<String, dynamic>> listBug;
  final String role;
  final String expiredDate;

  const HomePage({
    super.key,
    required this.username,
    required this.password,
    required this.sessionKey,
    required this.listBug,
    required this.role,
    required this.expiredDate,
  });

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> with TickerProviderStateMixin {
  late AnimationController _cursorCtrl;
  late AnimationController _sendCtrl;
  late AnimationController _orbitCtrl;
  late Animation<double> _sendScale;
  late Animation<double> _sendGlow;
  late Animation<double> _sendRotate;

  final targetController = TextEditingController();

  Timer? _senderTimer;
  Timer? _typeTimer;

  String? _selectedBugId;
  bool _isSending = false;
  String? _responseMessage;
  String _targetMode = 'number';

  List<String> _globalSenders = [];
  bool _isLoadingSenders = false;
  int _privateSenderCount = 0;
  int _globalSenderCount = 0;
  bool _loadingSender = false;

  String _selectedSender = 'private';

  // ═══ BUG SELECT MODE ═══
  // 'vertical' | 'horizontal' | 'orbit' | 'simple'
  String _bugMode = 'horizontal';
  bool _hasChosenBugMode = false;
  int _orbitCurrentIndex = 0;

  final List<Map<String, dynamic>> _bugModes = [
    {
      'id': 'vertical',
      'label': 'VERTICAL SCROLL',
      'desc': 'Scroll atas bawah kayak feed',
      'icon': Icons.view_agenda_rounded,
      'color': const Color(0xFF2196F3),
    },
    {
      'id': 'horizontal',
      'label': 'HORIZONTAL SWIPE',
      'desc': 'Geser kiri-kanan',
      'icon': Icons.swap_horiz_rounded,
      'color': const Color(0xFF9C27B0),
    },
    {
      'id': 'orbit',
      'label': 'ORBIT SPIN',
      'desc': 'Command berputar orbit',
      'icon': Icons.rotate_right_rounded,
      'color': const Color(0xFFFF9800),
    },
    {
      'id': 'simple',
      'label': 'SIMPLE GRID',
      'desc': 'Grid simpel bebas pilih',
      'icon': Icons.grid_view_rounded,
      'color': const Color(0xFF4CAF50),
    },
  ];

  VideoPlayerController? _bannerVideoCtrl;
  bool _bannerReady = false;

  String _typedText = "";
  int _typeIndex = 0;
  bool _isDeleting = false;

  bool get canAccessGlobalSender {
    final r = widget.role.toLowerCase();
    return r == 'developer' ||
        r == 'high owner' ||
        r == 'owner' ||
        r == 'moderator' ||
        r == 'patner';
  }

  // ═══ FILTER BUG BERDASARKAN TARGET MODE ═══
  // - mode 'number' → hanya bug yang TIDAK berakhiran '_group'
  // - mode 'group'  → hanya bug yang berakhiran '_group'
  List<Map<String, dynamic>> get _filteredBugs {
    final isGroup = _targetMode == 'group';
    return widget.listBug.where((bug) {
      final id = (bug['bug_id'] as String? ?? '').toLowerCase();
      final isGroupBug = id.endsWith('_group');
      return isGroup ? isGroupBug : !isGroupBug;
    }).toList();
  }

  // Helper: cari bug pertama yang cocok dengan target mode
  String? _firstBugIdForTarget(String targetMode) {
    final isGroup = targetMode == 'group';
    final filtered = widget.listBug.where((bug) {
      final id = (bug['bug_id'] as String? ?? '').toLowerCase();
      final isGroupBug = id.endsWith('_group');
      return isGroup ? isGroupBug : !isGroupBug;
    }).toList();
    if (filtered.isEmpty) return null;
    return filtered[0]['bug_id'] as String?;
  }

  @override
  void initState() {
    super.initState();

    _cursorCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 600),
    )..repeat(reverse: true);

    _sendCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 2400),
    );

    _orbitCtrl = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 20),
    )..repeat();

    _sendScale = TweenSequence<double>([
      TweenSequenceItem(
        tween: Tween(begin: 1.0, end: 1.04)
            .chain(CurveTween(curve: Curves.easeOut)),
        weight: 15,
      ),
      TweenSequenceItem(
        tween: Tween(begin: 1.04, end: 1.0)
            .chain(CurveTween(curve: Curves.easeIn)),
        weight: 15,
      ),
      TweenSequenceItem(
        tween: Tween(begin: 1.0, end: 0.97)
            .chain(CurveTween(curve: Curves.easeOut)),
        weight: 30,
      ),
      TweenSequenceItem(
        tween: Tween(begin: 0.97, end: 1.06)
            .chain(CurveTween(curve: Curves.elasticOut)),
        weight: 40,
      ),
    ]).animate(_sendCtrl);

    _sendGlow = Tween<double>(begin: 0.3, end: 1.0).animate(
      CurvedAnimation(
        parent: _sendCtrl,
        curve: const Interval(0.0, 0.4, curve: Curves.easeOut),
      ),
    );

    _sendRotate = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(
        parent: _sendCtrl,
        curve: const Interval(0.2, 0.8, curve: Curves.easeInOut),
      ),
    );

    _initBannerVideo();
    _fetchSenderStats();
    _loadGlobalSenders();

    _senderTimer = Timer.periodic(const Duration(seconds: 30), (_) {
      _fetchSenderStats();
    });

    // Set bug pertama sesuai target mode default (number)
    _selectedBugId = _firstBugIdForTarget(_targetMode);

    _startTypewriter();

    // Load saved bug mode
    _loadBugMode();

    // Tampilkan dialog pilihan mode setelah delay
    WidgetsBinding.instance.addPostFrameCallback((_) {
      Future.delayed(const Duration(milliseconds: 800), () {
        if (mounted && !_hasChosenBugMode) {
          _showBugModeDialog(AppTheme.current.value);
        }
      });
    });
  }

  void _initBannerVideo() {
    _bannerVideoCtrl = VideoPlayerController.asset('assets/videos/bug.mp4')
      ..initialize().then((_) {
        if (mounted) {
          setState(() => _bannerReady = true);
          _bannerVideoCtrl?.setLooping(true);
          _bannerVideoCtrl?.setVolume(1.0);
          _bannerVideoCtrl?.play();
        }
      }).catchError((_) {});
  }

  void _startTypewriter() {
    const fullText = "CONFLICT";
    _typeTimer?.cancel();
    _typeIndex = 0;
    _isDeleting = false;
    _typedText = "";

    _typeTimer = Timer.periodic(const Duration(milliseconds: 150), (timer) {
      if (!mounted) return;
      setState(() {
        if (!_isDeleting) {
          if (_typeIndex < fullText.length) {
            _typedText = fullText.substring(0, _typeIndex + 1);
            _typeIndex++;
          } else {
            _isDeleting = true;
            timer.cancel();
            Future.delayed(const Duration(seconds: 3), () {
              if (mounted) _startDeleting();
            });
          }
        }
      });
    });
  }

  void _startDeleting() {
    _typeTimer?.cancel();
    _typeTimer = Timer.periodic(const Duration(milliseconds: 80), (timer) {
      if (!mounted) return;
      setState(() {
        if (_typeIndex > 0) {
          _typedText = _typedText.substring(0, _typeIndex - 1);
          _typeIndex--;
        } else {
          timer.cancel();
          Future.delayed(const Duration(seconds: 2), () {
            if (mounted) _startTypewriter();
          });
        }
      });
    });
  }

  @override
  void dispose() {
    _cursorCtrl.dispose();
    _sendCtrl.dispose();
    _orbitCtrl.dispose();
    targetController.dispose();
    _senderTimer?.cancel();
    _typeTimer?.cancel();
    _bannerVideoCtrl?.dispose();
    super.dispose();
  }

  // ═══ SAVE / LOAD BUG MODE ═══
  Future<void> _saveBugMode(String mode) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('bug_select_mode', mode);
  }

  Future<void> _loadBugMode() async {
    final prefs = await SharedPreferences.getInstance();
    final saved = prefs.getString('bug_select_mode');
    if (saved != null && mounted) {
      setState(() {
        _bugMode = saved;
        _hasChosenBugMode = true;
      });
    }
  }

  void _showBugModeSnack(AppPalette C, String msg) {
    ScaffoldMessenger.of(context).hideCurrentSnackBar();
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(msg),
        backgroundColor: C.primaryHi,
        behavior: SnackBarBehavior.floating,
        duration: const Duration(seconds: 2),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════
  // API
  // ═══════════════════════════════════════════════════════════
  Future<void> _fetchSenderStats() async {
    if (_loadingSender) return;
    if (mounted) setState(() => _loadingSender = true);
    try {
      final response = await http
          .get(Uri.parse(
              "$baseUrl/getSenderStats?key=${widget.sessionKey}"))
          .timeout(const Duration(seconds: 10));
      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['valid'] == true && mounted) {
          setState(() {
            _privateSenderCount = data['private'] ?? 0;
            _globalSenderCount = data['global'] ?? 0;
            _loadingSender = false;
          });
          return;
        }
      }
    } catch (_) {}
    if (mounted) setState(() => _loadingSender = false);
  }

  Future<void> _loadGlobalSenders() async {
    if (mounted) setState(() => _isLoadingSenders = true);
    try {
      final res = await http
          .get(Uri.parse(
              '$baseUrl/getActiveSenders?key=${widget.sessionKey}'))
          .timeout(const Duration(seconds: 10));
      final data = jsonDecode(res.body);
      if (data['valid'] == true && data['senders'] != null && mounted) {
        setState(() {
          _globalSenders = List<String>.from(data['senders']);
          _globalSenderCount = _globalSenders.length;
        });
      }
    } catch (_) {}
    if (mounted) setState(() => _isLoadingSenders = false);
  }

  String? formatPhoneNumber(String input) {
    final cleaned = input.replaceAll(RegExp(r'[^\d+]'), '');
    if (!cleaned.startsWith('+') || cleaned.length < 8) return null;
    return cleaned;
  }

  bool isValidGroup(String input) {
    final groupRegex = RegExp(r'chat\.whatsapp\.com/([A-Za-z0-9]+)');
    final jidRegex = RegExp(r'^\d+@g\.us$');
    return groupRegex.hasMatch(input) || jidRegex.hasMatch(input);
  }

  void _setResponse(String type, String msg) {
    if (!mounted) return;
    setState(() => _responseMessage = '$type|$msg');
  }

  Future<void> _sendBug(AppPalette C) async {
    final rawInput = targetController.text.trim();
    final key = widget.sessionKey;
    final isNumberMode = _targetMode == 'number';

    if (isNumberMode) {
      if (formatPhoneNumber(rawInput) == null) {
        _showAlert(C, "Nomor Tidak Valid",
            "Gunakan format internasional.\nContoh: +62812xxxxxxxx");
        return;
      }
    } else {
      if (!isValidGroup(rawInput)) {
        _showAlert(C,
            "Group Tidak Valid",
            "Format harus link invite atau JID:\n"
            "• chat.whatsapp.com/XXXXX\n"
            "• 123456789@g.us");
        return;
      }
    }

    if (_selectedSender == 'global' && !canAccessGlobalSender) {
      _showAlert(C,
          "Akses Ditolak", "Sender Global Hanya Untuk Role Partner Ke Atas");
      return;
    }

    if (_selectedBugId == null || _selectedBugId!.isEmpty) {
      _showAlert(C, "No Bug Selected", "Pilih 1 bug untuk dikirim.");
      return;
    }

    // ═══ VALIDASI: bug harus cocok dengan target mode ═══
    final isGroupTarget = _targetMode == 'group';
    final bugIdLower = _selectedBugId!.toLowerCase();
    final isGroupBug = bugIdLower.endsWith('_group');

    if (isGroupTarget != isGroupBug) {
      _showAlert(
        C,
        "Bug Tidak Cocok",
        isGroupTarget
            ? "Target GROUP harus pakai bug *_group."
            : "Target NUMBER tidak boleh pakai bug *_group.",
      );
      return;
    }

    if (_selectedSender == 'private' && _privateSenderCount == 0) {
      _showAlert(C,
          "No Private Sender", "Tidak ada private sender tersedia.");
      return;
    }
    if (_selectedSender == 'global' && _globalSenderCount == 0) {
      _showAlert(C,
          "No Global Sender", "Tidak ada global sender tersedia.");
      return;
    }

    HapticFeedback.mediumImpact();
    _sendCtrl.forward(from: 0);

    setState(() {
      _isSending = true;
      _responseMessage = null;
    });

    final targetLabel = isNumberMode
        ? 'Nomor: $rawInput'
        : 'Group: ${rawInput.length > 35 ? '${rawInput.substring(0, 35)}...' : rawInput}';

    await SendBugLoading.show(
      context,
      targetLabel: targetLabel,
      countdownSeconds: 5,
      onProcess: () async {
        try {
          final encodedTarget = Uri.encodeComponent(rawInput);
          final res = await http.get(Uri.parse('$baseUrl/sendBug'
            '?key=$key'
            '&target=$encodedTarget'
            '&bug=$_selectedBugId'
            '${_selectedSender == 'global' ? '&senderMode=global' : '&sender=private'}',
          )).timeout(const Duration(seconds: 15));
          final data = jsonDecode(res.body);

          if (data['valid'] == false) {
            _setResponse('error', 'Session key tidak valid. Login ulang.');
            return false;
          } else if (data['cooldown'] == true) {
            _setResponse('warning',
                'Cooldown aktif! Tunggu ${data['wait'] ?? 0} detik.');
            return false;
          } else if (data['sended'] == true) {
            final label = isNumberMode ? 'nomor' : 'group';
            _setResponse(
                'success',
                'Bug berhasil dikirim ke $label $rawInput! '
                '[${data['role'] ?? widget.role}]');
            targetController.clear();
            HapticFeedback.heavyImpact();
            return true;
          } else {
            _setResponse('error', 'Gagal mengirim. Server maintenance.');
            return false;
          }
        } catch (e) {
          _setResponse('error', 'Koneksi error. Periksa jaringan.');
          return false;
        }
      },
    );

    if (mounted) setState(() => _isSending = false);
  }

  void _showAlert(AppPalette C, String title, String msg) {
    final isComic = AppTheme.currentStyle.value == ThemeStyle.comic3d;

    showDialog(
      context: context,
      barrierColor: Colors.black.withOpacity(0.85),
      builder: (_) => Dialog(
        backgroundColor: Colors.transparent,
        insetPadding: const EdgeInsets.symmetric(horizontal: 24),
        child: _TacticalPanel(
          C: C,
          padding: const EdgeInsets.all(20),
          accent: C.primaryHi,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Stack(
                alignment: Alignment.center,
                children: [
                  Container(
                    width: 56,
                    height: 56,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: isComic ? C.primaryHi : C.primaryLo,
                      border: Border.all(
                          color: isComic
                              ? Colors.black
                              : C.primaryHi.withOpacity(0.6),
                          width: isComic ? 4 : 1.5),
                    ),
                    child: Icon(
                      Icons.warning_amber_rounded,
                      color: isComic
                          ? C.contrastTextOn(C.primaryHi)
                          : C.primaryHi,
                      size: 26,
                    ),
                  ),
                  if (!isComic)
                    Positioned(
                      top: 0,
                      right: 0,
                      child: _Led(color: C.primaryHi, size: 10, pulse: true),
                    ),
                ],
              ),
              const SizedBox(height: 14),
              Text(
                title.toUpperCase(),
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: isComic ? C.comicText : C.text,
                  fontSize: isComic ? 15 : 12,
                  fontWeight: FontWeight.w900,
                  fontFamily: isComic ? 'Bangers' : 'Orbitron',
                  letterSpacing: isComic ? 1.5 : 2,
                  shadows: isComic
                      ? [
                          Shadow(
                            color: C.comicTextOutline,
                            offset: const Offset(1, 1),
                            blurRadius: 0,
                          ),
                        ]
                      : const [
                          Shadow(
                            color: Colors.black,
                            offset: Offset(0, 1),
                            blurRadius: 2,
                          ),
                        ],
                ),
              ),
              const SizedBox(height: 10),
              Text(
                msg,
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: isComic
                      ? C.comicText.withOpacity(0.85)
                      : C.text.withOpacity(0.7),
                  fontSize: 11,
                  fontFamily: isComic ? 'ComicNeue' : 'ShareTechMono',
                  fontWeight: FontWeight.w700,
                  height: 1.5,
                ),
              ),
              const SizedBox(height: 20),
              GestureDetector(
                onTap: () => Navigator.pop(context),
                child: Container(
                  padding: const EdgeInsets.symmetric(
                      horizontal: 40, vertical: 12),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(isComic ? 12 : 8),
                    gradient: isComic
                        ? null
                        : LinearGradient(
                            begin: Alignment.topCenter,
                            end: Alignment.bottomCenter,
                            colors: [C.primaryHi, C.primary, C.primaryLo],
                          ),
                    color: isComic ? C.primaryHi : null,
                    border: Border.all(
                      color: isComic ? Colors.black : C.primaryLo,
                      width: isComic ? 4 : 1.5,
                    ),
                    boxShadow: isComic
                        ? const [
                            BoxShadow(
                              color: Colors.black,
                              offset: Offset(4, 4),
                              blurRadius: 0,
                            ),
                          ]
                        : [
                            BoxShadow(
                              color: C.primaryHi.withOpacity(0.4),
                              blurRadius: 12,
                            ),
                            BoxShadow(
                              color: Colors.black.withOpacity(0.6),
                              offset: const Offset(0, 3),
                              blurRadius: 5,
                            ),
                          ],
                  ),
                  child: Text(
                    'OK',
                    style: TextStyle(
                      color: isComic
                          ? C.contrastTextOn(C.primaryHi)
                          : Colors.white,
                      fontSize: isComic ? 16 : 12,
                      fontWeight: FontWeight.w900,
                      fontFamily: isComic ? 'Bangers' : 'Orbitron',
                      letterSpacing: isComic ? 1.5 : 2.5,
                      shadows: isComic
                          ? [
                              Shadow(
                                color: C.contrastTextOn(C.primaryHi) ==
                                        Colors.white
                                    ? Colors.black
                                    : Colors.white,
                                offset: const Offset(1, 1),
                                blurRadius: 0,
                              ),
                            ]
                          : const [
                              Shadow(
                                color: Colors.black54,
                                offset: Offset(0, 1),
                                blurRadius: 2,
                              ),
                            ],
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════
  // DIALOG PILIH MODE BUG SELECT
  // ═══════════════════════════════════════════════════════════
  void _showBugModeDialog(AppPalette C) {
    final isComic = AppTheme.currentStyle.value == ThemeStyle.comic3d;
    HapticFeedback.mediumImpact();

    showDialog(
      context: context,
      barrierDismissible: false,
      barrierColor: Colors.black.withOpacity(0.9),
      builder: (dialogCtx) => Dialog(
        backgroundColor: Colors.transparent,
        insetPadding: const EdgeInsets.symmetric(horizontal: 20),
        child: _TacticalPanel(
          C: C,
          padding: const EdgeInsets.all(20),
          accent: C.primaryHi,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Row(
                children: [
                  _Led(color: C.primaryHi, size: 8, pulse: !isComic),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Text(
                      'PILIH MODE SELECT COMMAND',
                      style: TextStyle(
                        color: isComic ? C.comicText : C.accent,
                        fontSize: isComic ? 15 : 12,
                        fontWeight: FontWeight.w900,
                        fontFamily: isComic ? 'Bangers' : 'Orbitron',
                        letterSpacing: 1.5,
                        shadows: isComic
                            ? [
                                Shadow(
                                  color: C.comicTextOutline,
                                  offset: const Offset(1, 1),
                                  blurRadius: 0,
                                ),
                              ]
                            : null,
                      ),
                    ),
                  ),
                  _Led(color: C.accent, size: 8, pulse: !isComic),
                ],
              ),
              const SizedBox(height: 6),
              Text(
                'Pilih tampilan daftar command yang lu mau.\nBisa diganti kapan aja di menu Command.',
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: isComic
                      ? C.comicTextSub
                      : C.text.withOpacity(0.6),
                  fontSize: isComic ? 11 : 10,
                  fontFamily: isComic ? 'ComicNeue' : 'ShareTechMono',
                  height: 1.4,
                ),
              ),
              const SizedBox(height: 18),

              ..._bugModes.map((mode) {
                return Padding(
                  padding: const EdgeInsets.only(bottom: 10),
                  child: _buildBugModeTile(C, isComic, mode, dialogCtx),
                );
              }),

              const SizedBox(height: 6),
              Text(
                'Pilihan tersimpan di perangkat',
                style: TextStyle(
                  color: isComic
                      ? C.comicTextMuted
                      : C.text.withOpacity(0.4),
                  fontSize: 9,
                  fontFamily: isComic ? 'ComicNeue' : 'ShareTechMono',
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildBugModeTile(
    AppPalette C,
    bool isComic,
    Map<String, dynamic> mode,
    BuildContext dialogCtx,
  ) {
    final color = mode['color'] as Color;
    final isSelected = _bugMode == mode['id'];

    return GestureDetector(
      onTap: () {
        HapticFeedback.selectionClick();
        setState(() {
          _bugMode = mode['id'] as String;
          _hasChosenBugMode = true;
        });
        _saveBugMode(mode['id'] as String);
        Navigator.pop(dialogCtx);
        _showBugModeSnack(C, '${mode['label']} aktif');
      },
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 180),
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
        decoration: BoxDecoration(
          color: isComic
              ? (isSelected ? color : C.bg)
              : color.withOpacity(isSelected ? 0.2 : 0.08),
          borderRadius: BorderRadius.circular(isComic ? 14 : 12),
          border: Border.all(
            color: isComic ? Colors.black : color.withOpacity(0.5),
            width: isComic ? 3.5 : 1.5,
          ),
          boxShadow: isComic
              ? const [
                  BoxShadow(
                    color: Colors.black,
                    offset: Offset(4, 4),
                    blurRadius: 0,
                  ),
                ]
              : null,
        ),
        child: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: isComic
                    ? (isSelected ? C.bgDark : color)
                    : color.withOpacity(0.25),
                border: Border.all(
                  color: isComic ? Colors.black : color,
                  width: isComic ? 2.5 : 1,
                ),
              ),
              child: Icon(
                mode['icon'] as IconData,
                color: isComic
                    ? (isSelected
                        ? C.contrastTextOn(C.bgDark)
                        : C.contrastTextOn(color))
                    : color,
                size: 20,
              ),
            ),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    mode['label'] as String,
                    style: TextStyle(
                      color: isComic ? C.comicText : C.text,
                      fontSize: isComic ? 14 : 12,
                      fontWeight: FontWeight.w900,
                      fontFamily: isComic ? 'Bangers' : 'Orbitron',
                      letterSpacing: 1,
                      shadows: isComic
                          ? [
                              Shadow(
                                color: C.comicTextOutline,
                                offset: const Offset(1, 1),
                                blurRadius: 0,
                              ),
                            ]
                          : null,
                    ),
                  ),
                  const SizedBox(height: 2),
                  Text(
                    mode['desc'] as String,
                    style: TextStyle(
                      color: isComic
                          ? C.comicTextSub
                          : C.text.withOpacity(0.6),
                      fontSize: isComic ? 11 : 9,
                      fontFamily:
                          isComic ? 'ComicNeue' : 'ShareTechMono',
                    ),
                  ),
                ],
              ),
            ),
            if (isSelected)
              Icon(
                Icons.check_circle_rounded,
                color: isComic ? C.comicText : color,
                size: 22,
              ),
          ],
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════
  // TOP BAR
  // ═══════════════════════════════════════════════════════════
  Widget _buildTopBar(AppPalette C, bool isComic) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(14, 8, 14, 4),
      child: Container(
        height: 54,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(isComic ? 14 : 10),
          gradient: isComic
              ? null
              : LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [C.bg, C.bgDark, C.bgDeep],
                ),
          color: isComic ? C.bgDark : null,
          border: Border.all(
            color: isComic ? Colors.black : C.bgDeep,
            width: isComic ? 4 : 1.2,
          ),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.7),
              offset: const Offset(0, 4),
              blurRadius: isComic ? 0 : 8,
            ),
            if (isComic)
              const BoxShadow(
                color: Colors.black,
                offset: Offset(4, 4),
                blurRadius: 0,
              ),
          ],
        ),
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 10),
          child: Row(
            children: [
              if (!isComic) _Screw(C: C, size: 12),
              if (!isComic) const SizedBox(width: 8),
              _Led(color: C.primaryHi, size: 6, pulse: !isComic),
              const SizedBox(width: 8),
              Container(
                width: 32,
                height: 32,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: isComic
                      ? null
                      : RadialGradient(
                          center: const Alignment(-0.3, -0.3),
                          colors: [C.primaryHi, C.primary, C.primaryLo],
                        ),
                  color: isComic ? C.primaryHi : null,
                  border: Border.all(
                      color: isComic ? Colors.black : C.primaryLo,
                      width: isComic ? 3 : 1.5),
                  boxShadow: isComic
                      ? null
                      : [
                          BoxShadow(
                            color: C.primaryHi.withOpacity(0.4),
                            blurRadius: 10,
                          ),
                        ],
                ),
                child: Icon(Icons.shield_rounded,
                    color: isComic
                        ? C.contrastTextOn(C.primaryHi)
                        : Colors.white,
                    size: 16),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Row(
                  children: [
                    Flexible(
                      child: Text(
                        _typedText.isEmpty ? " " : _typedText,
                        style: TextStyle(
                          color: isComic ? C.comicText : C.text,
                          fontFamily: isComic ? 'Bangers' : 'Orbitron',
                          fontWeight: FontWeight.w900,
                          fontSize: isComic ? 16 : 13,
                          letterSpacing: isComic ? 1.5 : 2.5,
                          shadows: isComic
                              ? [
                                  Shadow(
                                    color: C.comicTextOutline,
                                    offset: const Offset(1, 1),
                                    blurRadius: 0,
                                  ),
                                ]
                              : [
                                  const Shadow(
                                    color: Colors.black,
                                    offset: Offset(0, 1),
                                    blurRadius: 2,
                                  ),
                                  Shadow(
                                    color: C.primary,
                                    offset: const Offset(0, 0),
                                    blurRadius: 8,
                                  ),
                                ],
                        ),
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                    FadeTransition(
                      opacity: _cursorCtrl,
                      child: Container(
                        width: 2,
                        height: 14,
                        margin: const EdgeInsets.only(left: 2),
                        color: isComic ? C.comicText : C.primaryHi,
                      ),
                    ),
                  ],
                ),
              ),
              Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(isComic ? 6 : 4),
                  gradient: isComic
                      ? null
                      : LinearGradient(
                          begin: Alignment.topCenter,
                          end: Alignment.bottomCenter,
                          colors: [C.textSub, C.bgDark],
                        ),
                  color: isComic ? C.accent : null,
                  border: Border.all(
                      color: isComic ? Colors.black : C.text,
                      width: isComic ? 2.5 : 1),
                  boxShadow: isComic
                      ? const [
                          BoxShadow(
                            color: Colors.black,
                            offset: Offset(2, 2),
                            blurRadius: 0,
                          ),
                        ]
                      : [
                          BoxShadow(
                            color: Colors.black.withOpacity(0.5),
                            offset: const Offset(0, 2),
                            blurRadius: 3,
                          ),
                        ],
                ),
                child: Text(
                  'V6.0',
                  style: TextStyle(
                    color: isComic
                        ? C.contrastTextOn(C.accent)
                        : C.text,
                    fontFamily: isComic ? 'Bangers' : 'Orbitron',
                    fontWeight: FontWeight.w900,
                    fontSize: isComic ? 11 : 9,
                    letterSpacing: 1.2,
                    shadows: isComic
                        ? [
                            Shadow(
                              color: C.contrastTextOn(C.accent) ==
                                      Colors.white
                                  ? Colors.black
                                  : Colors.white,
                              offset: const Offset(1, 1),
                              blurRadius: 0,
                            ),
                          ]
                        : null,
                  ),
                ),
              ),
              if (!isComic) const SizedBox(width: 8),
              if (!isComic) _Screw(C: C, size: 12, rotation: 0),
            ],
          ),
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════
  // BANNER VIDEO
  // ═══════════════════════════════════════════════════════════
  Widget _buildBannerVideo(AppPalette C, bool isComic) {
    return _TacticalPanel(
      C: C,
      padding: const EdgeInsets.all(4),
      accent: C.primaryHi.withOpacity(0.4),
      child: AspectRatio(
        aspectRatio: 16 / 9,
        child: ClipRRect(
          borderRadius: BorderRadius.circular(isComic ? 12 : 9),
          child: Stack(
            fit: StackFit.expand,
            children: [
              if (_bannerReady && _bannerVideoCtrl != null)
                FittedBox(
                  fit: BoxFit.cover,
                  child: SizedBox(
                    width: _bannerVideoCtrl!.value.size.width,
                    height: _bannerVideoCtrl!.value.size.height,
                    child: VideoPlayer(_bannerVideoCtrl!),
                  ),
                )
              else
                Container(
                  color: C.bgDeep,
                  child: Center(
                    child: CircularProgressIndicator(
                      color: C.primaryHi,
                      strokeWidth: 2,
                    ),
                  ),
                ),
              Container(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                    colors: [
                      Colors.black.withOpacity(0.55),
                      Colors.transparent,
                      Colors.transparent,
                      Colors.black.withOpacity(0.8),
                    ],
                    stops: const [0.0, 0.3, 0.7, 1.0],
                  ),
                ),
              ),
              Positioned(
                top: 10,
                left: 10,
                child: Container(
                  padding: const EdgeInsets.symmetric(
                      horizontal: 10, vertical: 5),
                  decoration: BoxDecoration(
                    borderRadius:
                        BorderRadius.circular(isComic ? 10 : 20),
                    color: Colors.black.withOpacity(0.75),
                    border: Border.all(
                        color: isComic ? Colors.white : C.textSub,
                        width: isComic ? 2 : 1),
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      _Led(color: C.primaryHi, size: 6, pulse: !isComic),
                      const SizedBox(width: 6),
                      Text(
                        'LIVE BANNER',
                        style: TextStyle(
                          color: C.text.withOpacity(0.9),
                          fontSize: isComic ? 11 : 9,
                          fontWeight: FontWeight.w900,
                          fontFamily: isComic ? 'Bangers' : 'Orbitron',
                          letterSpacing: 1.5,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              Positioned(
                left: 14,
                bottom: 12,
                right: 14,
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Row(
                            children: [
                              _Led(
                                  color: C.primaryHi,
                                  size: 5,
                                  pulse: !isComic),
                              const SizedBox(width: 6),
                              Text(
                                'WELCOME BACK',
                                style: TextStyle(
                                  color: C.accent.withOpacity(0.9),
                                  fontSize: isComic ? 11 : 9,
                                  fontWeight: FontWeight.w900,
                                  fontFamily:
                                      isComic ? 'Bangers' : 'Orbitron',
                                  letterSpacing: 2.5,
                                  shadows: const [
                                    Shadow(
                                        color: Colors.black,
                                        offset: Offset(0, 1),
                                        blurRadius: 2),
                                  ],
                                ),
                              ),
                            ],
                          ),
                          const SizedBox(height: 3),
                          Text(
                            widget.username.toUpperCase(),
                            style: TextStyle(
                              color: C.text,
                              fontSize: isComic ? 22 : 18,
                              fontWeight: FontWeight.w900,
                              fontFamily:
                                  isComic ? 'Bangers' : 'Orbitron',
                              letterSpacing: 1.5,
                              shadows: const [
                                Shadow(
                                    color: Colors.black,
                                    offset: Offset(0, 2),
                                    blurRadius: 4),
                              ],
                            ),
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                          ),
                        ],
                      ),
                    ),
                    Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 8, vertical: 3),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(4),
                        gradient: isComic
                            ? null
                            : LinearGradient(
                                colors: [C.primaryHi, C.primaryLo],
                              ),
                        color: isComic ? C.accent : null,
                        border: Border.all(
                            color: isComic ? Colors.black : C.accentHi,
                            width: isComic ? 2 : 1),
                      ),
                      child: Text(
                        widget.role.toUpperCase(),
                        style: TextStyle(
                          color: isComic
                              ? C.contrastTextOn(C.accent)
                              : C.accentShine,
                          fontSize: isComic ? 10 : 8,
                          fontWeight: FontWeight.w900,
                          fontFamily: isComic ? 'Bangers' : 'Orbitron',
                          letterSpacing: 1.5,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              if (!isComic)
                Positioned(top: 4, left: 4, child: _Rivet(C: C, size: 8)),
              if (!isComic)
                Positioned(top: 4, right: 4, child: _Rivet(C: C, size: 8)),
              if (!isComic)
                Positioned(bottom: 4, left: 4, child: _Rivet(C: C, size: 8)),
              if (!isComic)
                Positioned(bottom: 4, right: 4, child: _Rivet(C: C, size: 8)),
            ],
          ),
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════
  // TARGET PANEL
  // ═══════════════════════════════════════════════════════════
  Widget _buildTargetPanel(AppPalette C, bool isComic) {
    final isNumber = _targetMode == 'number';

    return _TacticalPanel(
      C: C,
      accent: C.primaryHi.withOpacity(0.4),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _SectionHeader(
            C: C,
            title: isNumber ? 'TARGET NUMBER' : 'TARGET GROUP',
            icon: isNumber
                ? Icons.phone_android_rounded
                : Icons.groups_rounded,
            accent: C.primaryHi,
          ),
          const SizedBox(height: 12),
          Container(
            padding: const EdgeInsets.all(4),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(isComic ? 10 : 8),
              color: isComic ? C.bg : Colors.black.withOpacity(0.5),
              border: Border.all(
                  color: isComic ? Colors.black : C.bgDark,
                  width: isComic ? 3 : 1),
            ),
            child: Row(
              children: [
                Expanded(
                  child: _TargetModeTab(
                    C: C,
                    icon: Icons.phone_android_rounded,
                    label: 'NUMBER',
                    color: C.primaryHi,
                    isSelected: isNumber,
                    isComic: isComic,
                    onTap: () {
                      HapticFeedback.selectionClick();
                      setState(() {
                        _targetMode = 'number';
                        targetController.clear();
                        // Reset bug ke bug number pertama
                        _selectedBugId = _firstBugIdForTarget('number');
                      });
                    },
                  ),
                ),
                const SizedBox(width: 4),
                Expanded(
                  child: _TargetModeTab(
                    C: C,
                    icon: Icons.groups_rounded,
                    label: 'GROUP',
                    color: C.primaryHi,
                    isSelected: !isNumber,
                    isComic: isComic,
                    onTap: () {
                      HapticFeedback.selectionClick();
                      setState(() {
                        _targetMode = 'group';
                        targetController.clear();
                        // Reset bug ke bug group pertama
                        _selectedBugId = _firstBugIdForTarget('group');
                      });
                    },
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 12),
          _DisplayPanel(
            C: C,
            glowColor: C.primaryHi,
            child: Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(7),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(isComic ? 6 : 6),
                    gradient: isComic
                        ? null
                        : LinearGradient(
                            begin: Alignment.topCenter,
                            end: Alignment.bottomCenter,
                            colors: [C.textSub, C.bgDark],
                          ),
                    color: isComic ? C.primaryHi : null,
                    border: Border.all(
                        color: isComic ? Colors.black : C.bgDeep,
                        width: isComic ? 2.5 : 1),
                  ),
                  child: Icon(
                    isNumber
                        ? Icons.language_rounded
                        : Icons.link_rounded,
                    color: isComic
                        ? C.contrastTextOn(C.primaryHi)
                        : C.primaryHi,
                    size: 13,
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: TextField(
                    controller: targetController,
                    onChanged: (_) => setState(() {}),
                    style: TextStyle(
                      color: isComic ? C.comicText : C.text,
                      fontFamily: isComic ? 'ComicNeue' : 'ShareTechMono',
                      fontSize: 13,
                      fontWeight: FontWeight.w700,
                      letterSpacing: 1.2,
                    ),
                    cursorColor: isComic ? C.comicText : C.primaryHi,
                    cursorWidth: 2,
                    keyboardType: isNumber
                        ? TextInputType.phone
                        : TextInputType.url,
                    maxLines: 1,
                    decoration: InputDecoration(
                      hintText: isNumber
                          ? '+62812XXXXXXXX'
                          : 'https://chat.whatsapp.com/XXXX',
                      hintStyle: TextStyle(
                        color: isComic
                            ? C.comicTextMuted
                            : C.text.withOpacity(0.3),
                        fontFamily:
                            isComic ? 'ComicNeue' : 'ShareTechMono',
                        fontSize: 11,
                        letterSpacing: 0.8,
                      ),
                      border: InputBorder.none,
                      contentPadding:
                          const EdgeInsets.symmetric(vertical: 16),
                    ),
                  ),
                ),
                if (targetController.text.isNotEmpty)
                  GestureDetector(
                    onTap: () {
                      HapticFeedback.lightImpact();
                      setState(() => targetController.clear());
                    },
                    child: Container(
                      padding: const EdgeInsets.all(6),
                      decoration: BoxDecoration(
                        shape: isComic ? BoxShape.rectangle : BoxShape.circle,
                        borderRadius: isComic
                            ? BorderRadius.circular(6)
                            : null,
                        color: isComic ? C.accent : C.bgDark,
                        border: Border.all(
                            color: isComic ? Colors.black : C.bg,
                            width: isComic ? 2 : 1),
                      ),
                      child: Icon(
                        Icons.close_rounded,
                        color: isComic
                            ? C.contrastTextOn(C.accent)
                            : C.text,
                        size: 12,
                      ),
                    ),
                  ),
              ],
            ),
          ),
          const SizedBox(height: 8),
          Row(
            children: [
              Icon(
                Icons.info_outline_rounded,
                color: isComic
                    ? C.comicTextSub
                    : C.text.withOpacity(0.5),
                size: 11,
              ),
              const SizedBox(width: 6),
              Expanded(
                child: Text(
                  isNumber
                      ? 'Format: +62812xxxx (internasional)'
                      : 'Paste link invite / JID group (contoh: chat.whatsapp.com/xxx)',
                  style: TextStyle(
                    color: isComic
                        ? C.comicTextSub
                        : C.text.withOpacity(0.5),
                    fontSize: 9,
                    fontFamily: isComic ? 'ComicNeue' : 'ShareTechMono',
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════
  // BUG PANEL — 4 MODE
  // ═══════════════════════════════════════════════════════════
  Widget _buildBugPanel(AppPalette C, bool isComic) {
    final badgeText = C.contrastTextOn(C.primaryHi);
    final bugs = _filteredBugs;

    return _TacticalPanel(
      C: C,
      accent: C.primaryHi.withOpacity(0.4),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _SectionHeader(
            C: C,
            title: 'SELECT COMMAND',
            icon: Icons.bug_report_rounded,
            accent: C.primaryHi,
            trailing: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                GestureDetector(
                  onTap: () => _showBugModeDialog(C),
                  child: Container(
                    padding: const EdgeInsets.all(5),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(isComic ? 6 : 4),
                      color: isComic ? C.accent : C.bgDark,
                      border: Border.all(
                        color: isComic ? Colors.black : C.accent,
                        width: isComic ? 2 : 1,
                      ),
                    ),
                    child: Icon(
                      Icons.tune_rounded,
                      color: isComic
                          ? C.contrastTextOn(C.accent)
                          : C.accent,
                      size: 11,
                    ),
                  ),
                ),
                const SizedBox(width: 6),
                Container(
                  padding: const EdgeInsets.symmetric(
                      horizontal: 6, vertical: 2),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(isComic ? 6 : 3),
                    color: isComic ? badgeText : C.primaryLo,
                    border: Border.all(
                      color: isComic
                          ? Colors.black
                          : C.primaryHi.withOpacity(0.6),
                      width: isComic ? 2 : 1,
                    ),
                  ),
                  child: Text(
                    '${bugs.length}',
                    style: TextStyle(
                      color: isComic ? C.primaryHi : C.primaryHi,
                      fontFamily: isComic ? 'Bangers' : 'Orbitron',
                      fontWeight: FontWeight.w900,
                      fontSize: isComic ? 12 : 8,
                      letterSpacing: 1,
                    ),
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 6),
          Row(
            children: [
              _Led(color: C.primaryHi, size: 4, pulse: !isComic),
              const SizedBox(width: 6),
              Expanded(
                child: Text(
                  'MODE: ${_bugMode.toUpperCase()} • TARGET: ${_targetMode.toUpperCase()}',
                  style: TextStyle(
                    color: isComic
                        ? C.comicTextSub
                        : C.accent.withOpacity(0.7),
                    fontSize: isComic ? 10 : 8,
                    fontFamily: isComic ? 'ComicNeue' : 'ShareTechMono',
                    fontWeight: FontWeight.w700,
                    letterSpacing: 1.5,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          _buildBugModeContent(C, isComic),
        ],
      ),
    );
  }

  Widget _buildBugModeContent(AppPalette C, bool isComic) {
    final bugs = _filteredBugs;
    switch (_bugMode) {
      case 'vertical':
        return _buildBugVertical(C, isComic, bugs);
      case 'orbit':
        return _buildBugOrbit(C, isComic, bugs);
      case 'simple':
        return _buildBugSimple(C, isComic, bugs);
      case 'horizontal':
      default:
        return _buildBugHorizontal(C, isComic, bugs);
    }
  }

  // Helper empty state
  Widget _buildEmptyBugState(AppPalette C, bool isComic) {
    final isGroup = _targetMode == 'group';
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 28, horizontal: 12),
      alignment: Alignment.center,
      child: Column(
        children: [
          Icon(
            Icons.inbox_rounded,
            color: isComic ? C.comicTextSub : C.text.withOpacity(0.4),
            size: 32,
          ),
          const SizedBox(height: 8),
          Text(
            isGroup
                ? 'Tidak ada bug GROUP tersedia'
                : 'Tidak ada bug NUMBER tersedia',
            textAlign: TextAlign.center,
            style: TextStyle(
              color: isComic ? C.comicTextSub : C.text.withOpacity(0.6),
              fontFamily: isComic ? 'ComicNeue' : 'ShareTechMono',
              fontSize: 11,
              fontWeight: FontWeight.w700,
            ),
          ),
        ],
      ),
    );
  }

  // MODE 1 — VERTICAL SCROLL
  Widget _buildBugVertical(
    AppPalette C,
    bool isComic,
    List<Map<String, dynamic>> bugs,
  ) {
    if (bugs.isEmpty) {
      return _buildEmptyBugState(C, isComic);
    }
    return SizedBox(
      height: 220,
      child: ListView.separated(
        physics: const BouncingScrollPhysics(),
        padding: const EdgeInsets.symmetric(horizontal: 2),
        itemCount: bugs.length,
        separatorBuilder: (_, __) => const SizedBox(height: 8),
        itemBuilder: (context, index) {
          final bug = bugs[index];
          final bugId = bug['bug_id'] as String? ?? '$index';
          final isSelected = _selectedBugId == bugId;

          return GestureDetector(
            onTap: () {
              HapticFeedback.selectionClick();
              setState(() => _selectedBugId = bugId);
            },
            child: Container(
              padding: const EdgeInsets.symmetric(
                  horizontal: 14, vertical: 12),
              decoration: BoxDecoration(
                color: isComic
                    ? (isSelected ? C.primaryHi : C.bg)
                    : (isSelected
                        ? C.primaryHi.withOpacity(0.2)
                        : C.bgDark),
                borderRadius: BorderRadius.circular(isComic ? 12 : 10),
                border: Border.all(
                  color: isComic
                      ? Colors.black
                      : (isSelected ? C.primaryHi : C.bgDark),
                  width: isComic ? 3 : (isSelected ? 1.5 : 1),
                ),
                boxShadow: isComic
                    ? const [
                        BoxShadow(
                          color: Colors.black,
                          offset: Offset(3, 3),
                          blurRadius: 0,
                        ),
                      ]
                    : null,
              ),
              child: Row(
                children: [
                  Container(
                    padding: const EdgeInsets.all(7),
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: isComic
                          ? (isSelected ? C.bgDark : C.primaryHi)
                          : C.primaryHi.withOpacity(0.2),
                      border: Border.all(
                        color: isComic ? Colors.black : C.primaryHi,
                        width: isComic ? 2 : 1,
                      ),
                    ),
                    child: Icon(
                      Icons.shield_rounded,
                      color: isComic
                          ? (isSelected
                              ? C.contrastTextOn(C.bgDark)
                              : C.contrastTextOn(C.primaryHi))
                          : C.primaryHi,
                      size: 14,
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          bugId.toUpperCase(),
                          style: TextStyle(
                            color: isComic ? C.comicText : C.text,
                            fontSize: isComic ? 14 : 12,
                            fontWeight: FontWeight.w900,
                            fontFamily:
                                isComic ? 'Bangers' : 'Orbitron',
                            letterSpacing: 1,
                          ),
                        ),
                        const SizedBox(height: 2),
                        Text(
                          'id: ${bugId.toLowerCase()}',
                          style: TextStyle(
                            color: isComic
                                ? C.comicTextSub
                                : C.text.withOpacity(0.5),
                            fontSize: isComic ? 10 : 8,
                            fontFamily: isComic
                                ? 'ComicNeue'
                                : 'ShareTechMono',
                          ),
                        ),
                      ],
                    ),
                  ),
                  if (isSelected)
                    Container(
                      padding: const EdgeInsets.all(4),
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: isComic ? C.accent : C.primaryHi,
                        border: Border.all(
                          color: isComic ? Colors.black : C.primaryHi,
                          width: isComic ? 2 : 1,
                        ),
                      ),
                      child: Icon(
                        Icons.check_rounded,
                        color: isComic
                            ? C.contrastTextOn(C.accent)
                            : Colors.white,
                        size: 12,
                      ),
                    ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }

  // MODE 2 — HORIZONTAL SWIPE
  Widget _buildBugHorizontal(
    AppPalette C,
    bool isComic,
    List<Map<String, dynamic>> bugs,
  ) {
    if (bugs.isEmpty) {
      return _buildEmptyBugState(C, isComic);
    }
    return SizedBox(
      height: 172,
      child: ListView.separated(
        scrollDirection: Axis.horizontal,
        physics: const BouncingScrollPhysics(),
        padding: const EdgeInsets.symmetric(horizontal: 2, vertical: 4),
        itemCount: bugs.length,
        separatorBuilder: (_, __) => const SizedBox(width: 10),
        itemBuilder: (context, index) {
          final bug = bugs[index];
          final bugId = bug['bug_id'] as String? ?? '$index';
          final isSelected = _selectedBugId == bugId;

          return _BugChip(
            C: C,
            bugId: bugId,
            isSelected: isSelected,
            isComic: isComic,
            onTap: () {
              HapticFeedback.selectionClick();
              setState(() => _selectedBugId = bugId);
            },
          );
        },
      ),
    );
  }

  // MODE 3 — ORBIT SPIN (FIXED)
  Widget _buildBugOrbit(
    AppPalette C,
    bool isComic,
    List<Map<String, dynamic>> bugs,
  ) {
    if (bugs.isEmpty) {
      return _buildEmptyBugState(C, isComic);
    }

    const double orbitRadius = 105.0;
    const double centerSize = 76.0;
    const double buttonSize = 72.0;
    const double containerHeight = 340.0;
    const double containerWidth = 320.0;

    return SizedBox(
      height: containerHeight,
      width: double.infinity,
      child: Center(
        child: SizedBox(
          width: containerWidth,
          height: containerHeight,
          child: Stack(
            alignment: Alignment.center,
            clipBehavior: Clip.none,
            children: [
              Container(
                width: orbitRadius * 2 + buttonSize * 0.8,
                height: orbitRadius * 2 + buttonSize * 0.8,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  border: Border.all(
                    color: isComic
                        ? Colors.black.withOpacity(0.15)
                        : C.primaryHi.withOpacity(0.15),
                    width: isComic ? 3 : 1.5,
                  ),
                ),
              ),
              Container(
                width: orbitRadius * 1.4,
                height: orbitRadius * 1.4,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  border: Border.all(
                    color: isComic
                        ? Colors.black.withOpacity(0.1)
                        : C.accent.withOpacity(0.1),
                    width: isComic ? 2 : 1,
                  ),
                ),
              ),

              AnimatedBuilder(
                animation: _orbitCtrl,
                builder: (_, __) {
                  final count = bugs.length;
                  final angleStep = (2 * math.pi) / count;

                  return Stack(
                    alignment: Alignment.center,
                    clipBehavior: Clip.none,
                    children: List.generate(count, (i) {
                      final bug = bugs[i];
                      final bugId = bug['bug_id'] as String? ?? '$i';
                      final isSelected = _selectedBugId == bugId;

                      final angle =
                          _orbitCtrl.value * 2 * math.pi + (i * angleStep);

                      final x = math.cos(angle) * orbitRadius;
                      final y = math.sin(angle) * orbitRadius;

                      final z = math.sin(angle);
                      final scale = 0.75 + ((z + 1) / 2) * 0.45;

                      return Positioned(
                        left: (containerWidth / 2) + x - (buttonSize / 2),
                        top: (containerHeight / 2) + y - (buttonSize / 2),
                        child: Transform.scale(
                          scale: scale,
                          child: GestureDetector(
                            behavior: HitTestBehavior.opaque,
                            onTap: () {
                              HapticFeedback.selectionClick();
                              setState(() {
                                _selectedBugId = bugId;
                                _orbitCurrentIndex = i;
                              });
                            },
                            child: Container(
                              width: buttonSize,
                              height: buttonSize,
                              alignment: Alignment.center,
                              decoration: BoxDecoration(
                                color: isComic
                                    ? (isSelected ? C.primaryHi : C.bgDark)
                                    : (isSelected ? C.primaryHi : C.bgDark),
                                borderRadius:
                                    BorderRadius.circular(isComic ? 12 : 10),
                                border: Border.all(
                                  color: isComic
                                      ? Colors.black
                                      : (isSelected
                                          ? Colors.white
                                          : C.primaryHi),
                                  width: isComic
                                      ? 3
                                      : (isSelected ? 2 : 1.5),
                                ),
                                boxShadow: isComic
                                    ? const [
                                        BoxShadow(
                                          color: Colors.black,
                                          offset: Offset(3, 3),
                                          blurRadius: 0,
                                        ),
                                      ]
                                    : [
                                        BoxShadow(
                                          color: C.primaryHi.withOpacity(
                                              isSelected ? 0.7 : 0.25),
                                          blurRadius:
                                              isSelected ? 16 : 6,
                                        ),
                                      ],
                              ),
                              child: Padding(
                                padding: const EdgeInsets.symmetric(
                                    horizontal: 4),
                                child: FittedBox(
                                  fit: BoxFit.scaleDown,
                                  child: Text(
                                    bugId.toUpperCase(),
                                    textAlign: TextAlign.center,
                                    style: TextStyle(
                                      color: isComic
                                          ? (isSelected
                                              ? C.contrastTextOn(
                                                  C.primaryHi)
                                              : C.comicText)
                                          : (isSelected
                                              ? Colors.white
                                              : C.text),
                                      fontSize: isComic ? 11 : 9,
                                      fontWeight: FontWeight.w900,
                                      fontFamily: isComic
                                          ? 'Bangers'
                                          : 'Orbitron',
                                      letterSpacing: 0.8,
                                      shadows: isComic
                                          ? [
                                              Shadow(
                                                color: isSelected
                                                    ? (C.contrastTextOn(
                                                                C.primaryHi) ==
                                                            Colors.white
                                                        ? Colors.black
                                                        : Colors.white)
                                                    : C.comicTextOutline,
                                                offset:
                                                    const Offset(1, 1),
                                                blurRadius: 0,
                                              ),
                                            ]
                                          : null,
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ),
                      );
                    }),
                  );
                },
              ),

              Container(
                width: centerSize,
                height: centerSize,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: isComic
                      ? C.primaryHi
                      : C.primaryHi.withOpacity(0.18),
                  border: Border.all(
                    color: isComic ? Colors.black : C.primaryHi,
                    width: isComic ? 4 : 1.5,
                  ),
                  boxShadow: isComic
                      ? const [
                          BoxShadow(
                            color: Colors.black,
                            offset: Offset(4, 4),
                            blurRadius: 0,
                          ),
                        ]
                      : [
                          BoxShadow(
                            color: C.primaryHi.withOpacity(0.4),
                            blurRadius: 16,
                          ),
                        ],
                ),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(
                      Icons.rotate_right_rounded,
                      color: isComic
                          ? C.contrastTextOn(C.primaryHi)
                          : C.primaryHi,
                      size: 20,
                    ),
                    const SizedBox(height: 2),
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 4),
                      child: FittedBox(
                        fit: BoxFit.scaleDown,
                        child: Text(
                          _selectedBugId?.toUpperCase() ?? '-',
                          textAlign: TextAlign.center,
                          style: TextStyle(
                            color: isComic
                                ? C.contrastTextOn(C.primaryHi)
                                : C.primaryHi,
                            fontSize: isComic ? 11 : 9,
                            fontWeight: FontWeight.w900,
                            fontFamily:
                                isComic ? 'Bangers' : 'Orbitron',
                            letterSpacing: 1,
                            shadows: isComic
                                ? [
                                    Shadow(
                                      color: C.contrastTextOn(
                                                  C.primaryHi) ==
                                              Colors.white
                                          ? Colors.black
                                          : Colors.white,
                                      offset: const Offset(1, 1),
                                      blurRadius: 0,
                                    ),
                                  ]
                                : null,
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // MODE 4 — SIMPLE GRID
  Widget _buildBugSimple(
    AppPalette C,
    bool isComic,
    List<Map<String, dynamic>> bugs,
  ) {
    if (bugs.isEmpty) {
      return _buildEmptyBugState(C, isComic);
    }
    return Wrap(
      spacing: 8,
      runSpacing: 8,
      children: bugs.map((bug) {
        final bugId = bug['bug_id'] as String? ?? '0';
        final isSelected = _selectedBugId == bugId;

        return GestureDetector(
          onTap: () {
            HapticFeedback.selectionClick();
            setState(() => _selectedBugId = bugId);
          },
          child: Container(
            padding:
                const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
            decoration: BoxDecoration(
              color: isComic
                  ? (isSelected ? C.primaryHi : C.bg)
                  : (isSelected
                      ? C.primaryHi.withOpacity(0.25)
                      : C.bgDark),
              borderRadius: BorderRadius.circular(isComic ? 10 : 8),
              border: Border.all(
                color: isComic
                    ? Colors.black
                    : (isSelected ? C.primaryHi : C.bgDark),
                width: isComic ? 3 : (isSelected ? 1.8 : 1),
              ),
              boxShadow: isComic
                  ? const [
                      BoxShadow(
                        color: Colors.black,
                        offset: Offset(3, 3),
                        blurRadius: 0,
                      ),
                    ]
                  : null,
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                if (isSelected) ...[
                  Icon(
                    Icons.check_circle_rounded,
                    color: isComic
                        ? C.contrastTextOn(C.primaryHi)
                        : C.primaryHi,
                    size: 12,
                  ),
                  const SizedBox(width: 6),
                ],
                Text(
                  bugId.toUpperCase(),
                  style: TextStyle(
                    color: isComic
                        ? (isSelected
                            ? C.contrastTextOn(C.primaryHi)
                            : C.comicText)
                        : (isSelected ? C.primaryHi : C.text),
                    fontSize: isComic ? 12 : 10,
                    fontWeight: FontWeight.w900,
                    fontFamily: isComic ? 'Bangers' : 'Orbitron',
                    letterSpacing: 1,
                  ),
                ),
              ],
            ),
          ),
        );
      }).toList(),
    );
  }

  // ═══════════════════════════════════════════════════════════
  // SENDER PANEL
  // ═══════════════════════════════════════════════════════════
  Widget _buildSenderPanel(AppPalette C, bool isComic) {
    return _TacticalPanel(
      C: C,
      accent: C.textSub,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _SectionHeader(
            C: C,
            title: 'SELECT SENDER',
            icon: Icons.swap_horiz_rounded,
            accent: C.primaryHi,
            trailing: GestureDetector(
              onTap: () {
                _fetchSenderStats();
                _loadGlobalSenders();
                HapticFeedback.lightImpact();
              },
              child: Container(
                width: 24,
                height: 24,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: isComic
                      ? null
                      : LinearGradient(
                          begin: Alignment.topLeft,
                          end: Alignment.bottomRight,
                          colors: [C.textSub, C.bgDark],
                        ),
                  color: isComic ? C.contrastTextOn(C.primaryHi) : null,
                  border: Border.all(
                      color: isComic ? Colors.black : C.bgDeep,
                      width: isComic ? 2 : 1),
                ),
                child: (_isLoadingSenders || _loadingSender)
                    ? Padding(
                        padding: const EdgeInsets.all(5),
                        child: CircularProgressIndicator(
                          strokeWidth: 2,
                          color: isComic ? C.primaryHi : C.primaryHi,
                        ),
                      )
                    : Icon(
                        Icons.refresh_rounded,
                        color: isComic ? C.primaryHi : C.text,
                        size: 13,
                      ),
              ),
            ),
          ),
          const SizedBox(height: 10),
          _DisplayPanel(
            C: C,
            glowColor: C.primaryHi,
            glow: !isComic && (_privateSenderCount + _globalSenderCount > 0),
            padding:
                const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
            child: Row(
              children: [
                _Led(color: C.primaryHi, size: 6, pulse: !isComic),
                const SizedBox(width: 8),
                Text(
                  _loadingSender
                      ? 'READING SYSTEM...'
                      : '${_privateSenderCount + _globalSenderCount} SENDER ONLINE',
                  style: TextStyle(
                    color: isComic ? C.comicText : C.primaryHi,
                    fontFamily: isComic ? 'Bangers' : 'Orbitron',
                    fontSize: isComic ? 11 : 9,
                    fontWeight: FontWeight.w900,
                    letterSpacing: 1.5,
                  ),
                ),
                const Spacer(),
                Container(
                  padding: const EdgeInsets.symmetric(
                      horizontal: 6, vertical: 2),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(isComic ? 5 : 3),
                    color: isComic ? C.accent : C.primaryLo,
                    border: Border.all(
                        color: isComic
                            ? Colors.black
                            : C.primaryHi.withOpacity(0.5),
                        width: isComic ? 2 : 1),
                  ),
                  child: Text(
                    'LIVE',
                    style: TextStyle(
                      color: isComic
                          ? C.contrastTextOn(C.accent)
                          : C.primaryHi,
                      fontFamily: isComic ? 'Bangers' : 'Orbitron',
                      fontSize: isComic ? 9 : 7,
                      fontWeight: FontWeight.w900,
                      letterSpacing: 1,
                    ),
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 12),
          Row(
            children: [
              Expanded(
                child: _SenderTile(
                  C: C,
                  icon: Icons.person_rounded,
                  title: 'PRIBADI',
                  count: _privateSenderCount,
                  isSelected: _selectedSender == 'private',
                  isLocked: false,
                  accent: C.primaryHi,
                  isComic: isComic,
                  onTap: () {
                    HapticFeedback.selectionClick();
                    setState(() => _selectedSender = 'private');
                  },
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: _SenderTile(
                  C: C,
                  icon: Icons.public_rounded,
                  title: 'GLOBAL',
                  count: _globalSenderCount,
                  isSelected: _selectedSender == 'global',
                  isLocked: !canAccessGlobalSender,
                  accent: C.accentHi,
                  isComic: isComic,
                  onTap: () {
                    if (!canAccessGlobalSender) {
                      _showAlert(C, 'Akses Ditolak',
                          'Sender Global Hanya Untuk Role Partner Ke Atas');
                      return;
                    }
                    HapticFeedback.selectionClick();
                    setState(() => _selectedSender = 'global');
                    _loadGlobalSenders();
                  },
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),
          if (_selectedSender == 'global' && _globalSenders.isNotEmpty)
            _DisplayPanel(
              C: C,
              padding: const EdgeInsets.all(10),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Icon(Icons.format_list_bulleted_rounded,
                          color: isComic ? C.comicText : C.accentHi,
                          size: 11),
                      const SizedBox(width: 6),
                      Text(
                        '${_globalSenders.length} ACTIVE SENDERS',
                        style: TextStyle(
                          color: isComic ? C.comicText : C.accentHi,
                          fontSize: 9,
                          fontFamily:
                              isComic ? 'Bangers' : 'Orbitron',
                          fontWeight: FontWeight.w900,
                          letterSpacing: 1.2,
                          shadows: isComic
                              ? [
                                  Shadow(
                                    color: C.comicTextOutline,
                                    offset: const Offset(1, 1),
                                    blurRadius: 0,
                                  ),
                                ]
                              : null,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 8),
                  ...(_globalSenders.take(3).map(
                        (s) => Padding(
                          padding: const EdgeInsets.only(bottom: 4),
                          child: Row(
                            children: [
                              _Led(color: C.primaryHi, size: 4),
                              const SizedBox(width: 8),
                              Expanded(
                                child: Text(
                                  s,
                                  style: TextStyle(
                                    color: isComic
                                        ? C.comicText
                                        : C.text,
                                    fontSize: 10,
                                    fontFamily: isComic
                                        ? 'ComicNeue'
                                        : 'ShareTechMono',
                                    fontWeight: FontWeight.w700,
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      )),
                ],
              ),
            )
          else
            Row(
              children: [
                _Led(color: C.accent, size: 5),
                const SizedBox(width: 8),
                Text(
                  'Sender Global CONFLICT One',
                  style: TextStyle(
                    color: isComic
                        ? C.comicTextSub
                        : C.text.withOpacity(0.55),
                    fontFamily: isComic ? 'ComicNeue' : 'ShareTechMono',
                    fontSize: 10,
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ],
            ),
        ],
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════
  // SPAM OTP CARD
  // ═══════════════════════════════════════════════════════════
  Widget _buildSpamOtpCard(AppPalette C, bool isComic) {
    final badgeText = C.contrastTextOn(C.primaryHi);
    return _TacticalPanel(
      C: C,
      accent: C.accentHi.withOpacity(0.5),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _SectionHeader(
            C: C,
            title: 'SPAM OTP',
            icon: Icons.sms_failed_rounded,
            accent: C.accentHi,
            trailing: Container(
              padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(isComic ? 6 : 3),
                color: isComic ? badgeText : C.primaryLo,
                border: Border.all(
                    color: isComic
                        ? Colors.black
                        : C.accentHi.withOpacity(0.6),
                    width: isComic ? 2 : 1),
              ),
              child: Text(
                'NEW',
                style: TextStyle(
                  color: isComic ? C.primaryHi : C.accentHi,
                  fontFamily: isComic ? 'Bangers' : 'Orbitron',
                  fontWeight: FontWeight.w900,
                  fontSize: isComic ? 11 : 8,
                  letterSpacing: 1.5,
                ),
              ),
            ),
          ),
          const SizedBox(height: 12),
          _buildOtpTile(
            C: C,
            isComic: isComic,
            icon: Icons.flash_on_rounded,
            title: 'OTP BURST',
            subtitle: '16 provider sekaligus',
            color: C.primaryHi,
            onTap: () {
              HapticFeedback.mediumImpact();
              Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => const SpamOTPPage()),
              );
            },
          ),
          const SizedBox(height: 8),
          _buildOtpTile(
            C: C,
            isComic: isComic,
            icon: Icons.phone_iphone_rounded,
            title: 'PAIRING WA',
            subtitle: 'Spam pairing WhatsApp',
            color: C.primaryHi,
            onTap: () {
              HapticFeedback.mediumImpact();
              Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => const SpamOTPPage()),
              );
            },
          ),
          const SizedBox(height: 10),
          Row(
            children: [
              Icon(Icons.info_outline_rounded,
                  color: isComic
                      ? C.comicTextSub
                      : C.text.withOpacity(0.5),
                  size: 11),
              const SizedBox(width: 6),
              Expanded(
                child: Text(
                  'Bisa spam 1 nomor atau banyak (pisah pake koma)',
                  style: TextStyle(
                    color: isComic
                        ? C.comicTextSub
                        : C.text.withOpacity(0.5),
                    fontSize: 9,
                    fontFamily: isComic ? 'ComicNeue' : 'ShareTechMono',
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildOtpTile({
    required AppPalette C,
    required bool isComic,
    required IconData icon,
    required String title,
    required String subtitle,
    required Color color,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 12),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(isComic ? 14 : 10),
          gradient: isComic
              ? null
              : LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [C.bg, C.bgDark, C.bgDeep],
                  stops: const [0.0, 0.5, 1.0],
                ),
          color: isComic ? C.bg : null,
          border: Border.all(
            color: isComic ? Colors.black : color.withOpacity(0.5),
            width: isComic ? 3.5 : 1.3,
          ),
          boxShadow: isComic
              ? const [
                  BoxShadow(
                    color: Colors.black,
                    offset: Offset(4, 4),
                    blurRadius: 0,
                  ),
                ]
              : [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.5),
                    offset: const Offset(0, 3),
                    blurRadius: 6,
                  ),
                  BoxShadow(
                    color: color.withOpacity(0.15),
                    blurRadius: 10,
                  ),
                ],
        ),
        child: Row(
          children: [
            Stack(
              alignment: Alignment.center,
              children: [
                Container(
                  width: 40,
                  height: 40,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    gradient: isComic
                        ? null
                        : RadialGradient(
                            center: const Alignment(-0.3, -0.3),
                            colors: [
                              color.withOpacity(0.4),
                              color.withOpacity(0.15),
                              Colors.black.withOpacity(0.85),
                            ],
                            stops: const [0.0, 0.5, 1.0],
                          ),
                    color: isComic ? color : null,
                    border: Border.all(
                        color: isComic
                            ? Colors.black
                            : color.withOpacity(0.6),
                        width: isComic ? 3 : 1.5),
                    boxShadow: isComic
                        ? null
                        : [
                            BoxShadow(
                              color: color.withOpacity(0.35),
                              blurRadius: 10,
                            ),
                          ],
                  ),
                  child: Icon(icon,
                      color: isComic
                          ? C.contrastTextOn(color)
                          : color,
                      size: 18),
                ),
                if (!isComic)
                  Positioned(
                    top: 0,
                    right: 0,
                    child: _Led(color: color, size: 6, pulse: true),
                  ),
              ],
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    style: TextStyle(
                      color: isComic ? C.comicText : C.text,
                      fontFamily: isComic ? 'Bangers' : 'Orbitron',
                      fontWeight: FontWeight.w900,
                      fontSize: isComic ? 15 : 12,
                      letterSpacing: isComic ? 1 : 1.2,
                      shadows: isComic
                          ? [
                              Shadow(
                                color: C.comicTextOutline,
                                offset: const Offset(1, 1),
                                blurRadius: 0,
                              ),
                            ]
                          : const [
                              Shadow(
                                color: Colors.black,
                                offset: Offset(0, 1),
                                blurRadius: 2,
                              ),
                            ],
                    ),
                  ),
                  const SizedBox(height: 3),
                  Text(
                    subtitle,
                    style: TextStyle(
                      color: isComic
                          ? C.comicTextSub
                          : C.text.withOpacity(0.6),
                      fontSize: 10,
                      fontFamily: isComic ? 'ComicNeue' : 'ShareTechMono',
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ],
              ),
            ),
            Container(
              padding: const EdgeInsets.all(6),
              decoration: BoxDecoration(
                shape: isComic ? BoxShape.rectangle : BoxShape.circle,
                borderRadius: isComic ? BorderRadius.circular(8) : null,
                color: isComic ? color : color.withOpacity(0.15),
                border: Border.all(
                    color: isComic
                        ? Colors.black
                        : color.withOpacity(0.5),
                    width: isComic ? 2.5 : 1),
              ),
              child: Icon(
                Icons.arrow_forward_ios_rounded,
                color: isComic ? C.contrastTextOn(color) : color,
                size: 12,
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════
  // SEND BUTTON
  // ═══════════════════════════════════════════════════════════
  Widget _buildSendButton(AppPalette C, bool isComic) {
    final textColor = isComic ? C.contrastTextOn(C.primaryHi) : Colors.white;
    return AnimatedBuilder(
      animation: _sendCtrl,
      builder: (context, _) {
        final isAnimating = _sendCtrl.isAnimating || _isSending;
        final scale = isAnimating ? _sendScale.value : 1.0;
        final glowAlpha = isAnimating ? _sendGlow.value : 0.35;
        final rotate = isAnimating ? _sendRotate.value * math.pi * 2 : 0.0;

        return Transform.scale(
          scale: scale,
          child: GestureDetector(
            onTap: _isSending ? null : () => _sendBug(C),
            child: Container(
              height: 64,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(isComic ? 16 : 12),
                gradient: isComic
                    ? null
                    : LinearGradient(
                        begin: Alignment.topCenter,
                        end: Alignment.bottomCenter,
                        colors: [
                          C.primaryHi,
                          C.primaryHi,
                          C.primary,
                          C.primaryLo
                        ],
                        stops: const [0.0, 0.25, 0.65, 1.0],
                      ),
                color: isComic ? C.primaryHi : null,
                border: Border.all(
                  color: isComic ? Colors.black : C.primaryLo,
                  width: isComic ? 5 : 2,
                ),
                boxShadow: isComic
                    ? const [
                        BoxShadow(
                          color: Colors.black,
                          offset: Offset(6, 6),
                          blurRadius: 0,
                        ),
                      ]
                    : [
                        BoxShadow(
                          color: C.primaryHi.withOpacity(glowAlpha),
                          blurRadius: 20 + (glowAlpha * 15),
                          spreadRadius: -2,
                        ),
                        BoxShadow(
                          color: Colors.black.withOpacity(0.7),
                          offset: const Offset(0, 6),
                          blurRadius: 10,
                        ),
                        const BoxShadow(
                          color: Colors.white38,
                          offset: Offset(0, -2),
                          blurRadius: 4,
                        ),
                      ],
              ),
              child: Stack(
                alignment: Alignment.center,
                children: [
                  if (!isComic)
                    Positioned(
                      top: 4,
                      left: 12,
                      right: 12,
                      child: Container(
                        height: 14,
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(7),
                          gradient: LinearGradient(
                            begin: Alignment.topCenter,
                            end: Alignment.bottomCenter,
                            colors: [
                              Colors.white.withOpacity(0.4),
                              Colors.transparent,
                            ],
                          ),
                        ),
                      ),
                    ),
                  if (isAnimating && !isComic)
                    Positioned.fill(
                      child: Padding(
                        padding: const EdgeInsets.all(6),
                        child: Transform.rotate(
                          angle: rotate,
                          child: CustomPaint(
                            painter: _SendRingPainter(
                              color: Colors.white.withOpacity(0.6),
                            ),
                          ),
                        ),
                      ),
                    ),
                  if (!isComic)
                    Positioned(top: 5, left: 5, child: _Rivet(C: C, size: 7)),
                  if (!isComic)
                    Positioned(top: 5, right: 5, child: _Rivet(C: C, size: 7)),
                  if (!isComic)
                    Positioned(bottom: 5, left: 5, child: _Rivet(C: C, size: 7)),
                  if (!isComic)
                    Positioned(bottom: 5, right: 5, child: _Rivet(C: C, size: 7)),
                  _isSending
                      ? Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            SizedBox(
                              width: 22,
                              height: 22,
                              child: CircularProgressIndicator(
                                color: textColor,
                                strokeWidth: 2.5,
                              ),
                            ),
                            const SizedBox(width: 12),
                            Text(
                              'TRANSMITTING...',
                              style: TextStyle(
                                color: textColor,
                                fontWeight: FontWeight.w900,
                                fontSize: isComic ? 17 : 13,
                                fontFamily:
                                    isComic ? 'Bangers' : 'Orbitron',
                                letterSpacing: isComic ? 1.5 : 2.5,
                                shadows: [
                                  Shadow(
                                    color: textColor == Colors.white
                                        ? Colors.black
                                        : Colors.white,
                                    offset: const Offset(0, 1),
                                    blurRadius: 3,
                                  ),
                                ],
                              ),
                            ),
                          ],
                        )
                      : Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Icon(
                              Icons.rocket_launch_rounded,
                              color: textColor,
                              size: 24,
                              shadows: [
                                Shadow(
                                  color: textColor == Colors.white
                                      ? Colors.black
                                      : Colors.white,
                                  offset: const Offset(0, 2),
                                  blurRadius: 4,
                                ),
                              ],
                            ),
                            const SizedBox(width: 12),
                            Text(
                              'SEND BUG',
                              style: TextStyle(
                                color: textColor,
                                fontWeight: FontWeight.w900,
                                fontSize: isComic ? 22 : 17,
                                fontFamily:
                                    isComic ? 'Bangers' : 'Orbitron',
                                letterSpacing: isComic ? 2 : 4,
                                shadows: [
                                  Shadow(
                                    color: textColor == Colors.white
                                        ? Colors.black
                                        : Colors.white,
                                    offset: const Offset(0, 2),
                                    blurRadius: 4,
                                  ),
                                ],
                              ),
                            ),
                            const SizedBox(width: 12),
                            _Led(
                                color: textColor,
                                size: 8,
                                pulse: !isComic),
                          ],
                        ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  // ═══════════════════════════════════════════════════════════
  // RESPONSE MESSAGE
  // ═══════════════════════════════════════════════════════════
  Widget _buildResponseMessage(AppPalette C, bool isComic) {
    if (_responseMessage == null) return const SizedBox.shrink();

    final parts = _responseMessage!.split('|');
    final type = parts[0];
    final msg = parts.length > 1 ? parts[1] : '';

    Color color;
    Color deepColor;
    IconData icon;
    String title;
    switch (type) {
      case 'success':
        color = C.primaryHi;
        deepColor = C.primaryLo;
        icon = Icons.check_circle_rounded;
        title = 'BERHASIL';
        break;
      case 'warning':
        color = C.accentHi;
        deepColor = C.primaryLo;
        icon = Icons.warning_rounded;
        title = 'PERINGATAN';
        break;
      default:
        color = C.primaryHi;
        deepColor = C.primaryLo;
        icon = Icons.error_rounded;
        title = 'GAGAL';
    }

    return Padding(
      padding: const EdgeInsets.only(top: 12),
      child: _TacticalPanel(
        C: C,
        accent: color.withOpacity(0.5),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                shape: isComic ? BoxShape.rectangle : BoxShape.circle,
                borderRadius: isComic ? BorderRadius.circular(8) : null,
                color: isComic ? color : deepColor,
                border: Border.all(
                    color: isComic
                        ? Colors.black
                        : color.withOpacity(0.6),
                    width: isComic ? 3 : 1.5),
              ),
              child: Icon(icon,
                  color: isComic ? C.contrastTextOn(color) : color,
                  size: 18),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    style: TextStyle(
                      color: isComic ? C.comicText : color,
                      fontFamily: isComic ? 'Bangers' : 'Orbitron',
                      fontSize: isComic ? 15 : 11,
                      fontWeight: FontWeight.w900,
                      letterSpacing: isComic ? 1 : 1.5,
                      shadows: isComic
                          ? [
                              Shadow(
                                color: C.comicTextOutline,
                                offset: const Offset(1, 1),
                                blurRadius: 0,
                              ),
                            ]
                          : const [
                              Shadow(
                                color: Colors.black,
                                offset: Offset(0, 1),
                                blurRadius: 2,
                              ),
                            ],
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    msg,
                    style: TextStyle(
                      color: isComic ? C.comicText : C.text,
                      fontFamily: isComic ? 'ComicNeue' : 'ShareTechMono',
                      fontSize: 10,
                      fontWeight: FontWeight.w700,
                      height: 1.5,
                    ),
                  ),
                ],
              ),
            ),
            GestureDetector(
              onTap: () => setState(() => _responseMessage = null),
              child: Container(
                padding: const EdgeInsets.all(5),
                decoration: BoxDecoration(
                  shape: isComic ? BoxShape.rectangle : BoxShape.circle,
                  borderRadius: isComic ? BorderRadius.circular(6) : null,
                  gradient: isComic
                      ? null
                      : LinearGradient(
                          colors: [C.textSub, C.bgDark],
                        ),
                  color: isComic ? C.accent : null,
                  border: Border.all(
                      color: isComic ? Colors.black : C.bgDeep,
                      width: isComic ? 2 : 1),
                ),
                child: Icon(Icons.close_rounded,
                    color: isComic
                        ? C.contrastTextOn(C.accent)
                        : C.text,
                    size: 11),
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════
  // BUILD - BACKGROUND FOTO DIUBAH DI SINI
  // ═══════════════════════════════════════════════════════════
  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<AppPalette>(
      valueListenable: AppTheme.current,
      builder: (context, C, _) {
        return ValueListenableBuilder<ThemeStyle>(
          valueListenable: AppTheme.currentStyle,
          builder: (context, style, __) {
            final isComic = style == ThemeStyle.comic3d;

            return Scaffold(
              backgroundColor: C.bgDeep,
              body: Container(
                decoration: BoxDecoration(
                  color: isComic ? C.bg : null,
                ),
                child: Stack(
                  children: [
                    // ═══════════════════════════════════════════
                    // BACKGROUND FOTO
                    // GANTI 'assets/images/background.jpg' dengan
                    // nama file foto kamu
                    // ═══════════════════════════════════════════
                    Positioned.fill(
                      child: Image.asset(
                        'assets/images/home.png',
                        fit: BoxFit.cover,
                        errorBuilder: (_, __, ___) => Container(
                          decoration: BoxDecoration(
                            color: isComic ? C.bg : null,
                            gradient: isComic
                                ? null
                                : LinearGradient(
                                    begin: Alignment.topCenter,
                                    end: Alignment.bottomCenter,
                                    colors: [C.bg, C.bgDark, C.bgDeep],
                                    stops: const [0.0, 0.5, 1.0],
                                  ),
                          ),
                        ),
                      ),
                    ),

                    // ═══ OVERLAY GELAP AGAR TEKS TERBACA ═══
                    Positioned.fill(
                      child: IgnorePointer(
                        child: Container(
                          decoration: BoxDecoration(
                            gradient: LinearGradient(
                              begin: Alignment.topCenter,
                              end: Alignment.bottomCenter,
                              colors: [
                                Colors.black.withOpacity(0.7),
                                Colors.black.withOpacity(0.5),
                                Colors.black.withOpacity(0.8),
                              ],
                              stops: const [0.0, 0.5, 1.0],
                            ),
                          ),
                        ),
                      ),
                    ),

                    // ═══ EFEK COMIC HALFTONE (opsional) ═══
                    if (isComic)
                      Positioned.fill(
                        child: IgnorePointer(
                          child: CustomPaint(
                            painter: _ComicBgPainter(
                                color: C.primaryLo.withOpacity(0.12)),
                          ),
                        ),
                      ),

                    // ═══ KONTEN ═══
                    SafeArea(
                      child: Column(
                        children: [
                          _buildTopBar(C, isComic),
                          Expanded(
                            child: SingleChildScrollView(
                              physics: const BouncingScrollPhysics(),
                              padding:
                                  const EdgeInsets.fromLTRB(14, 8, 14, 24),
                              child: Column(
                                crossAxisAlignment:
                                    CrossAxisAlignment.stretch,
                                children: [
                                  _buildBannerVideo(C, isComic),
                                  const SizedBox(height: 12),
                                  _buildSpamOtpCard(C, isComic),
                                  const SizedBox(height: 12),
                                  _buildTargetPanel(C, isComic),
                                  const SizedBox(height: 12),
                                  _buildBugPanel(C, isComic),
                                  const SizedBox(height: 12),
                                  _buildSenderPanel(C, isComic),
                                  const SizedBox(height: 20),
                                  _buildSendButton(C, isComic),
                                  _buildResponseMessage(C, isComic),
                                ],
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            );
          },
        );
      },
    );
  }
}

// ═══════════════════════════════════════════════════════════
// SEND RING PAINTER
// ═══════════════════════════════════════════════════════════
class _SendRingPainter extends CustomPainter {
  final Color color;
  _SendRingPainter({required this.color});

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = color
      ..strokeWidth = 2
      ..style = PaintingStyle.stroke
      ..strokeCap = StrokeCap.round;

    final rect = Rect.fromLTWH(2, 2, size.width - 4, size.height - 4);
    const segments = 8;
    const gap = 0.15;

    for (int i = 0; i < segments; i++) {
      final start = (i / segments) * 2 * math.pi + gap;
      final sweep = (1 / segments) * 2 * math.pi - gap * 2;
      canvas.drawArc(rect, start, sweep, false, paint);
    }
  }

  @override
  bool shouldRepaint(_SendRingPainter old) => old.color != color;
}

// ═══════════════════════════════════════════════════════════
// COMIC BG PAINTER
// ═══════════════════════════════════════════════════════════
class _ComicBgPainter extends CustomPainter {
  final Color color;
  const _ComicBgPainter({required this.color});

  @override
  void paint(Canvas canvas, Size size) {
    const spacing = 22.0;
    final paint = Paint()..color = color;
    for (double x = 0; x < size.width + spacing; x += spacing) {
      for (double y = 0; y < size.height + spacing; y += spacing) {
        canvas.drawCircle(Offset(x, y), 2.5, paint);
      }
    }
  }

  @override
  bool shouldRepaint(_ComicBgPainter old) => old.color != color;
}

// ═══════════════════════════════════════════════════════════
// BUG CHIP
// ═══════════════════════════════════════════════════════════
class _BugChip extends StatelessWidget {
  final AppPalette C;
  final String bugId;
  final bool isSelected;
  final bool isComic;
  final VoidCallback onTap;
  const _BugChip({
    required this.C,
    required this.bugId,
    required this.isSelected,
    required this.isComic,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final selectedTextColor =
        isComic ? C.contrastTextOn(C.primaryHi) : Colors.white;
    return GestureDetector(
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 180),
        width: 156,
        height: 164,
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(isComic ? 16 : 12),
          gradient: !isComic && isSelected
              ? LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [C.primaryHi, C.primary, C.primaryLo],
                  stops: const [0.0, 0.5, 1.0],
                )
              : (isComic
                  ? null
                  : LinearGradient(
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                      colors: [C.bg, C.bgDark, C.bgDeep],
                      stops: const [0.0, 0.5, 1.0],
                    )),
          color: isComic ? (isSelected ? C.primaryHi : C.bgDark) : null,
          border: Border.all(
            color: isComic
                ? Colors.black
                : (isSelected ? C.primaryHi : C.bgDark),
            width: isComic ? 3.5 : (isSelected ? 2.0 : 1.2),
          ),
          boxShadow: isComic
              ? const [
                  BoxShadow(
                    color: Colors.black,
                    offset: Offset(5, 5),
                    blurRadius: 0,
                  ),
                ]
              : [
                  BoxShadow(
                    color: isSelected
                        ? C.primaryHi.withOpacity(0.55)
                        : Colors.black.withOpacity(0.5),
                    offset: const Offset(0, 4),
                    blurRadius: isSelected ? 16 : 6,
                  ),
                ],
        ),
        child: Stack(
          children: [
            if (isSelected && !isComic) ...[
              Positioned(top: 3, left: 3, child: _Rivet(C: C, size: 5)),
              Positioned(top: 3, right: 3, child: _Rivet(C: C, size: 5)),
              Positioned(bottom: 3, left: 3, child: _Rivet(C: C, size: 5)),
              Positioned(bottom: 3, right: 3, child: _Rivet(C: C, size: 5)),
            ],
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.all(7),
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: isComic
                            ? (isSelected ? C.bgDark : C.primaryHi)
                            : Colors.black.withOpacity(0.4),
                        border: Border.all(
                          color: isComic
                              ? Colors.black
                              : (isSelected ? C.primaryHi : C.bg),
                          width: isComic ? 3 : 1.2,
                        ),
                      ),
                      child: Icon(
                        Icons.shield_rounded,
                        color: isComic
                            ? (isSelected
                                ? C.contrastTextOn(C.bgDark)
                                : C.contrastTextOn(C.primaryHi))
                            : (isSelected ? C.primaryHi : C.text),
                        size: 17,
                      ),
                    ),
                    const Spacer(),
                    if (isSelected)
                      Icon(
                        Icons.workspace_premium_rounded,
                        color: isComic
                            ? selectedTextColor
                            : C.accentHi,
                        size: 18,
                      ),
                  ],
                ),
                const Spacer(),
                Row(
                  children: [
                    _Led(
                      color: isComic
                          ? (isSelected
                              ? C.contrastTextOn(C.primaryHi)
                              : C.comicTextSub)
                          : (isSelected ? C.primaryHi : C.textSub),
                      size: 6,
                      pulse: isSelected && !isComic,
                    ),
                    const SizedBox(width: 6),
                    Text(
                      isSelected ? 'READY' : 'IDLE',
                      style: TextStyle(
                        color: isComic
                            ? (isSelected
                                ? selectedTextColor
                                : C.comicTextSub)
                            : (isSelected
                                ? C.primaryHi
                                : C.text.withOpacity(0.4)),
                        fontSize: isComic ? 10 : 8,
                        fontFamily: isComic ? 'Bangers' : 'Orbitron',
                        letterSpacing: 1.2,
                        fontWeight: FontWeight.w900,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 8),
                Text(
                  bugId.toUpperCase(),
                  style: TextStyle(
                    color: isComic
                        ? (isSelected ? selectedTextColor : C.comicText)
                        : (isSelected ? Colors.white : C.text),
                    fontFamily: isComic ? 'Bangers' : 'Orbitron',
                    fontWeight: FontWeight.w900,
                    fontSize: isComic ? 17 : 14,
                    letterSpacing: 1,
                    shadows: isComic
                        ? [
                            Shadow(
                              color: isSelected
                                  ? (selectedTextColor == Colors.white
                                      ? Colors.black
                                      : Colors.white)
                                  : C.comicTextOutline,
                              offset: const Offset(1, 1),
                              blurRadius: 0,
                            ),
                          ]
                        : (isSelected
                            ? const [
                                Shadow(
                                  color: Colors.black54,
                                  offset: Offset(0, 1),
                                  blurRadius: 2,
                                ),
                              ]
                            : null),
                  ),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
                const SizedBox(height: 4),
                Text(
                  'id: ${bugId.toLowerCase()}',
                  style: TextStyle(
                    color: isComic
                        ? (isSelected
                            ? selectedTextColor.withOpacity(0.75)
                            : C.comicTextSub)
                        : C.text.withOpacity(0.55),
                    fontFamily: isComic ? 'ComicNeue' : 'ShareTechMono',
                    fontSize: 9,
                    fontWeight: FontWeight.w700,
                  ),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════
// SENDER TILE
// ═══════════════════════════════════════════════════════════
class _SenderTile extends StatelessWidget {
  final AppPalette C;
  final IconData icon;
  final String title;
  final int count;
  final bool isSelected;
  final bool isLocked;
  final Color accent;
  final bool isComic;
  final VoidCallback onTap;

  const _SenderTile({
    required this.C,
    required this.icon,
    required this.title,
    required this.count,
    required this.isSelected,
    required this.isLocked,
    required this.accent,
    required this.isComic,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final selectedTextColor =
        isComic && isSelected ? C.contrastTextOn(accent) : Colors.white;
    return GestureDetector(
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 180),
        height: 124,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(isComic ? 14 : 10),
          gradient: !isComic && isSelected
              ? LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [
                    accent,
                    accent.withOpacity(0.7),
                    accent.withOpacity(0.4)
                  ],
                  stops: const [0.0, 0.5, 1.0],
                )
              : (isComic
                  ? null
                  : LinearGradient(
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                      colors: [C.bg, C.bgDark, C.bgDeep],
                      stops: const [0.0, 0.5, 1.0],
                    )),
          color: isComic ? (isSelected ? accent : C.bgDark) : null,
          border: Border.all(
            color: isComic
                ? Colors.black
                : (isSelected ? accent : C.bgDark),
            width: isComic ? 3.5 : (isSelected ? 1.5 : 1),
          ),
          boxShadow: isComic
              ? const [
                  BoxShadow(
                    color: Colors.black,
                    offset: Offset(5, 5),
                    blurRadius: 0,
                  ),
                ]
              : [
                  BoxShadow(
                    color: isSelected
                        ? accent.withOpacity(0.5)
                        : Colors.black.withOpacity(0.5),
                    offset: const Offset(0, 4),
                    blurRadius: isSelected ? 12 : 6,
                  ),
                ],
        ),
        child: Stack(
          children: [
            if (isSelected && !isComic) ...[
              Positioned(top: 4, left: 4, child: _Rivet(C: C, size: 5)),
              Positioned(top: 4, right: 4, child: _Rivet(C: C, size: 5)),
              Positioned(bottom: 4, left: 4, child: _Rivet(C: C, size: 5)),
              Positioned(bottom: 4, right: 4, child: _Rivet(C: C, size: 5)),
            ],
            if (isLocked)
              Positioned(
                top: 6,
                right: 6,
                child: Container(
                  width: 20,
                  height: 20,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: isComic ? C.bg : C.primaryLo,
                    border: Border.all(
                        color: isComic
                            ? Colors.black
                            : C.primaryHi.withOpacity(0.7),
                        width: isComic ? 2 : 1.2),
                  ),
                  child: Icon(Icons.lock_rounded,
                      color: isComic ? C.comicText : C.primaryHi,
                      size: 10),
                ),
              ),
            Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Stack(
                    alignment: Alignment.center,
                    children: [
                      Container(
                        width: 44,
                        height: 44,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          gradient: !isComic && isSelected
                              ? RadialGradient(
                                  center: const Alignment(-0.3, -0.3),
                                  colors: [
                                    Colors.white.withOpacity(0.4),
                                    accent.withOpacity(0.5),
                                    accent.withOpacity(0.3),
                                  ],
                                  stops: const [0.0, 0.5, 1.0],
                                )
                              : (isComic
                                  ? null
                                  : RadialGradient(
                                      center: const Alignment(-0.3, -0.3),
                                      colors: [
                                        C.textSub,
                                        C.bg,
                                        C.bgDeep,
                                      ],
                                      stops: const [0.0, 0.5, 1.0],
                                    )),
                          color: isComic
                              ? (isSelected ? C.bg : accent)
                              : null,
                          border: Border.all(
                            color: isComic
                                ? Colors.black
                                : (isSelected ? Colors.white : C.textSub),
                            width: isComic ? 3 : 1.5,
                          ),
                          boxShadow: isComic
                              ? null
                              : [
                                  BoxShadow(
                                    color: isSelected
                                        ? accent.withOpacity(0.6)
                                        : Colors.black.withOpacity(0.6),
                                    blurRadius: isSelected ? 12 : 4,
                                  ),
                                ],
                        ),
                        child: Icon(
                          icon,
                          color: isComic
                              ? (isSelected
                                  ? C.contrastTextOn(C.bg)
                                  : C.contrastTextOn(accent))
                              : (isSelected ? Colors.white : C.text),
                          size: 20,
                        ),
                      ),
                      if (!isComic)
                        Positioned(
                          top: 0,
                          right: 0,
                          child: _Led(
                            color: count > 0 ? C.primaryHi : C.primaryHi,
                            size: 8,
                            pulse: count > 0,
                          ),
                        ),
                    ],
                  ),
                  const SizedBox(height: 8),
                  Text(
                    title,
                    style: TextStyle(
                      color: isComic
                          ? (isSelected ? selectedTextColor : C.comicText)
                          : (isSelected ? Colors.white : C.text),
                      fontFamily: isComic ? 'Bangers' : 'Orbitron',
                      fontWeight: FontWeight.w900,
                      fontSize: isComic ? 13 : 10,
                      letterSpacing: isComic ? 1 : 1.5,
                      shadows: isComic
                          ? [
                              Shadow(
                                color: isComic && isSelected
                                    ? (selectedTextColor == Colors.white
                                        ? Colors.black
                                        : Colors.white)
                                    : C.comicTextOutline,
                                offset: const Offset(1, 1),
                                blurRadius: 0,
                              ),
                            ]
                          : const [
                              Shadow(
                                color: Colors.black54,
                                offset: Offset(0, 1),
                                blurRadius: 2,
                              ),
                            ],
                    ),
                  ),
                  const SizedBox(height: 4),
                  if (count == 0)
                    Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 6, vertical: 2),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(isComic ? 6 : 3),
                        color: isComic ? C.bg : C.primaryLo,
                        border: Border.all(
                            color: isComic
                                ? Colors.black
                                : C.primaryHi.withOpacity(0.5),
                            width: isComic ? 2 : 1),
                      ),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(Icons.close_rounded,
                              color: isComic
                                  ? C.comicText
                                  : C.primaryHi,
                              size: 8),
                          const SizedBox(width: 3),
                          Text(
                            'KOSONG',
                            style: TextStyle(
                              color: isComic
                                  ? C.comicText
                                  : C.primaryHi,
                              fontFamily:
                                  isComic ? 'Bangers' : 'Orbitron',
                              fontWeight: FontWeight.w900,
                              fontSize: isComic ? 9 : 7,
                              letterSpacing: 1,
                            ),
                          ),
                        ],
                      ),
                    )
                  else
                    Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 8, vertical: 3),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(isComic ? 6 : 3),
                        color: isComic
                            ? C.bg
                            : Colors.black.withOpacity(0.5),
                        border: Border.all(
                            color: isComic
                                ? Colors.black
                                : (isSelected ? Colors.white30 : C.textSub),
                            width: isComic ? 2 : 1),
                      ),
                      child: Text(
                        '$count SENDER',
                        style: TextStyle(
                          color: isComic
                              ? C.comicText
                              : (isSelected ? Colors.white : C.primaryHi),
                          fontFamily: isComic ? 'Bangers' : 'Orbitron',
                          fontWeight: FontWeight.w900,
                          fontSize: isComic ? 9 : 7,
                          letterSpacing: 1,
                        ),
                      ),
                    ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════
// TARGET MODE TAB
// ═══════════════════════════════════════════════════════════
class _TargetModeTab extends StatelessWidget {
  final AppPalette C;
  final IconData icon;
  final String label;
  final Color color;
  final bool isSelected;
  final bool isComic;
  final VoidCallback onTap;

  const _TargetModeTab({
    required this.C,
    required this.icon,
    required this.label,
    required this.color,
    required this.isSelected,
    required this.isComic,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final selectedTextColor =
        isComic && isSelected ? C.contrastTextOn(color) : Colors.white;
    return GestureDetector(
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 180),
        padding: const EdgeInsets.symmetric(vertical: 9),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(isComic ? 8 : 6),
          gradient: !isComic && isSelected
              ? LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [
                    color,
                    color.withOpacity(0.7),
                    color.withOpacity(0.4),
                  ],
                )
              : null,
          color: isComic && isSelected ? color : null,
          border: Border.all(
            color: isComic
                ? (isSelected ? Colors.black : Colors.transparent)
                : (isSelected ? color.withOpacity(0.9) : C.bg),
            width: isComic ? 3 : (isSelected ? 1.5 : 1),
          ),
          boxShadow: isComic && isSelected
              ? const [
                  BoxShadow(
                    color: Colors.black,
                    offset: Offset(3, 3),
                    blurRadius: 0,
                  ),
                ]
              : (!isComic && isSelected
                  ? [
                      BoxShadow(
                        color: color.withOpacity(0.5),
                        blurRadius: 10,
                      ),
                    ]
                  : null),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              icon,
              color: isComic
                  ? (isSelected
                      ? selectedTextColor
                      : C.comicTextSub)
                  : (isSelected ? Colors.white : C.text),
              size: isComic ? 15 : 13,
              shadows: isComic
                  ? [
                      Shadow(
                        color: isComic && isSelected
                            ? (selectedTextColor == Colors.white
                                ? Colors.black
                                : Colors.white)
                            : C.comicTextOutline,
                        offset: const Offset(1, 1),
                        blurRadius: 0,
                      ),
                    ]
                  : (isSelected
                      ? const [
                          Shadow(
                            color: Colors.black54,
                            offset: Offset(0, 1),
                            blurRadius: 2,
                          ),
                        ]
                      : null),
            ),
            const SizedBox(width: 6),
            Text(
              label,
              style: TextStyle(
                color: isComic
                    ? (isSelected
                        ? selectedTextColor
                        : C.comicTextSub)
                    : (isSelected ? Colors.white : C.text),
                fontFamily: isComic ? 'Bangers' : 'Orbitron',
                fontWeight: FontWeight.w900,
                fontSize: isComic ? 12 : 10,
                letterSpacing: isComic ? 1 : 1.5,
                shadows: isComic
                    ? [
                        Shadow(
                          color: isComic && isSelected
                              ? (selectedTextColor == Colors.white
                                  ? Colors.black
                                  : Colors.white)
                              : C.comicTextOutline,
                          offset: const Offset(1, 1),
                          blurRadius: 0,
                        ),
                      ]
                    : (isSelected
                        ? const [
                            Shadow(
                              color: Colors.black54,
                              offset: Offset(0, 1),
                              blurRadius: 2,
                            ),
                          ]
                        : null),
              ),
            ),
            if (isSelected && !isComic) ...[
              const SizedBox(width: 5),
              const _Led(color: Colors.white, size: 5),
            ],
          ],
        ),
      ),
    );
  }
}