// by @zasaco
import 'package:flutter/material.dart';
import 'dart:math';
import 'dart:async';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'app_theme.dart';

// ============================================================
//  🎨 CARTOON COLORS — ADAPTIVE ke AppTheme
// ============================================================
class CartoonColors {
  static bool get _isComic =>
      AppTheme.currentStyle.value == ThemeStyle.comic3d;

  static AppPalette get _C => AppTheme.current.value;

  static Color get bgMain => _isComic ? _C.bg : const Color(0xFFFFFFFF);
  static Color get bgCard => _isComic ? _C.bgDark : const Color(0xFFFFFDF7);
  static Color get textMain =>
      _isComic ? _C.comicText : const Color(0xFF0A0A0A);
  static Color get textSub =>
      _isComic ? _C.comicTextSub : const Color(0xFF52525B);
  static Color get textMuted =>
      _isComic ? _C.comicTextMuted : const Color(0xFF71717A);
  static Color get outline =>
      _isComic ? Colors.black : const Color(0xFF000000);
  static Color get successGreen =>
      _isComic ? _C.primaryHi : const Color(0xFF22C55E);
  static Color get dangerPink =>
      _isComic ? _C.primaryHi : const Color(0xFFEF4444);
  static Color get warningYellow =>
      _isComic ? _C.accent : const Color(0xFFFBBF24);
  static Color get btnBlueLight =>
      _isComic ? _C.accent : const Color(0xFF38BDF8);
  static Color get btnBlueDark =>
      _isComic ? _C.primary : const Color(0xFF1E40AF);

  /// Text di atas button berwarna
  static Color textOnButton(Color bg) {
    if (!_isComic) return Colors.white;
    return _C.contrastTextOn(bg);
  }

  /// Text di atas surface putih (input comic)
  static Color get textOnInput =>
      _isComic ? Colors.black : textMain;

  /// Text di atas card (bgCard)
  static Color get textOnCard => _isComic ? _C.comicText : textMain;

  static String get fontFamily => _isComic ? 'Bangers' : 'Orbitron';
  static String get fontFamilySub => _isComic ? 'ComicNeue' : 'ShareTechMono';
}

// ============================================================
//  SPAM OTP PAGE — API KAMU
// ============================================================
class SpamOTPPage extends StatefulWidget {
  const SpamOTPPage({super.key});
  @override
  State<SpamOTPPage> createState() => _SpamOTPPageState();
}

class _SpamOTPPageState extends State<SpamOTPPage> {
  static const String _kBase = 'https://spamotp-api-eef5f0834c07.herokuapp.com';

  final TextEditingController phoneController = TextEditingController();

  bool isRunning = false;
  bool shouldStop = false;
  int totalSuccess = 0;
  int totalError = 0;
  int totalRequests = 0;
  int currentLoop = 0;
  int totalLoops = 10;
  int delayMs = 1000;
  String currentStatus = 'Menunggu...';
  double progress = 0.0;
  List<String> logs = [];
  bool isBannedMode = false;
  final ScrollController _logScrollController = ScrollController();

  final Random _random = Random();

  String _normalizePhone(String phone) {
    String cleaned = phone.replaceAll(RegExp(r'[^0-9+]'), '');
    if (cleaned.startsWith('+')) return cleaned.replaceFirst('+', '');
    if (cleaned.startsWith('0')) return '62${cleaned.substring(1)}';
    return cleaned;
  }

  Future<List<Map<String, dynamic>>> _getOTPEndpoints(String phone) async {
    final String basePhone = phone.startsWith('62') ? phone : '62$phone';
    try {
      await http
          .get(Uri.parse('$_kBase/health'))
          .timeout(const Duration(seconds: 10));
    } catch (_) {
      _addLog('⚠️ Server sedang tidak merespons, coba lagi nanti', type: 'info');
    }

    return [
      {
        'url': '$_kBase/api/$basePhone?mode=single',
        'method': 'GET',
        'label': 'OTP Burst 16 Provider',
      },
      {
        'url': '$_kBase/api/$basePhone?mode=pairing',
        'method': 'GET',
        'label': 'Pairing WA Spam',
      },
    ];
  }

  Future<bool> _sendRequest(Map<String, dynamic> endpoint, int delayMs) async {
    if (isBannedMode) {
      await Future.delayed(
          Duration(milliseconds: isRunning ? delayMs ~/ 3 : delayMs));
      return true;
    }

    await Future.delayed(Duration(milliseconds: delayMs));

    try {
      final uri = Uri.parse(endpoint['url']);
      final response = await http.get(uri).timeout(
        const Duration(seconds: 15),
        onTimeout: () => http.Response('{"status":"timeout"}', 408),
      );

      if ([200, 201, 202].contains(response.statusCode)) {
        try {
          final data = jsonDecode(response.body);
          if (data is Map<String, dynamic>) {
            if (data['success'] == true) return true;
            if (data['status'] == 'running') return true;
            if (data['status'] == 'ok') return true;
          }
        } catch (_) {}
        return true;
      }
      return false;
    } catch (e) {
      return false;
    }
  }

  void _addLog(String message, {String type = 'info'}) {
    String time = DateTime.now().toString().substring(11, 19);
    setState(() {
      logs.add('[$time] $message');
      if (logs.length > 500) logs.removeAt(0);
    });
    _scrollToBottom();
  }

  void _scrollToBottom() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_logScrollController.hasClients) {
        _logScrollController.animateTo(
          _logScrollController.position.maxScrollExtent,
          duration: const Duration(milliseconds: 200),
          curve: Curves.easeOut,
        );
      }
    });
  }

  Future<void> _startSpam() async {
    if (isRunning) return;

    String phoneRaw = phoneController.text.trim();
    if (phoneRaw.isEmpty) {
      _addLog('❌ Masukkan nomor target!', type: 'error');
      return;
    }

    List<String> phones = phoneRaw
        .split(',')
        .map((p) => p.trim())
        .where((p) => p.isNotEmpty)
        .toList();

    if (phones.isEmpty) {
      _addLog('❌ Masukkan minimal 1 nomor!', type: 'error');
      return;
    }

    for (int i = 0; i < phones.length; i++) {
      phones[i] = _normalizePhone(phones[i]);
    }

    setState(() {
      isRunning = true;
      shouldStop = false;
      totalSuccess = 0;
      totalError = 0;
      totalRequests = 0;
      currentLoop = 0;
      progress = 0.0;
      currentStatus = 'Memulai spam...';
    });

    var endpoints = await _getOTPEndpoints(phones[0]);
    int totalPhones = phones.length;
    int totalJobs = totalPhones * totalLoops * endpoints.length;
    int currentJob = 0;

    _addLog('🚀 Spam ke ${phones.length} nomor ($totalLoops× masing-masing)');
    _addLog('📡 API: $_kBase');
    _addLog('🔌 ${endpoints.length} mode tersedia');

    if (isBannedMode) {
      _addLog('🚫 BANNED MODE: Simulasi aktif', type: 'banned');
    }

    for (int p = 0; p < phones.length; p++) {
      if (shouldStop) {
        _addLog('🛑 Dihentikan!', type: 'error');
        break;
      }

      String phone = phones[p];
      setState(() {
        currentStatus = '📞 Memproses: $phone (${p + 1}/${phones.length})';
      });

      for (int loop = 1; loop <= totalLoops; loop++) {
        if (shouldStop) break;
        int loopSuccess = 0;
        int loopError = 0;

        for (int i = 0; i < endpoints.length; i++) {
          if (shouldStop) break;

          bool result = await _sendRequest(endpoints[i], delayMs);

          if (result) {
            loopSuccess++;
            totalSuccess++;
          } else {
            loopError++;
            totalError++;
          }
          totalRequests++;
          currentJob++;

          if (mounted) {
            setState(() {
              progress = (currentJob / totalJobs) * 100;
              currentLoop = loop;
            });
          }

          _addLog(
            '📞 $phone | Lp$loop → ${endpoints[i]['label']} | ${result ? "✅" : "❌"}',
            type: isBannedMode ? 'banned' : (result ? 'success' : 'error'),
          );

          if (!shouldStop && !isBannedMode) {
            await Future.delayed(const Duration(milliseconds: 300));
          }
        }

        _addLog('📞 $phone Loop $loop selesai! ✅ $loopSuccess ❌ $loopError');
      }

      _addLog('✅ Selesai: $phone | Total ✅ $totalSuccess ❌ $totalError');
    }

    if (mounted) {
      setState(() {
        isRunning = false;
        progress = 100;
        currentStatus = '✅ Selesai! ✅ $totalSuccess ❌ $totalError';
      });
    }

    if (isBannedMode) {
      _addLog('🚫 BANNED SELESAI — Simulasi selesai', type: 'banned');
    } else {
      _addLog('🎯 SELESAI TOTAL! ✅ $totalSuccess ❌ $totalError',
          type: 'success');
    }
  }

  void _stopSpam() {
    if (isRunning) {
      setState(() => shouldStop = true);
      _addLog('🛑 Menghentikan...', type: 'error');
    }
  }

  List<BoxShadow> get _hardShadow => const [
        BoxShadow(
            color: Color(0xFF000000), offset: Offset(4, 4), blurRadius: 0),
      ];
  List<BoxShadow> get _hardShadowSmall => const [
        BoxShadow(
            color: Color(0xFF000000), offset: Offset(2.5, 2.5), blurRadius: 0),
      ];

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<AppPalette>(
      valueListenable: AppTheme.current,
      builder: (context, C, _) {
        return ValueListenableBuilder<ThemeStyle>(
          valueListenable: AppTheme.currentStyle,
          builder: (context, style, __) {
            final isComic = style == ThemeStyle.comic3d;

            return Scaffold(
              backgroundColor: CartoonColors.bgMain,
              body: Stack(
                children: [
                  if (isComic)
                    Positioned.fill(
                      child: CustomPaint(
                        painter: _ComicHalftonePainter(
                            color: C.primaryLo.withOpacity(0.12)),
                      ),
                    ),
                  SafeArea(
                    child: Padding(
                      padding: const EdgeInsets.all(16.0),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          _buildHeader(isComic),
                          const SizedBox(height: 6),
                          _buildApiBanner(isComic, C),
                          const SizedBox(height: 16),
                          _buildPhoneLabel(isComic),
                          const SizedBox(height: 6),
                          _buildPhoneInput(isComic),
                          const SizedBox(height: 4),
                          Text('Pisahkan dengan koma (,)',
                              style: TextStyle(
                                fontSize: 10,
                                color: CartoonColors.textSub
                                    .withOpacity(0.6),
                                fontFamily: CartoonColors.fontFamilySub,
                              )),
                          const SizedBox(height: 12),
                          _buildLoopDelayRow(isComic, C),
                          const SizedBox(height: 12),
                          _buildActionButtons(isComic),
                          const SizedBox(height: 12),
                          if (isRunning || progress > 0)
                            _buildProgressCard(isComic, C),
                          const SizedBox(height: 8),
                          Expanded(child: _buildLogPanel(isComic, C)),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            );
          },
        );
      },
    );
  }

  Widget _buildHeader(bool isComic) {
    return Row(
      children: [
        Text(
          '📱 Spam OTP',
          style: TextStyle(
            fontSize: 22,
            fontWeight: FontWeight.w900,
            color: CartoonColors.textMain,
            fontFamily: CartoonColors.fontFamily,
            letterSpacing: isComic ? 1.5 : 0,
          ),
        ),
        const SizedBox(width: 8),
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
          decoration: BoxDecoration(
            color: CartoonColors.successGreen,
            borderRadius: BorderRadius.circular(8),
            border: Border.all(color: CartoonColors.outline, width: 2.5),
            boxShadow: _hardShadowSmall,
          ),
          child: Text(
            '💾 API-KU',
            style: TextStyle(
              fontSize: 10,
              color: CartoonColors.textOnButton(
                  CartoonColors.successGreen),
              fontWeight: FontWeight.w700,
              fontFamily: CartoonColors.fontFamilySub,
            ),
          ),
        ),
        if (isBannedMode)
          Container(
            margin: const EdgeInsets.only(left: 8),
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
            decoration: BoxDecoration(
              color: CartoonColors.dangerPink,
              borderRadius: BorderRadius.circular(8),
              border: Border.all(color: CartoonColors.outline, width: 2.5),
              boxShadow: _hardShadowSmall,
            ),
            child: Text(
              '🚫 BANNED',
              style: TextStyle(
                fontSize: 10,
                color: CartoonColors.textOnButton(
                    CartoonColors.dangerPink),
                fontWeight: FontWeight.w700,
                fontFamily: CartoonColors.fontFamilySub,
              ),
            ),
          ),
      ],
    );
  }

  Widget _buildApiBanner(bool isComic, AppPalette C) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
      decoration: BoxDecoration(
        color: CartoonColors.warningYellow,
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: CartoonColors.outline, width: 2.5),
        boxShadow: _hardShadowSmall,
      ),
      child: Text(
        '💸 Pakai API: spamotp-api-eef5f0834c07.herokuapp.com',
        style: TextStyle(
          fontSize: 11,
          color: CartoonColors.textOnButton(CartoonColors.warningYellow),
          fontWeight: FontWeight.w700,
          fontFamily: CartoonColors.fontFamilySub,
        ),
      ),
    );
  }

  Widget _buildPhoneLabel(bool isComic) {
    return Text(
      '📞 Nomor Target',
      style: TextStyle(
        fontSize: 12,
        color: CartoonColors.textSub,
        fontWeight: FontWeight.w700,
        fontFamily: CartoonColors.fontFamily,
        letterSpacing: isComic ? 1 : 0,
      ),
    );
  }

  Widget _buildPhoneInput(bool isComic) {
    return Row(
      children: [
        Expanded(
          child: Container(
            decoration: BoxDecoration(
              color: CartoonColors.bgCard,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: CartoonColors.outline, width: 3),
              boxShadow: _hardShadow,
            ),
            child: TextField(
              controller: phoneController,
              style: TextStyle(
                color: CartoonColors.textOnCard,
                fontWeight: FontWeight.w600,
                fontFamily: CartoonColors.fontFamilySub,
              ),
              cursorColor: CartoonColors.successGreen,
              decoration: InputDecoration(
                hintText: '6281234567890,6289876543210',
                hintStyle: TextStyle(
                    color: CartoonColors.textSub.withOpacity(0.4),
                    fontFamily: CartoonColors.fontFamilySub),
                border: InputBorder.none,
                contentPadding:
                    const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
              ),
            ),
          ),
        ),
        const SizedBox(width: 8),
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
          decoration: BoxDecoration(
            color: CartoonColors.btnBlueLight,
            borderRadius: BorderRadius.circular(8),
            border: Border.all(color: CartoonColors.outline, width: 2.5),
            boxShadow: _hardShadowSmall,
          ),
          child: Text(
            'Multi',
            style: TextStyle(
              fontSize: 10,
              color: CartoonColors.textOnButton(CartoonColors.btnBlueLight),
              fontWeight: FontWeight.w700,
              fontFamily: CartoonColors.fontFamilySub,
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildLoopDelayRow(bool isComic, AppPalette C) {
    return Row(
      children: [
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('🔄 Jumlah Pengiriman',
                  style: TextStyle(
                    fontSize: 12,
                    color: CartoonColors.textSub,
                    fontWeight: FontWeight.w700,
                    fontFamily: CartoonColors.fontFamilySub,
                  )),
              const SizedBox(height: 6),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8),
                decoration: BoxDecoration(
                  color: CartoonColors.btnBlueLight,
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: CartoonColors.outline, width: 3),
                  boxShadow: _hardShadow,
                ),
                child: DropdownButtonHideUnderline(
                  child: DropdownButton<int>(
                    value: totalLoops,
                    dropdownColor: CartoonColors.bgCard,
                    style: TextStyle(
                      color: CartoonColors
                          .textOnButton(CartoonColors.btnBlueLight),
                      fontSize: 14,
                      fontWeight: FontWeight.w700,
                      fontFamily: CartoonColors.fontFamilySub,
                    ),
                    icon: Icon(Icons.keyboard_arrow_down,
                        color: CartoonColors
                            .textOnButton(CartoonColors.btnBlueLight)),
                    isExpanded: true,
                    items: [
                      _ddItem(1, '1×', isComic),
                      _ddItem(2, '2×', isComic),
                      _ddItem(3, '3×', isComic),
                      _ddItem(5, '5×', isComic),
                      _ddItem(10, '10×', isComic),
                      _ddItem(20, '20×', isComic),
                      _ddItem(30, '30×', isComic),
                      _ddItem(50, '50×', isComic),
                      _ddItem(100, '100×', isComic),
                      DropdownMenuItem(
                        value: 9999,
                        child: Text('🚫 BANNED SPAM',
                            style: TextStyle(
                              color: CartoonColors.textOnButton(
                                  CartoonColors.btnBlueLight),
                              fontWeight: FontWeight.w900,
                              fontFamily: CartoonColors.fontFamilySub,
                            )),
                      ),
                    ],
                    onChanged: isRunning
                        ? null
                        : (value) {
                            setState(() {
                              totalLoops = value!;
                              isBannedMode = (value == 9999);
                            });
                          },
                  ),
                ),
              ),
            ],
          ),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('⏱️ Delay (ms)',
                  style: TextStyle(
                    fontSize: 12,
                    color: CartoonColors.textSub,
                    fontWeight: FontWeight.w700,
                    fontFamily: CartoonColors.fontFamilySub,
                  )),
              const SizedBox(height: 6),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8),
                decoration: BoxDecoration(
                  color: CartoonColors.btnBlueDark,
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: CartoonColors.outline, width: 3),
                  boxShadow: _hardShadow,
                ),
                child: DropdownButtonHideUnderline(
                  child: DropdownButton<int>(
                    value: delayMs,
                    dropdownColor: CartoonColors.bgCard,
                    style: TextStyle(
                      color: CartoonColors
                          .textOnButton(CartoonColors.btnBlueDark),
                      fontSize: 14,
                      fontWeight: FontWeight.w700,
                      fontFamily: CartoonColors.fontFamilySub,
                    ),
                    icon: Icon(Icons.keyboard_arrow_down,
                        color: CartoonColors
                            .textOnButton(CartoonColors.btnBlueDark)),
                    isExpanded: true,
                    items: [
                      _ddItem(500, '500ms (Cepat)', isComic,
                          bgColor: CartoonColors.btnBlueDark),
                      _ddItem(1000, '1000ms (Normal)', isComic,
                          bgColor: CartoonColors.btnBlueDark),
                      _ddItem(2000, '2000ms (Aman)', isComic,
                          bgColor: CartoonColors.btnBlueDark),
                      _ddItem(3000, '3000ms (Anti Blokir)', isComic,
                          bgColor: CartoonColors.btnBlueDark),
                    ],
                    onChanged: isRunning
                        ? null
                        : (value) => setState(() => delayMs = value!),
                  ),
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  DropdownMenuItem<int> _ddItem(int value, String text, bool isComic,
      {Color? bgColor}) {
    final bg = bgColor ?? CartoonColors.btnBlueLight;
    return DropdownMenuItem(
      value: value,
      child: Text(text,
          style: TextStyle(
            color: CartoonColors.textOnButton(bg),
            fontFamily: CartoonColors.fontFamilySub,
            fontWeight: FontWeight.w700,
          )),
    );
  }

  Widget _buildActionButtons(bool isComic) {
    final startBg = isBannedMode
        ? CartoonColors.dangerPink
        : CartoonColors.successGreen;
    return Row(
      children: [
        Expanded(
          child: ElevatedButton(
            onPressed: isRunning ? null : _startSpam,
            style: ElevatedButton.styleFrom(
              backgroundColor: startBg,
              foregroundColor:
                  CartoonColors.textOnButton(startBg),
              padding: const EdgeInsets.symmetric(vertical: 16),
              elevation: 0,
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                  side: BorderSide(
                      color: CartoonColors.outline, width: 3)),
            ),
            child: Text(
              isBannedMode ? '🔥 BANNED SPAM' : '🚀 Kirim',
              style: TextStyle(
                fontWeight: FontWeight.w900,
                fontSize: 16,
                color: CartoonColors.textOnButton(startBg),
                fontFamily: CartoonColors.fontFamily,
                letterSpacing: isComic ? 1.5 : 0.5,
              ),
            ),
          ),
        ),
        const SizedBox(width: 10),
        Expanded(
          child: ElevatedButton(
            onPressed: isRunning ? _stopSpam : null,
            style: ElevatedButton.styleFrom(
              backgroundColor: CartoonColors.dangerPink,
              foregroundColor:
                  CartoonColors.textOnButton(CartoonColors.dangerPink),
              padding: const EdgeInsets.symmetric(vertical: 16),
              elevation: 0,
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                  side:
                      BorderSide(color: CartoonColors.outline, width: 3)),
            ),
            child: Text(
              '🛑 Stop',
              style: TextStyle(
                fontWeight: FontWeight.w900,
                fontSize: 16,
                color:
                    CartoonColors.textOnButton(CartoonColors.dangerPink),
                fontFamily: CartoonColors.fontFamily,
                letterSpacing: isComic ? 1.5 : 0.5,
              ),
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildProgressCard(bool isComic, AppPalette C) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: CartoonColors.bgCard,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: CartoonColors.outline, width: 3),
        boxShadow: _hardShadow,
      ),
      child: Column(
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text('${progress.toStringAsFixed(0)}%',
                  style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w900,
                    color: CartoonColors.textOnCard,
                    fontFamily: CartoonColors.fontFamily,
                  )),
              Text('$totalRequests / ${(totalLoops * 2).toString()}',
                  style: TextStyle(
                    fontSize: 14,
                    color: CartoonColors.textSub,
                    fontWeight: FontWeight.w600,
                    fontFamily: CartoonColors.fontFamilySub,
                  )),
            ],
          ),
          const SizedBox(height: 8),
          ClipRRect(
            borderRadius: BorderRadius.circular(10),
            child: LinearProgressIndicator(
              value: progress / 100,
              minHeight: 12,
              backgroundColor:
                  CartoonColors.textSub.withOpacity(0.15),
              valueColor: AlwaysStoppedAnimation<Color>(isBannedMode
                  ? CartoonColors.dangerPink
                  : CartoonColors.successGreen),
            ),
          ),
          const SizedBox(height: 12),
          Row(
            children: [
              _buildStatBox('✅ Sukses', totalSuccess,
                  CartoonColors.successGreen),
              const SizedBox(width: 6),
              _buildStatBox('❌ Gagal', totalError,
                  CartoonColors.dangerPink),
              const SizedBox(width: 6),
              _buildStatBox('📡 Total', totalRequests,
                  CartoonColors.btnBlueDark),
            ],
          ),
          const SizedBox(height: 8),
          Text(currentStatus,
              style: TextStyle(
                fontSize: 11,
                color: CartoonColors.textSub,
                fontWeight: FontWeight.w600,
                fontFamily: CartoonColors.fontFamilySub,
              ),
              textAlign: TextAlign.center),
        ],
      ),
    );
  }

  Widget _buildLogPanel(bool isComic, AppPalette C) {
    return Container(
      decoration: BoxDecoration(
        color: CartoonColors.bgCard,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: CartoonColors.outline, width: 3),
        boxShadow: _hardShadow,
      ),
      child: logs.isEmpty
          ? Center(
              child: Text('📭 Belum ada log',
                  style: TextStyle(
                    color: CartoonColors.textSub,
                    fontSize: 13,
                    fontWeight: FontWeight.w600,
                    fontFamily: CartoonColors.fontFamilySub,
                  )))
          : ListView.builder(
              controller: _logScrollController,
              padding: const EdgeInsets.all(12),
              itemCount: logs.length,
              itemBuilder: (context, index) {
                String log = logs[index];
                Color color = CartoonColors.textSub;
                if (log.contains('✅') && !log.contains('BANNED')) {
                  color = CartoonColors.successGreen;
                } else if (log.contains('❌')) {
                  color = CartoonColors.dangerPink;
                } else if (log.contains('🚫') || log.contains('BANNED')) {
                  color = CartoonColors.dangerPink;
                } else if (log.contains('🛑')) {
                  color = CartoonColors.dangerPink;
                } else if (log.contains('🎯')) {
                  color = CartoonColors.warningYellow;
                }
                return Padding(
                  padding: const EdgeInsets.symmetric(vertical: 2),
                  child: Row(
                    children: [
                      Text(log.substring(1, 9),
                          style: TextStyle(
                            fontSize: 10,
                            color: CartoonColors.textSub.withOpacity(0.5),
                            fontFamily: 'monospace',
                            fontWeight: FontWeight.bold,
                          )),
                      const SizedBox(width: 6),
                      Expanded(
                        child: Text(log.substring(10),
                            style: TextStyle(
                              fontSize: 11,
                              color: color,
                              fontFamily: 'monospace',
                              fontWeight: FontWeight.w600,
                            )),
                      ),
                    ],
                  ),
                );
              },
            ),
    );
  }

  Widget _buildStatBox(String label, int value, Color color) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 8),
        decoration: BoxDecoration(
          color: color,
          borderRadius: BorderRadius.circular(10),
          border: Border.all(color: CartoonColors.outline, width: 2.5),
          boxShadow: _hardShadowSmall,
        ),
        child: Column(
          children: [
            Text(value.toString(),
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.w900,
                  color: CartoonColors.textOnButton(color),
                  fontFamily: CartoonColors.fontFamily,
                )),
            Text(label,
                style: TextStyle(
                  fontSize: 9,
                  color: CartoonColors.textOnButton(color)
                      .withOpacity(0.95),
                  fontWeight: FontWeight.w700,
                  fontFamily: CartoonColors.fontFamilySub,
                )),
          ],
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════
// COMIC HALFTONE PAINTER
// ═══════════════════════════════════════════════════════════
class _ComicHalftonePainter extends CustomPainter {
  final Color color;
  const _ComicHalftonePainter({required this.color});

  @override
  void paint(Canvas canvas, Size size) {
    const spacing = 22.0;
    final paint = Paint()..color = color;
    for (double x = 0; x < size.width + spacing; x += spacing) {
      for (double y = 0; y < size.height + spacing; y += spacing) {
        canvas.drawCircle(Offset(x, y), 2.5, paint);
      }
    }
  }

  @override
  bool shouldRepaint(_ComicHalftonePainter old) => old.color != color;
}