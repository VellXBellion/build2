// lib/check_notif_page.dart
import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'app_theme.dart';
import 'api_config.dart';
import 'notification_service.dart';

class _Pulse {
  static final ValueNotifier<double> v = ValueNotifier<double>(0);
  static bool _started = false;
  static void ensureStarted() {
    if (_started) return;
    _started = true;
    _run();
  }
  static Future<void> _run() async {
    final sw = Stopwatch()..start();
    while (true) {
      await Future<void>.delayed(const Duration(milliseconds: 80));
      final t = (sw.elapsedMilliseconds % 1600) / 1600.0;
      v.value = t < 0.5 ? t * 2 : (1 - t) * 2;
    }
  }
}

class _Led extends StatelessWidget {
  final Color color;
  final double size;
  final bool blink;
  const _Led({required this.color, this.size = 8, this.blink = false});

  @override
  Widget build(BuildContext context) {
    final isComic = AppTheme.currentStyle.value == ThemeStyle.comic3d;
    if (isComic) {
      return Container(
        width: size, height: size,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          color: color,
          border: Border.all(color: Colors.black, width: size * 0.18)),
      );
    }
    if (!blink) return _dot(1.0);
    return ValueListenableBuilder<double>(
      valueListenable: _Pulse.v,
      builder: (_, v, __) => _dot(0.45 + v * 0.55));
  }

  Widget _dot(double opacity) => Container(
        width: size, height: size,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          gradient: RadialGradient(
            center: const Alignment(-0.35, -0.35),
            colors: [
              Colors.white.withValues(alpha: 0.85 * opacity),
              color.withValues(alpha: opacity),
              color.withValues(alpha: 0.55 * opacity),
            ],
            stops: const [0.0, 0.4, 1.0]),
          border: Border.all(
              color: Colors.black.withValues(alpha: 0.85),
              width: size * 0.1),
          boxShadow: [
            BoxShadow(color: color.withValues(alpha: 0.75 * opacity),
                blurRadius: size * 1.4, spreadRadius: size * 0.2),
            BoxShadow(color: color.withValues(alpha: 0.35 * opacity),
                blurRadius: size * 2.6, spreadRadius: size * 0.4),
          ],
        ),
      );
}

class _Rivet extends StatelessWidget {
  final AppPalette C;
  final double size;
  const _Rivet({required this.C, this.size = 10});
  @override
  Widget build(BuildContext context) {
    if (AppTheme.currentStyle.value == ThemeStyle.comic3d) {
      return const SizedBox.shrink();
    }
    return Container(
      width: size, height: size,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        gradient: RadialGradient(
          center: const Alignment(-0.35, -0.35),
          colors: [C.accentShine, C.accentHi, C.accent, C.primaryLo],
          stops: const [0.0, 0.3, 0.65, 1.0]),
      ),
    );
  }
}

class _MetalPlate extends StatelessWidget {
  final AppPalette C;
  final Widget child;
  final EdgeInsets padding;
  final double radius;
  const _MetalPlate({
    required this.C,
    required this.child,
    this.padding = const EdgeInsets.all(16),
    this.radius = 16,
  });

  @override
  Widget build(BuildContext context) {
    final isComic = AppTheme.currentStyle.value == ThemeStyle.comic3d;
    if (isComic) {
      return Container(
        padding: padding,
        decoration: BoxDecoration(
          color: C.bgDark,
          borderRadius: BorderRadius.circular(radius + 4),
          border: Border.all(color: Colors.black, width: 4),
          boxShadow: const [
            BoxShadow(color: Colors.black, offset: Offset(6, 6),
                blurRadius: 0),
          ],
        ),
        child: child,
      );
    }
    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(radius),
        gradient: LinearGradient(
          begin: Alignment.topLeft, end: Alignment.bottomRight,
          colors: [C.text, C.bg, C.bgDark, C.bgDeep],
          stops: const [0.0, 0.4, 0.7, 1.0]),
        boxShadow: [
          BoxShadow(color: Colors.black.withValues(alpha: 0.75),
              offset: const Offset(0, 6), blurRadius: 12),
        ],
      ),
      padding: const EdgeInsets.all(3),
      child: Container(
        padding: padding,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(radius - 3),
          gradient: LinearGradient(
            begin: Alignment.topCenter, end: Alignment.bottomCenter,
            colors: [C.bg, C.bgDark, C.bgDeep]),
          border: Border.all(color: Colors.black.withValues(alpha: 0.5)),
        ),
        child: child,
      ),
    );
  }
}

class _IndustrialButton extends StatefulWidget {
  final AppPalette C;
  final Widget child;
  final VoidCallback? onTap;
  final Color color;
  final double height;
  const _IndustrialButton({
    required this.C,
    required this.child,
    required this.onTap,
    required this.color,
    this.height = 56,
  });

  @override
  State<_IndustrialButton> createState() => _IndustrialButtonState();
}

class _IndustrialButtonState extends State<_IndustrialButton> {
  bool _pressed = false;

  @override
  Widget build(BuildContext context) {
    final C = widget.C;
    final enabled = widget.onTap != null;
    final isComic = AppTheme.currentStyle.value == ThemeStyle.comic3d;
    final light = _lighten(widget.color);
    final dark = _darken(widget.color);

    return GestureDetector(
      onTapDown: enabled ? (_) => setState(() => _pressed = true) : null,
      onTapUp: enabled ? (_) {
        setState(() => _pressed = false);
        HapticFeedback.mediumImpact();
        widget.onTap?.call();
      } : null,
      onTapCancel: enabled ? () => setState(() => _pressed = false) : null,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 80),
        height: widget.height,
        transform: isComic
            ? Matrix4.translationValues(_pressed ? 4 : 0, _pressed ? 4 : 0, 0)
            : null,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(isComic ? 12 : 12),
          gradient: isComic ? null : LinearGradient(
            begin: _pressed ? Alignment.bottomCenter : Alignment.topCenter,
            end: _pressed ? Alignment.topCenter : Alignment.bottomCenter,
            colors: _pressed
                ? [dark, dark, widget.color]
                : [light, widget.color, dark],
            stops: const [0.0, 0.5, 1.0]),
          color: isComic ? widget.color : null,
          boxShadow: isComic
              ? (_pressed ? [] : const [
                  BoxShadow(color: Colors.black, offset: Offset(4, 4),
                      blurRadius: 0)])
              : (_pressed
                  ? [BoxShadow(color: Colors.black.withValues(alpha: 0.9),
                      offset: const Offset(0, 1), blurRadius: 3)]
                  : [
                      BoxShadow(color: widget.color.withValues(alpha: 0.45),
                          offset: const Offset(0, 5), blurRadius: 10,
                          spreadRadius: -2),
                      BoxShadow(color: Colors.black.withValues(alpha: 0.75),
                          offset: const Offset(0, 4), blurRadius: 6),
                    ]),
          border: Border.all(
              color: isComic ? Colors.black : dark.withValues(alpha: 0.9),
              width: isComic ? 3.5 : 1.5),
        ),
        child: Stack(
          alignment: Alignment.center,
          children: [
            if (!isComic) ...[
              Positioned(top: 5, left: 5, child: _Rivet(C: C, size: 6)),
              Positioned(top: 5, right: 5, child: _Rivet(C: C, size: 6)),
              Positioned(bottom: 5, left: 5, child: _Rivet(C: C, size: 6)),
              Positioned(bottom: 5, right: 5, child: _Rivet(C: C, size: 6)),
            ],
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20),
              child: Opacity(opacity: enabled ? 1 : 0.5, child: widget.child),
            ),
          ],
        ),
      ),
    );
  }

  static Color _lighten(Color c) => Color.fromARGB(
        (c.a * 255).round(),
        ((c.r * 255).round() + 40).clamp(0, 255),
        ((c.g * 255).round() + 40).clamp(0, 255),
        ((c.b * 255).round() + 30).clamp(0, 255));
  static Color _darken(Color c) => Color.fromARGB(
        (c.a * 255).round(),
        ((c.r * 255).round() - 60).clamp(0, 255),
        ((c.g * 255).round() - 50).clamp(0, 255),
        ((c.b * 255).round() - 40).clamp(0, 255));
}

// ═══════════════════════════════════════════════════════════
// MODEL
// ═══════════════════════════════════════════════════════════
class AppNotification {
  final String id;
  final String title;
  final String body;
  final String type;
  final DateTime createdAt;
  final bool isRead;
  final String? fromUser;

  AppNotification({
    required this.id,
    required this.title,
    required this.body,
    required this.type,
    required this.createdAt,
    required this.isRead,
    this.fromUser,
  });

  AppNotification copyWith({bool? isRead}) => AppNotification(
        id: id, title: title, body: body, type: type,
        createdAt: createdAt, isRead: isRead ?? this.isRead,
        fromUser: fromUser,
      );

  factory AppNotification.fromJson(Map<String, dynamic> j) => AppNotification(
        id: (j['id'] ?? '').toString(),
        title: (j['title'] ?? 'Notifikasi').toString(),
        body: (j['body'] ?? j['message'] ?? '').toString(),
        type: (j['type'] ?? 'info').toString().toLowerCase(),
        createdAt:
            DateTime.tryParse((j['created_at'] ?? '').toString())?.toLocal() ??
                DateTime.now(),
        isRead: j['is_read'] == true || j['is_read'] == 1,
        fromUser: j['from']?.toString(),
      );

  Color accent(AppPalette C) {
    switch (type) {
      case 'success': return C.primaryHi;
      case 'warning': return C.accent;
      case 'error': return C.primaryHi;
      default: return C.accentHi;
    }
  }

  IconData get icon {
    switch (type) {
      case 'success': return Icons.check_circle_rounded;
      case 'warning': return Icons.warning_amber_rounded;
      case 'error': return Icons.error_rounded;
      default: return Icons.campaign_rounded;
    }
  }
}

// ═══════════════════════════════════════════════════════════
// CHECK NOTIF PAGE
// ═══════════════════════════════════════════════════════════
class CheckNotifPage extends StatefulWidget {
  final String sessionKey;
  final String username;
  final String role;

  const CheckNotifPage({
    super.key,
    required this.sessionKey,
    required this.username,
    required this.role,
  });

  @override
  State<CheckNotifPage> createState() => _CheckNotifPageState();
}

class _CheckNotifPageState extends State<CheckNotifPage> {
  final List<AppNotification> _notifications = [];
  bool _isLoading = true;
  String? _error;
  Timer? _pollTimer;
  final Set<String> _seenIds = {};
  bool _firstLoad = true;

  int get _unreadCount => _notifications.where((n) => !n.isRead).length;

  @override
  void initState() {
    super.initState();
    _Pulse.ensureStarted();
    _fetch();
    _pollTimer = Timer.periodic(
        const Duration(seconds: 15), (_) => _fetch(silent: true));
  }

  @override
  void dispose() {
    _pollTimer?.cancel();
    super.dispose();
  }

  Future<void> _fetch({bool silent = false}) async {
    if (!silent) setState(() => _isLoading = true);
    try {
      final uri = Uri.parse(
        '$baseUrl/getNotifications'
        '?key=${Uri.encodeComponent(widget.sessionKey)}'
        '&username=${Uri.encodeComponent(widget.username)}',
      );
      final res = await http.get(uri).timeout(const Duration(seconds: 15));

      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        final list = (data['notifications'] ?? data['data'] ?? []) as List;
        final parsed = list
            .map((e) => AppNotification.fromJson(e as Map<String, dynamic>))
            .toList()
          ..sort((a, b) => b.createdAt.compareTo(a.createdAt));

        if (_firstLoad) {
          _seenIds.addAll(parsed.map((e) => e.id));
          _firstLoad = false;
        } else {
          for (final n in parsed) {
            if (!_seenIds.contains(n.id)) {
              _seenIds.add(n.id);
              if (!n.isRead) {
                await NotificationService.show(
                  id: n.id.hashCode & 0x7fffffff,
                  title: n.title, body: n.body, payload: n.id);
              }
            }
          }
        }

        if (!mounted) return;
        setState(() {
          _notifications..clear()..addAll(parsed);
          _error = null;
        });
      } else {
        if (!mounted) return;
        setState(() => _error = 'HTTP ${res.statusCode}');
      }
    } catch (_) {
      if (!mounted) return;
      setState(() => _error = 'Gagal memuat notifikasi');
    } finally {
      if (mounted && !silent) setState(() => _isLoading = false);
    }
  }

  Future<void> _markAsRead(AppPalette C, AppNotification n) async {
    if (n.isRead) return;
    final idx = _notifications.indexWhere((e) => e.id == n.id);
    if (idx == -1) return;
    setState(() => _notifications[idx] = n.copyWith(isRead: true));

    try {
      await http.post(
        Uri.parse('$baseUrl/markNotificationRead'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'key': widget.sessionKey,
          'username': widget.username,
          'id': n.id,
        })).timeout(const Duration(seconds: 10));
    } catch (_) {}
  }

  Future<void> _markAllRead(AppPalette C, bool isComic) async {
    if (_unreadCount == 0) return;
    HapticFeedback.mediumImpact();

    for (int i = 0; i < _notifications.length; i++) {
      if (!_notifications[i].isRead) {
        _notifications[i] = _notifications[i].copyWith(isRead: true);
      }
    }
    setState(() {});

    try {
      await http.post(
        Uri.parse('$baseUrl/markAllRead'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'key': widget.sessionKey,
          'username': widget.username,
        })).timeout(const Duration(seconds: 10));
      _snack(C, isComic, 'Semua notifikasi ditandai dibaca');
    } catch (_) {
      _snack(C, isComic, 'Gagal menandai semua', isError: true);
      _fetch(silent: true);
    }
  }

  Future<void> _deleteNotification(AppPalette C, bool isComic,
      AppNotification n) async {
    final ok = await _confirmDialog(C, isComic, n);
    if (ok != true) return;
    final idx = _notifications.indexWhere((e) => e.id == n.id);
    if (idx == -1) return;
    final removed = _notifications.removeAt(idx);
    setState(() {});
    HapticFeedback.mediumImpact();

    try {
      final res = await http.post(
        Uri.parse('$baseUrl/deleteNotification'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'key': widget.sessionKey,
          'username': widget.username,
          'id': n.id,
        })).timeout(const Duration(seconds: 10));
      if (res.statusCode != 200) throw Exception();
      _snack(C, isComic, 'Notifikasi disembunyikan');
    } catch (_) {
      if (!mounted) return;
      setState(() => _notifications.insert(idx, removed));
      _snack(C, isComic, 'Gagal menghapus notifikasi', isError: true);
    }
  }

  void _snack(AppPalette C, bool isComic, String msg,
      {bool isError = false}) {
    if (!mounted) return;
    final c = isError ? C.primaryHi : C.primaryHi;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Row(
          children: [
            _Led(color: c, size: 8, blink: !isComic),
            const SizedBox(width: 12),
            Expanded(
              child: Text(msg,
                  style: TextStyle(
                    color: C.text,
                    fontSize: 12,
                    fontWeight: FontWeight.w700,
                    fontFamily:
                        isComic ? 'ComicNeue' : 'ShareTechMono',
                    letterSpacing: 0.3)),
            ),
          ],
        ),
        backgroundColor: C.bgDark,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(isComic ? 12 : 8),
          side: BorderSide(color: c, width: isComic ? 3 : 1.5)),
        margin: const EdgeInsets.all(16),
        duration: const Duration(seconds: 2),
      ),
    );
  }

  Future<bool?> _confirmDialog(AppPalette C, bool isComic,
      AppNotification n) {
    return showDialog<bool>(
      context: context,
      barrierColor: Colors.black.withValues(alpha: 0.8),
      builder: (ctx) => Dialog(
        backgroundColor: Colors.transparent,
        insetPadding: const EdgeInsets.all(24),
        child: _MetalPlate(
          C: C,
          padding: const EdgeInsets.all(20),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(Icons.delete_forever_rounded,
                  color: isComic ? Colors.black : C.primaryHi, size: 36),
              const SizedBox(height: 12),
              Text('HAPUS DARI INBOX?',
                  style: TextStyle(
                    color: isComic ? Colors.black : C.primaryHi,
                    fontSize: isComic ? 20 : 13,
                    fontWeight: FontWeight.w900,
                    fontFamily: isComic ? 'Bangers' : 'Orbitron',
                    letterSpacing: 2)),
              const SizedBox(height: 8),
              Text(n.title,
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    color: isComic
                        ? Colors.black.withValues(alpha: 0.7)
                        : C.text.withValues(alpha: 0.7),
                    fontSize: 11,
                    fontFamily: isComic ? 'ComicNeue' : 'ShareTechMono')),
              const SizedBox(height: 6),
              Text('Notif ini hanya disembunyikan dari inbox Anda.',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    color: isComic
                        ? Colors.black.withValues(alpha: 0.5)
                        : C.text.withValues(alpha: 0.45),
                    fontSize: 9,
                    fontFamily: isComic ? 'ComicNeue' : 'ShareTechMono',
                    height: 1.4)),
              const SizedBox(height: 18),
              Row(
                children: [
                  Expanded(
                    child: _IndustrialButton(
                      C: C, color: C.bg, height: 44,
                      onTap: () => Navigator.pop(ctx, false),
                      child: Text('BATAL',
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: isComic ? 15 : 11,
                            fontWeight: FontWeight.w900,
                            fontFamily:
                                isComic ? 'Bangers' : 'Orbitron',
                            letterSpacing: 2)),
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: _IndustrialButton(
                      C: C, color: C.primaryHi, height: 44,
                      onTap: () => Navigator.pop(ctx, true),
                      child: const Text('HAPUS',
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 11,
                            fontWeight: FontWeight.w900,
                            fontFamily: 'Orbitron',
                            letterSpacing: 2)),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _openDetail(AppPalette C, bool isComic, AppNotification n) {
    _markAsRead(C, n);
    HapticFeedback.lightImpact();
    showDialog(
      context: context,
      barrierColor: Colors.black.withValues(alpha: 0.85),
      builder: (ctx) => Dialog(
        backgroundColor: Colors.transparent,
        insetPadding: const EdgeInsets.all(20),
        child: _MetalPlate(
          C: C,
          padding: const EdgeInsets.all(20),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Stack(
                    alignment: Alignment.center,
                    children: [
                      Container(
                        width: 46, height: 46,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          gradient: isComic ? null
                              : RadialGradient(
                                  colors: [C.text, C.bg, C.bgDark]),
                          color: isComic ? n.accent(C) : null,
                          border: Border.all(
                              color: isComic ? Colors.black : n.accent(C),
                              width: isComic ? 4 : 2)),
                        child: Icon(n.icon,
                            color: Colors.white, size: 22),
                      ),
                      if (!isComic)
                        Positioned(top: -2, right: -2,
                            child: _Led(color: C.primaryHi, size: 6,
                                blink: true)),
                    ],
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Container(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 6, vertical: 2),
                          margin: const EdgeInsets.only(bottom: 4),
                          decoration: BoxDecoration(
                            color: isComic ? n.accent(C)
                                : n.accent(C).withValues(alpha: 0.18),
                            borderRadius: BorderRadius.circular(
                                isComic ? 6 : 4),
                            border: Border.all(
                                color: isComic ? Colors.black
                                    : n.accent(C).withValues(alpha: 0.6),
                                width: isComic ? 2 : 1)),
                          child: Text(n.type.toUpperCase(),
                              style: TextStyle(
                                color: Colors.white,
                                fontSize: isComic ? 10 : 8,
                                fontWeight: FontWeight.w900,
                                fontFamily:
                                    isComic ? 'Bangers' : 'Orbitron',
                                letterSpacing: 1.5)),
                        ),
                        Text(n.title,
                            style: TextStyle(
                              color: isComic ? Colors.black : C.accentHi,
                              fontSize: isComic ? 16 : 13,
                              fontWeight: FontWeight.w900,
                              fontFamily:
                                  isComic ? 'Bangers' : 'Orbitron',
                              letterSpacing: 1, height: 1.2)),
                        const SizedBox(height: 4),
                        Text(_formatTime(n.createdAt),
                            style: TextStyle(
                              color: isComic
                                  ? Colors.black.withValues(alpha: 0.5)
                                  : C.text.withValues(alpha: 0.55),
                              fontSize: 9,
                              fontFamily:
                                  isComic ? 'ComicNeue' : 'ShareTechMono',
                              letterSpacing: 1)),
                      ],
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 14),
              Container(
                height: isComic ? 3 : 1,
                color: isComic ? Colors.black : null,
                decoration: isComic ? null : BoxDecoration(
                    gradient: LinearGradient(colors: [
                      Colors.transparent,
                      n.accent(C).withValues(alpha: 0.6),
                      Colors.transparent])),
              ),
              const SizedBox(height: 14),
              ConstrainedBox(
                constraints: BoxConstraints(
                    maxHeight: MediaQuery.of(ctx).size.height * 0.4),
                child: SingleChildScrollView(
                  physics: const BouncingScrollPhysics(),
                  child: SelectableText(
                    n.body,
                    style: TextStyle(
                      color: isComic ? Colors.black : C.text,
                      fontSize: isComic ? 13 : 12,
                      height: 1.6,
                      fontFamily:
                          isComic ? 'ComicNeue' : 'ShareTechMono',
                      letterSpacing: 0.3)),
                ),
              ),
              if (n.fromUser != null && n.fromUser!.isNotEmpty) ...[
                const SizedBox(height: 12),
                Container(
                  padding: const EdgeInsets.symmetric(
                      horizontal: 10, vertical: 6),
                  decoration: BoxDecoration(
                    color: isComic ? Colors.white
                        : Colors.black.withValues(alpha: 0.4),
                    borderRadius: BorderRadius.circular(isComic ? 8 : 6),
                    border: Border.all(
                        color: isComic ? Colors.black : C.bgDark,
                        width: isComic ? 2 : 1)),
                  child: Row(
                    children: [
                      Icon(Icons.podcasts_rounded,
                          size: 12,
                          color: isComic ? Colors.black : C.accent),
                      const SizedBox(width: 6),
                      Expanded(
                        child: Text('Broadcast dari: ${n.fromUser}',
                            style: TextStyle(
                              color: isComic
                                  ? Colors.black.withValues(alpha: 0.8)
                                  : C.text.withValues(alpha: 0.7),
                              fontSize: 10,
                              fontFamily:
                                  isComic ? 'ComicNeue' : 'ShareTechMono')),
                      ),
                    ],
                  ),
                ),
              ],
              const SizedBox(height: 16),
              Row(
                children: [
                  Expanded(
                    child: _IndustrialButton(
                      C: C, color: C.primaryHi, height: 46,
                      onTap: () {
                        Navigator.pop(ctx);
                        _deleteNotification(C, isComic, n);
                      },
                      child: const Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(Icons.delete_outline_rounded,
                              color: Colors.white, size: 14),
                          SizedBox(width: 6),
                          Text('HAPUS',
                              style: TextStyle(
                                color: Colors.white,
                                fontSize: 11,
                                fontWeight: FontWeight.w900,
                                fontFamily: 'Orbitron',
                                letterSpacing: 2)),
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: _IndustrialButton(
                      C: C, color: n.accent(C), height: 46,
                      onTap: () => Navigator.pop(ctx),
                      child: Text('TUTUP',
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: isComic ? 15 : 11,
                            fontWeight: FontWeight.w900,
                            fontFamily:
                                isComic ? 'Bangers' : 'Orbitron',
                            letterSpacing: 2)),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<AppPalette>(
      valueListenable: AppTheme.current,
      builder: (context, C, _) {
        return ValueListenableBuilder<ThemeStyle>(
          valueListenable: AppTheme.currentStyle,
          builder: (context, style, __) {
            final isComic = style == ThemeStyle.comic3d;

            return Scaffold(
              backgroundColor: C.bgDeep,
              body: Stack(
                children: [
                  Positioned.fill(
                    child: isComic
                        ? Container(
                            color: C.bg,
                            child: CustomPaint(
                              painter: _ComicHalftonePainter(
                                  color: C.primaryLo.withValues(
                                      alpha: 0.12))))
                        : Container(
                            decoration: BoxDecoration(
                              gradient: RadialGradient(
                                center: const Alignment(-0.3, -0.3),
                                radius: 1.2,
                                colors: [C.bg, C.bgDark, C.bgDeep],
                                stops: const [0.0, 0.6, 1.0]))),
                  ),
                  SafeArea(
                    child: Column(
                      children: [
                        const SizedBox(height: 8),
                        _buildAppBar(C, isComic),
                        const SizedBox(height: 12),
                        Expanded(child: _buildBody(C, isComic)),
                      ],
                    ),
                  ),
                ],
              ),
            );
          },
        );
      },
    );
  }

  Widget _buildAppBar(AppPalette C, bool isComic) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 12),
      child: _MetalPlate(
        C: C,
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
        child: Row(
          children: [
            GestureDetector(
              onTap: () {
                HapticFeedback.lightImpact();
                Navigator.pop(context);
              },
              child: Container(
                width: 40, height: 40,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(10),
                  gradient: isComic ? null
                      : LinearGradient(
                          begin: Alignment.topCenter,
                          end: Alignment.bottomCenter,
                          colors: [C.textSub, C.bg, C.bgDark]),
                  color: isComic ? C.accent : null,
                  border: Border.all(
                      color: isComic ? Colors.black
                          : Colors.black.withValues(alpha: 0.7),
                      width: isComic ? 3 : 1.2)),
                child: Icon(Icons.arrow_back_ios_new_rounded,
                    color: isComic ? Colors.white : C.accent, size: 16),
              ),
            ),
            const SizedBox(width: 12),
            Stack(
              alignment: Alignment.center,
              children: [
                Container(
                  width: 40, height: 40,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    gradient: isComic ? null
                        : RadialGradient(colors: [C.text, C.bg, C.bgDark]),
                    color: isComic ? C.primaryHi : null,
                    border: Border.all(
                        color: isComic ? Colors.black : C.accentHi,
                        width: isComic ? 3 : 2)),
                  child: Icon(Icons.campaign_rounded,
                      color: isComic ? Colors.white : C.accentHi,
                      size: 20),
                ),
                if (_unreadCount > 0)
                  Positioned(
                    top: -3, right: -3,
                    child: Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 5, vertical: 1),
                      decoration: BoxDecoration(
                        color: C.primaryHi,
                        borderRadius: BorderRadius.circular(8),
                        border: isComic
                            ? Border.all(color: Colors.black, width: 2)
                            : null),
                      constraints: const BoxConstraints(minWidth: 16),
                      child: Text(
                        _unreadCount > 99 ? '99+' : '$_unreadCount',
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: isComic ? 10 : 8,
                          fontWeight: FontWeight.w900,
                          fontFamily:
                              isComic ? 'Bangers' : 'Orbitron')),
                    ),
                  ),
              ],
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('NOTIFIKASI PAGE',
                      style: TextStyle(
                        color: isComic ? Colors.black : C.accentHi,
                        fontSize: isComic ? 18 : 13,
                        fontWeight: FontWeight.w900,
                        fontFamily: isComic ? 'Bangers' : 'Orbitron',
                        letterSpacing: isComic ? 1.5 : 2, height: 1,
                        shadows: isComic ? null : [
                          Shadow(color: C.primaryLo,
                              offset: const Offset(0, 1), blurRadius: 1),
                          const Shadow(color: Colors.black,
                              offset: Offset(0, 2), blurRadius: 3)])),
                  const SizedBox(height: 3),
                  Row(
                    children: [
                      _Led(color: C.accentHi, size: 4, blink: !isComic),
                      const SizedBox(width: 5),
                      Text(
                        _unreadCount > 0
                            ? '$_unreadCount BELUM DIBACA'
                            : 'SEMUA TERBACA',
                        style: TextStyle(
                          color: isComic
                              ? Colors.black.withValues(alpha: 0.5)
                              : C.text.withValues(alpha: 0.55),
                          fontSize: 8,
                          fontWeight: FontWeight.w700,
                          fontFamily:
                              isComic ? 'ComicNeue' : 'ShareTechMono',
                          letterSpacing: 1.2)),
                    ],
                  ),
                ],
              ),
            ),
            GestureDetector(
              onTap: () {
                HapticFeedback.lightImpact();
                _fetch();
              },
              child: Container(
                width: 36, height: 36,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(9),
                  gradient: isComic ? null
                      : LinearGradient(
                          begin: Alignment.topCenter,
                          end: Alignment.bottomCenter,
                          colors: [C.textSub, C.bg, C.bgDark]),
                  color: isComic ? C.accent : null,
                  border: Border.all(
                      color: isComic ? Colors.black
                          : Colors.black.withValues(alpha: 0.7),
                      width: isComic ? 3 : 1.2)),
                child: Icon(Icons.refresh_rounded,
                    color: isComic ? Colors.white : C.accent, size: 18),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildBody(AppPalette C, bool isComic) {
    if (_isLoading && _notifications.isEmpty) {
      return Center(
        child: CircularProgressIndicator(
            valueColor: AlwaysStoppedAnimation(
                isComic ? Colors.black : C.accent),
            strokeWidth: 3));
    }

    if (_error != null && _notifications.isEmpty) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: _MetalPlate(
            C: C,
            padding: const EdgeInsets.all(20),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(Icons.wifi_off_rounded,
                    color: isComic ? Colors.black : C.primaryHi, size: 40),
                const SizedBox(height: 12),
                Text(_error!,
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      color: isComic ? Colors.black : C.text,
                      fontSize: isComic ? 13 : 12,
                      fontFamily:
                          isComic ? 'ComicNeue' : 'ShareTechMono')),
                const SizedBox(height: 14),
                _IndustrialButton(
                  C: C, color: C.primaryHi, height: 44,
                  onTap: () => _fetch(),
                  child: Text('COBA LAGI',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: isComic ? 15 : 11,
                        fontWeight: FontWeight.w900,
                        fontFamily: isComic ? 'Bangers' : 'Orbitron',
                        letterSpacing: 2)),
                ),
              ],
            ),
          ),
        ),
      );
    }

    if (_notifications.isEmpty) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: _MetalPlate(
            C: C,
            padding: const EdgeInsets.all(24),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(
                  width: 60, height: 60,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    gradient: isComic ? null
                        : RadialGradient(colors: [C.text, C.bg, C.bgDark]),
                    color: isComic ? C.primaryHi : null,
                    border: Border.all(
                        color: isComic ? Colors.black : C.textSub,
                        width: isComic ? 4 : 2)),
                  child: Icon(Icons.campaign_rounded,
                      color: Colors.white, size: 28),
                ),
                const SizedBox(height: 16),
                Text('TIDAK ADA BROADCAST',
                    style: TextStyle(
                      color: isComic ? Colors.black : C.accent,
                      fontSize: isComic ? 16 : 12,
                      fontWeight: FontWeight.w900,
                      fontFamily: isComic ? 'Bangers' : 'Orbitron',
                      letterSpacing: 2)),
                const SizedBox(height: 8),
                Text('Owner belum mengirim broadcast.\nTarik ke bawah untuk refresh.',
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      color: isComic
                          ? Colors.black.withValues(alpha: 0.6)
                          : C.text.withValues(alpha: 0.6),
                      fontSize: isComic ? 12 : 10,
                      fontFamily: isComic ? 'ComicNeue' : 'ShareTechMono',
                      height: 1.5)),
              ],
            ),
          ),
        ),
      );
    }

    return RefreshIndicator(
      onRefresh: () => _fetch(),
      color: isComic ? Colors.black : C.accent,
      backgroundColor: C.bgDark,
      child: ListView.builder(
        physics: const AlwaysScrollableScrollPhysics(
            parent: BouncingScrollPhysics()),
        padding: const EdgeInsets.symmetric(horizontal: 12),
        itemCount: _notifications.length + 1,
        itemBuilder: (_, i) {
          if (i == 0) return _buildActionBar(C, isComic);
          final n = _notifications[i - 1];
          return Padding(
            padding: const EdgeInsets.only(bottom: 10),
            child: _NotifTile(
              C: C,
              isComic: isComic,
              notif: n,
              onTap: () => _openDetail(C, isComic, n),
              onDelete: () => _deleteNotification(C, isComic, n),
              timeAgo: _formatTime(n.createdAt)),
          );
        },
      ),
    );
  }

  Widget _buildActionBar(AppPalette C, bool isComic) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Row(
        children: [
          Expanded(
            child: Container(
              padding: const EdgeInsets.symmetric(
                  horizontal: 10, vertical: 6),
              decoration: BoxDecoration(
                color: isComic ? C.bgDark
                    : Colors.black.withValues(alpha: 0.4),
                borderRadius: BorderRadius.circular(isComic ? 10 : 8),
                border: Border.all(
                    color: isComic ? Colors.black : C.bgDark,
                    width: isComic ? 3 : 1)),
              child: Row(
                children: [
                  _Led(color: C.accentHi, size: 6, blink: !isComic),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Text(
                      'TOTAL: ${_notifications.length}  |  BARU: $_unreadCount',
                      style: TextStyle(
                        color: isComic
                            ? Colors.black.withValues(alpha: 0.8)
                            : C.text.withValues(alpha: 0.7),
                        fontSize: 9,
                        fontFamily:
                            isComic ? 'ComicNeue' : 'ShareTechMono',
                        letterSpacing: 0.5)),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(width: 8),
          GestureDetector(
            onTap: _unreadCount > 0
                ? () => _markAllRead(C, isComic)
                : null,
            child: Container(
              padding: const EdgeInsets.symmetric(
                  horizontal: 10, vertical: 6),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(isComic ? 10 : 8),
                gradient: isComic ? null
                    : (_unreadCount > 0
                        ? LinearGradient(colors: [
                            C.accentHi, C.accent, C.primaryLo])
                        : LinearGradient(colors: [C.bg, C.bgDark])),
                color: isComic
                    ? (_unreadCount > 0 ? C.primaryHi : C.bg)
                    : null,
                border: Border.all(
                    color: isComic ? Colors.black
                        : Colors.black.withValues(alpha: 0.6),
                    width: isComic ? 3 : 1)),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(Icons.done_all_rounded,
                      size: isComic ? 14 : 12,
                      color: _unreadCount > 0
                          ? Colors.white
                          : (isComic
                              ? Colors.black.withValues(alpha: 0.4)
                              : C.text.withValues(alpha: 0.4))),
                  const SizedBox(width: 4),
                  Text('BACA SEMUA',
                      style: TextStyle(
                        color: _unreadCount > 0
                            ? Colors.white
                            : (isComic
                                ? Colors.black.withValues(alpha: 0.4)
                                : C.text.withValues(alpha: 0.4)),
                        fontSize: isComic ? 11 : 9,
                        fontWeight: FontWeight.w900,
                        fontFamily:
                            isComic ? 'Bangers' : 'Orbitron',
                        letterSpacing: 1)),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  static String _formatTime(DateTime t) {
    final d = DateTime.now().difference(t);
    if (d.inSeconds < 0) return 'baru saja';
    if (d.inSeconds < 60) return '${d.inSeconds}s lalu';
    if (d.inMinutes < 60) return '${d.inMinutes}m lalu';
    if (d.inHours < 24) return '${d.inHours}j lalu';
    if (d.inDays < 7) return '${d.inDays}h lalu';
    final dd = t.day.toString().padLeft(2, '0');
    final mm = t.month.toString().padLeft(2, '0');
    return '$dd/$mm/${t.year}';
  }
}

// ═══════════════════════════════════════════════════════════
// TILE NOTIFIKASI
// ═══════════════════════════════════════════════════════════
class _NotifTile extends StatelessWidget {
  final AppPalette C;
  final bool isComic;
  final AppNotification notif;
  final VoidCallback onTap;
  final VoidCallback onDelete;
  final String timeAgo;

  const _NotifTile({
    required this.C,
    required this.isComic,
    required this.notif,
    required this.onTap,
    required this.onDelete,
    required this.timeAgo,
  });

  @override
  Widget build(BuildContext context) {
    final c = notif.accent(C);
    final unread = !notif.isRead;

    return GestureDetector(
      onTap: onTap,
      onLongPress: () {
        HapticFeedback.mediumImpact();
        onDelete();
      },
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 180),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(isComic ? 16 : 12),
          gradient: isComic ? null
              : LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: unread
                      ? [Color.lerp(C.bg, c, 0.08)!, C.bg, C.bgDark]
                      : [C.bg, C.bgDark]),
          color: isComic ? (unread ? c : C.bgDark) : null,
          border: Border.all(
              color: isComic ? Colors.black
                  : (unread ? c.withValues(alpha: 0.55) : C.bgDark),
              width: isComic ? 4 : (unread ? 1.5 : 1)),
          boxShadow: isComic
              ? const [
                  BoxShadow(color: Colors.black, offset: Offset(5, 5),
                      blurRadius: 0),
                ]
              : [
                  BoxShadow(
                      color: unread
                          ? c.withValues(alpha: 0.15)
                          : Colors.black26,
                      blurRadius: unread ? 10 : 4,
                      spreadRadius: unread ? 1 : 0),
                  const BoxShadow(color: Colors.black54,
                      offset: Offset(0, 2), blurRadius: 4),
                ],
        ),
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Stack(
                alignment: Alignment.center,
                children: [
                  Container(
                    width: 42, height: 42,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      gradient: isComic ? null
                          : RadialGradient(
                              center: const Alignment(-0.35, -0.35),
                              colors: [
                                c.withValues(alpha: 0.35),
                                c.withValues(alpha: 0.12),
                                Colors.black.withValues(alpha: 0.85)],
                              stops: const [0.0, 0.5, 1.0]),
                      color: isComic ? Colors.white : null,
                      border: Border.all(
                          color: isComic ? Colors.black
                              : c.withValues(alpha: unread ? 0.85 : 0.4),
                          width: isComic ? 3 : 1.8)),
                    child: Icon(notif.icon,
                        color: isComic ? c : c, size: 20),
                  ),
                  if (unread && !isComic)
                    Positioned(top: -1, right: -1,
                        child: _Led(color: C.primaryHi, size: 7,
                            blink: true)),
                ],
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Expanded(
                          child: Text(notif.title,
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: TextStyle(
                                color: isComic
                                    ? (unread ? Colors.white : Colors.white)
                                    : (unread ? C.accentHi : C.accent),
                                fontSize: isComic ? 15 : 12,
                                fontWeight: FontWeight.w900,
                                fontFamily:
                                    isComic ? 'Bangers' : 'Orbitron',
                                letterSpacing: isComic ? 1 : 0.5,
                                height: 1.2,
                                shadows: isComic
                                    ? const [Shadow(
                                        color: Colors.black,
                                        offset: Offset(1, 1),
                                        blurRadius: 0)]
                                    : (unread
                                        ? const [Shadow(
                                            color: Colors.black,
                                            offset: Offset(0, 1),
                                            blurRadius: 2)]
                                        : null))),
                        ),
                        if (unread) ...[
                          const SizedBox(width: 6),
                          Container(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 5, vertical: 1),
                            decoration: BoxDecoration(
                              color: isComic ? Colors.black : C.primaryHi,
                              borderRadius:
                                  BorderRadius.circular(isComic ? 6 : 4),
                              border: isComic
                                  ? Border.all(
                                      color: Colors.white, width: 1.5)
                                  : null),
                            child: Text('BARU',
                                style: TextStyle(
                                  color: Colors.white,
                                  fontSize: isComic ? 9 : 7,
                                  fontWeight: FontWeight.w900,
                                  fontFamily: isComic
                                      ? 'Bangers'
                                      : 'Orbitron',
                                  letterSpacing: 0.8)),
                          ),
                        ],
                      ],
                    ),
                    const SizedBox(height: 4),
                    Text(notif.body,
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(
                          color: isComic
                              ? Colors.white.withValues(
                                  alpha: unread ? 0.9 : 0.7)
                              : C.text.withValues(
                                  alpha: unread ? 0.85 : 0.55),
                          fontSize: isComic ? 12 : 10.5,
                          fontFamily:
                              isComic ? 'ComicNeue' : 'ShareTechMono',
                          height: 1.35,
                          letterSpacing: 0.2)),
                    const SizedBox(height: 8),
                    Row(
                      children: [
                        Icon(Icons.schedule_rounded,
                            size: 10,
                            color: isComic
                                ? Colors.white.withValues(alpha: 0.6)
                                : C.text.withValues(alpha: 0.4)),
                        const SizedBox(width: 4),
                        Text(timeAgo,
                            style: TextStyle(
                              color: isComic
                                  ? Colors.white.withValues(alpha: 0.6)
                                  : C.text.withValues(alpha: 0.5),
                              fontSize: 9,
                              fontFamily:
                                  isComic ? 'ComicNeue' : 'ShareTechMono',
                              letterSpacing: 0.5)),
                        const SizedBox(width: 10),
                        Container(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 5, vertical: 1),
                          decoration: BoxDecoration(
                            color: isComic ? Colors.white
                                : c.withValues(alpha: 0.15),
                            borderRadius:
                                BorderRadius.circular(isComic ? 6 : 3),
                            border: Border.all(
                                color: isComic ? Colors.black
                                    : c.withValues(alpha: 0.5),
                                width: isComic ? 2 : 0.8)),
                          child: Text(notif.type.toUpperCase(),
                              style: TextStyle(
                                color: isComic ? c : c,
                                fontSize: isComic ? 9 : 7,
                                fontWeight: FontWeight.w900,
                                fontFamily: isComic
                                    ? 'Bangers'
                                    : 'Orbitron',
                                letterSpacing: 0.8)),
                        ),
                        const Spacer(),
                        GestureDetector(
                          onTap: () {
                            HapticFeedback.lightImpact();
                            onDelete();
                          },
                          child: Container(
                            padding: const EdgeInsets.all(4),
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              color: isComic ? Colors.white
                                  : Colors.black.withValues(alpha: 0.5),
                              border: Border.all(
                                  color: isComic ? Colors.black
                                      : C.primaryHi.withValues(alpha: 0.6),
                                  width: isComic ? 2.5 : 1)),
                            child: Icon(Icons.close_rounded,
                                size: isComic ? 13 : 11,
                                color: isComic ? Colors.black : C.primaryHi),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════
// COMIC HALFTONE PAINTER
// ═══════════════════════════════════════════════════════════
class _ComicHalftonePainter extends CustomPainter {
  final Color color;
  const _ComicHalftonePainter({required this.color});

  @override
  void paint(Canvas canvas, Size size) {
    const spacing = 22.0;
    final paint = Paint()..color = color;
    for (double x = 0; x < size.width + spacing; x += spacing) {
      for (double y = 0; y < size.height + spacing; y += spacing) {
        canvas.drawCircle(Offset(x, y), 2.5, paint);
      }
    }
  }

  @override
  bool shouldRepaint(_ComicHalftonePainter old) => old.color != color;
}