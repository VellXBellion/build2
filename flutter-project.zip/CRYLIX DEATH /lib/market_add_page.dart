// market_add_page.dart — Form jual produk (Support Style Switcher)
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:image_picker/image_picker.dart';

import 'app_theme.dart';
import 'market_api.dart';

class MarketAddPage extends StatefulWidget {
  final String username;
  final String sessionKey;

  const MarketAddPage({
    super.key,
    required this.username,
    required this.sessionKey,
  });

  @override
  State<MarketAddPage> createState() => _MarketAddPageState();
}

class _MarketAddPageState extends State<MarketAddPage> {
  final TextEditingController _namaCtrl = TextEditingController();
  final TextEditingController _hargaCtrl = TextEditingController();
  final TextEditingController _deskripsiCtrl = TextEditingController();
  final TextEditingController _waCtrl = TextEditingController();
  final TextEditingController _telegramCtrl = TextEditingController();

  File? _foto;
  String _selectedKategori = 'Lainnya';
  bool _isUploading = false;

  final List<String> _kategoriList = [
    'Elektronik', 'Fashion', 'Makanan', 'Jasa', 'Digital', 'Lainnya',
  ];

  @override
  void dispose() {
    _namaCtrl.dispose();
    _hargaCtrl.dispose();
    _deskripsiCtrl.dispose();
    _waCtrl.dispose();
    _telegramCtrl.dispose();
    super.dispose();
  }

  Future<void> _pickImage(AppPalette C, bool isComic,
      ImageSource source) async {
    try {
      final picker = ImagePicker();
      final picked = await picker.pickImage(
          source: source, imageQuality: 70, maxWidth: 1080);
      if (picked != null) {
        setState(() => _foto = File(picked.path));
      }
    } catch (e) {
      _showSnack(C, isComic, 'Gagal pilih gambar: $e', isError: true);
    }
  }

  void _showImageOptions(AppPalette C, bool isComic) {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      barrierColor: Colors.black.withValues(alpha: 0.85),
      builder: (ctx) => _MetalPlate(
        C: C,
        padding: const EdgeInsets.all(18),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(width: 50, height: isComic ? 5 : 4,
                margin: const EdgeInsets.only(bottom: 20),
                decoration: BoxDecoration(
                    color: isComic ? Colors.black : C.textSub,
                    borderRadius: BorderRadius.circular(3))),
            Text('PILIH SUMBER FOTO',
                style: TextStyle(
                  color: isComic ? Colors.black : C.accent,
                  fontSize: isComic ? 16 : 13,
                  fontWeight: FontWeight.w900,
                  fontFamily: isComic ? 'Bangers' : 'Orbitron',
                  letterSpacing: 2)),
            const SizedBox(height: 20),
            Row(
              children: [
                Expanded(child: _IndustrialButton(
                  C: C, color: C.accentHi, height: 52,
                  onTap: () {
                    Navigator.pop(ctx);
                    _pickImage(C, isComic, ImageSource.camera);
                  },
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      const Icon(Icons.camera_alt_rounded,
                          color: Colors.white, size: 16),
                      const SizedBox(width: 6),
                      Text('KAMERA',
                          style: TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight.w900,
                            fontFamily:
                                isComic ? 'Bangers' : 'Orbitron',
                            letterSpacing: 2,
                            fontSize: isComic ? 14 : 11)),
                    ],
                  ),
                )),
                const SizedBox(width: 10),
                Expanded(child: _IndustrialButton(
                  C: C, color: C.accentHi, height: 52,
                  onTap: () {
                    Navigator.pop(ctx);
                    _pickImage(C, isComic, ImageSource.gallery);
                  },
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      const Icon(Icons.photo_library_rounded,
                          color: Colors.white, size: 16),
                      const SizedBox(width: 6),
                      Text('GALERI',
                          style: TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight.w900,
                            fontFamily:
                                isComic ? 'Bangers' : 'Orbitron',
                            letterSpacing: 2,
                            fontSize: isComic ? 14 : 11)),
                    ],
                  ),
                )),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _submit(AppPalette C, bool isComic) async {
    final nama = _namaCtrl.text.trim();
    final hargaText = _hargaCtrl.text.replaceAll('.', '').trim();
    final harga = int.tryParse(hargaText) ?? 0;
    final deskripsi = _deskripsiCtrl.text.trim();
    final wa = _waCtrl.text.trim();
    final telegram = _telegramCtrl.text.trim();

    if (nama.length < 3) {
      _showSnack(C, isComic, 'Nama produk minimal 3 karakter',
          isError: true);
      return;
    }
    if (harga < 1000) {
      _showSnack(C, isComic, 'Harga minimal Rp 1.000', isError: true);
      return;
    }
    if (_foto == null) {
      _showSnack(C, isComic, 'Upload foto produk dulu!', isError: true);
      return;
    }
    if (wa.isEmpty && telegram.isEmpty) {
      _showSnack(C, isComic,
          'Isi minimal 1 kontak (WA atau Telegram)', isError: true);
      return;
    }

    setState(() => _isUploading = true);

    try {
      final result = await MarketApi.addProduct(
        sessionKey: widget.sessionKey,
        nama: nama, harga: harga, deskripsi: deskripsi,
        kategori: _selectedKategori, wa: wa, telegram: telegram,
        foto: _foto!,
      );
      if (!mounted) return;
      if (result['valid'] == true) {
        _showSuccessDialog(C, isComic);
      } else {
        _showSnack(C, isComic,
            result['message'] ?? 'Gagal upload', isError: true);
      }
    } catch (e) {
      if (mounted) {
        _showSnack(C, isComic, 'Error: $e', isError: true);
      }
    } finally {
      if (mounted) setState(() => _isUploading = false);
    }
  }

  void _showSuccessDialog(AppPalette C, bool isComic) {
    showDialog(
      context: context,
      barrierDismissible: false,
      barrierColor: Colors.black.withValues(alpha: 0.85),
      builder: (ctx) => Dialog(
        backgroundColor: Colors.transparent,
        insetPadding: const EdgeInsets.all(24),
        child: _MetalPlate(
          C: C,
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                width: 60, height: 60,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: isComic ? null
                      : RadialGradient(colors: [
                          C.primaryHi, C.primary, Colors.black]),
                  color: isComic ? C.primaryHi : null,
                  border: Border.all(
                      color: isComic ? Colors.black : C.primaryHi,
                      width: isComic ? 4 : 2.5)),
                child: Icon(Icons.check_rounded,
                    color: isComic ? Colors.white : C.primaryHi,
                    size: 30),
              ),
              const SizedBox(height: 18),
              Text('BERHASIL!',
                  style: TextStyle(
                    color: isComic ? Colors.black : C.accent,
                    fontSize: isComic ? 22 : 15,
                    fontWeight: FontWeight.w900,
                    fontFamily: isComic ? 'Bangers' : 'Orbitron',
                    letterSpacing: 2.5)),
              const SizedBox(height: 10),
              Text('Produk lu berhasil dipasang di Pasar Online.\nUser lain bisa liat & hubungi lu sekarang!',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    color: isComic
                        ? Colors.black.withValues(alpha: 0.7)
                        : C.text.withValues(alpha: 0.75),
                    fontSize: isComic ? 13 : 11,
                    fontFamily: isComic ? 'ComicNeue' : 'ShareTechMono',
                    height: 1.5)),
              const SizedBox(height: 20),
              _IndustrialButton(
                C: C, color: C.primaryHi, height: 46,
                onTap: () {
                  Navigator.pop(ctx);
                  Navigator.pop(context, true);
                },
                child: Text('OKE',
                    style: TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.w900,
                      fontFamily: isComic ? 'Bangers' : 'Orbitron',
                      letterSpacing: 2.5,
                      fontSize: isComic ? 16 : 12)),
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _showSnack(AppPalette C, bool isComic, String msg,
      {bool isError = false}) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Row(children: [
          _Led(color: isError ? C.primaryHi : C.primaryHi, size: 8,
              blink: !isComic),
          const SizedBox(width: 10),
          Expanded(
            child: Text(msg,
                style: TextStyle(
                  fontWeight: FontWeight.w700,
                  fontFamily:
                      isComic ? 'ComicNeue' : 'ShareTechMono',
                  color: C.text,
                  fontSize: isComic ? 13 : 12)),
          ),
        ]),
        backgroundColor: C.bgDark,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(isComic ? 12 : 8),
          side: BorderSide(
              color: isError ? C.primaryHi : C.primaryHi,
              width: isComic ? 3 : 1.5)),
        margin: const EdgeInsets.all(16),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<AppPalette>(
      valueListenable: AppTheme.current,
      builder: (context, C, _) {
        return ValueListenableBuilder<ThemeStyle>(
          valueListenable: AppTheme.currentStyle,
          builder: (context, style, __) {
            final isComic = style == ThemeStyle.comic3d;

            return Scaffold(
              backgroundColor: C.bgDeep,
              body: Container(
                decoration: isComic
                    ? BoxDecoration(color: C.bg)
                    : BoxDecoration(
                        gradient: RadialGradient(
                          center: const Alignment(-0.3, -0.3),
                          radius: 1.2,
                          colors: [C.bg, C.bgDark, C.bgDeep],
                          stops: const [0.0, 0.6, 1.0])),
                child: Stack(
                  children: [
                    if (isComic)
                      Positioned.fill(
                        child: IgnorePointer(
                          child: CustomPaint(
                            painter: _ComicHalftonePainter(
                                color: C.primaryLo.withValues(
                                    alpha: 0.12))))),
                    SafeArea(
                      child: Column(
                        children: [
                          _buildAppBar(C, isComic),
                          const SizedBox(height: 10),
                          Expanded(
                            child: SingleChildScrollView(
                              padding: const EdgeInsets.fromLTRB(
                                  14, 4, 14, 32),
                              physics: const BouncingScrollPhysics(),
                              child: Column(
                                crossAxisAlignment:
                                    CrossAxisAlignment.start,
                                children: [
                                  _sectionTitle(C, isComic,
                                      '1. FOTO PRODUK',
                                      Icons.image_rounded),
                                  const SizedBox(height: 10),
                                  _buildFotoUploader(C, isComic),
                                  const SizedBox(height: 18),
                                  _sectionTitle(C, isComic,
                                      '2. NAMA PRODUK',
                                      Icons.label_rounded),
                                  const SizedBox(height: 10),
                                  _input(C, isComic,
                                      controller: _namaCtrl,
                                      hint: 'Contoh: Kaos Polos Premium',
                                      icon: Icons.label_rounded,
                                      maxLength: 100),
                                  const SizedBox(height: 18),
                                  _sectionTitle(C, isComic,
                                      '3. HARGA',
                                      Icons.attach_money_rounded),
                                  const SizedBox(height: 10),
                                  _hargaInput(C, isComic),
                                  const SizedBox(height: 18),
                                  _sectionTitle(C, isComic,
                                      '4. DESKRIPSI',
                                      Icons.description_rounded),
                                  const SizedBox(height: 10),
                                  _input(C, isComic,
                                      controller: _deskripsiCtrl,
                                      hint:
                                          'Jelaskan detail produk lu...',
                                      icon: Icons.description_rounded,
                                      maxLines: 4,
                                      maxLength: 500),
                                  const SizedBox(height: 18),
                                  _sectionTitle(C, isComic,
                                      '5. KATEGORI',
                                      Icons.category_rounded),
                                  const SizedBox(height: 10),
                                  _kategoriPicker(C, isComic),
                                  const SizedBox(height: 18),
                                  _sectionTitle(C, isComic,
                                      '6. KONTAK PENJUAL',
                                      Icons.contact_phone_rounded),
                                  const SizedBox(height: 4),
                                  Text(
                                      'Isi minimal salah satu (WA atau Telegram)',
                                      style: TextStyle(
                                        color: isComic
                                            ? Colors.black.withValues(
                                                alpha: 0.6)
                                            : C.text.withValues(
                                                alpha: 0.5),
                                        fontSize: isComic ? 12 : 10,
                                        fontFamily: isComic
                                            ? 'ComicNeue'
                                            : 'ShareTechMono')),
                                  const SizedBox(height: 10),
                                  _input(C, isComic,
                                      controller: _waCtrl,
                                      hint: 'Contoh: +62812xxxxxxxx',
                                      icon: Icons.phone_rounded,
                                      keyboardType:
                                          TextInputType.phone),
                                  const SizedBox(height: 10),
                                  _input(C, isComic,
                                      controller: _telegramCtrl,
                                      hint: 'Contoh: @username',
                                      icon: Icons.send_rounded),
                                  const SizedBox(height: 24),
                                  _IndustrialButton(
                                    C: C,
                                    color: _isUploading
                                        ? C.bg
                                        : C.primaryHi,
                                    height: 54,
                                    onTap: _isUploading
                                        ? null
                                        : () => _submit(C, isComic),
                                    child: Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.center,
                                      children: [
                                        if (_isUploading)
                                          SizedBox(
                                              width: 18, height: 18,
                                              child:
                                                  CircularProgressIndicator(
                                                      strokeWidth: 2.5,
                                                      valueColor: AlwaysStoppedAnimation<Color>(
                                                          C.accent)))
                                        else
                                          const Icon(
                                              Icons.storefront_rounded,
                                              color: Colors.white,
                                              size: 16),
                                        const SizedBox(width: 10),
                                        Text(
                                            _isUploading
                                                ? 'MENGUPLOAD...'
                                                : 'JUAL SEKARANG',
                                            style: TextStyle(
                                              color: Colors.white,
                                              fontWeight:
                                                  FontWeight.w900,
                                              fontFamily: isComic
                                                  ? 'Bangers'
                                                  : 'Orbitron',
                                              letterSpacing: 2,
                                              fontSize:
                                                  isComic ? 16 : 12)),
                                      ],
                                    ),
                                  ),
                                  const SizedBox(height: 12),
                                  Text(
                                    'Produk lu bakal muncul di Pasar Online.\nPastiin data bener sebelum jual ya!',
                                    textAlign: TextAlign.center,
                                    style: TextStyle(
                                      color: isComic
                                          ? Colors.black.withValues(
                                              alpha: 0.6)
                                          : C.text.withValues(
                                              alpha: 0.5),
                                      fontSize: isComic ? 12 : 10,
                                      fontFamily: isComic
                                          ? 'ComicNeue'
                                          : 'ShareTechMono',
                                      height: 1.5),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            );
          },
        );
      },
    );
  }

  Widget _buildAppBar(AppPalette C, bool isComic) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(12, 8, 12, 0),
      child: _MetalPlate(
        C: C,
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
        child: Row(
          children: [
            _IconButton(
              C: C, isComic: isComic,
              icon: Icons.arrow_back_rounded,
              color: C.accent,
              onTap: () => Navigator.pop(context),
            ),
            const SizedBox(width: 12),
            Stack(
              alignment: Alignment.center,
              children: [
                Container(
                  width: 40, height: 40,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    gradient: isComic ? null
                        : RadialGradient(
                            colors: [C.text, C.bg, C.bgDark]),
                    color: isComic ? C.primaryHi : null,
                    border: Border.all(
                        color: isComic ? Colors.black : C.primaryHi,
                        width: isComic ? 3 : 2)),
                  child: Icon(Icons.add_box_rounded,
                      color: isComic ? Colors.white : C.primaryHi,
                      size: 20),
                ),
                if (!isComic)
                  Positioned(top: -2, right: -2,
                      child: _Led(color: C.primaryHi, size: 6,
                          blink: true)),
              ],
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('JUAL PRODUK',
                      style: TextStyle(
                        color: isComic ? Colors.black : C.accentHi,
                        fontSize: isComic ? 18 : 13,
                        fontWeight: FontWeight.w900,
                        fontFamily: isComic ? 'Bangers' : 'Orbitron',
                        letterSpacing: isComic ? 1.5 : 2, height: 1,
                        shadows: isComic ? null : [
                          Shadow(color: C.primaryLo,
                              offset: const Offset(0, 1), blurRadius: 1),
                          const Shadow(color: Colors.black,
                              offset: Offset(0, 2), blurRadius: 3),
                        ])),
                  const SizedBox(height: 3),
                  Row(children: [
                    _Led(color: C.primaryHi, size: 4, blink: !isComic),
                    const SizedBox(width: 5),
                    Text('ISI DATA PRODUK',
                        style: TextStyle(
                          color: isComic
                              ? Colors.black.withValues(alpha: 0.5)
                              : C.text.withValues(alpha: 0.55),
                          fontSize: 8,
                          fontWeight: FontWeight.w700,
                          fontFamily:
                              isComic ? 'ComicNeue' : 'ShareTechMono',
                          letterSpacing: 1.2)),
                  ]),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _sectionTitle(AppPalette C, bool isComic, String title,
      IconData icon) {
    return Row(
      children: [
        Container(
          width: 28, height: 28,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            gradient: isComic ? null
                : RadialGradient(colors: [C.text, C.bg, C.bgDark]),
            color: isComic ? C.primaryHi : null,
            border: Border.all(
                color: isComic ? Colors.black : C.accent,
                width: isComic ? 3 : 1.5)),
          child: Icon(icon,
              color: isComic ? Colors.white : C.accent, size: 14),
        ),
        const SizedBox(width: 10),
        Expanded(
          child: Text(title,
              style: TextStyle(
                color: isComic ? Colors.black : C.accent,
                fontSize: isComic ? 15 : 11,
                fontWeight: FontWeight.w900,
                fontFamily: isComic ? 'Bangers' : 'Orbitron',
                letterSpacing: 1.5)),
        ),
        if (!isComic) _Rivet(C: C, size: 6),
      ],
    );
  }

  Widget _buildFotoUploader(AppPalette C, bool isComic) {
    if (_foto != null) {
      return _MetalPlate(
        C: C,
        padding: const EdgeInsets.all(12),
        child: Column(
          children: [
            ClipRRect(
              borderRadius: BorderRadius.circular(isComic ? 12 : 10),
              child: Image.file(_foto!,
                  width: double.infinity, height: 220,
                  fit: BoxFit.cover),
            ),
            const SizedBox(height: 12),
            Row(
              children: [
                Expanded(child: _IndustrialButton(
                  C: C, color: C.accent, height: 44,
                  onTap: () => _showImageOptions(C, isComic),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      const Icon(Icons.refresh_rounded,
                          color: Colors.white, size: 14),
                      const SizedBox(width: 6),
                      Text('GANTI',
                          style: TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight.w900,
                            fontFamily:
                                isComic ? 'Bangers' : 'Orbitron',
                            letterSpacing: 2,
                            fontSize: isComic ? 14 : 11)),
                    ],
                  ),
                )),
                const SizedBox(width: 8),
                Expanded(child: _IndustrialButton(
                  C: C, color: C.primaryHi, height: 44,
                  onTap: () => setState(() => _foto = null),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      const Icon(Icons.delete_rounded,
                          color: Colors.white, size: 14),
                      const SizedBox(width: 6),
                      Text('HAPUS',
                          style: TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight.w900,
                            fontFamily:
                                isComic ? 'Bangers' : 'Orbitron',
                            letterSpacing: 2,
                            fontSize: isComic ? 14 : 11)),
                    ],
                  ),
                )),
              ],
            ),
          ],
        ),
      );
    }

    return GestureDetector(
      onTap: () => _showImageOptions(C, isComic),
      child: _InsetPanel(
        C: C,
        isComic: isComic,
        padding: const EdgeInsets.symmetric(vertical: 44),
        child: Column(
          children: [
            Container(
              width: 64, height: 64,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: isComic ? null
                    : RadialGradient(
                        colors: [C.text, C.bg, C.bgDark]),
                color: isComic ? C.primaryHi : null,
                border: Border.all(
                    color: isComic ? Colors.black : C.accent,
                    width: isComic ? 4 : 2)),
              child: Icon(Icons.cloud_upload_rounded,
                  color: isComic ? Colors.white : C.accent, size: 28),
            ),
            const SizedBox(height: 14),
            Text('TAP UNTUK UPLOAD FOTO',
                style: TextStyle(
                  color: isComic ? Colors.black : C.accent,
                  fontSize: isComic ? 16 : 13,
                  fontWeight: FontWeight.w900,
                  fontFamily: isComic ? 'Bangers' : 'Orbitron',
                  letterSpacing: 1.5)),
            const SizedBox(height: 4),
            Text('Format: JPG / PNG (max 5MB)',
                style: TextStyle(
                  color: isComic
                      ? Colors.black.withValues(alpha: 0.6)
                      : C.text.withValues(alpha: 0.5),
                  fontSize: isComic ? 12 : 10,
                  fontFamily: isComic ? 'ComicNeue' : 'ShareTechMono',
                  fontWeight: FontWeight.w600)),
          ],
        ),
      ),
    );
  }

  Widget _input(AppPalette C, bool isComic, {
    required TextEditingController controller,
    required String hint,
    required IconData icon,
    TextInputType? keyboardType,
    int maxLines = 1,
    int? maxLength,
  }) {
    return Container(
      decoration: isComic
          ? BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: Colors.black, width: 3))
          : BoxDecoration(
              borderRadius: BorderRadius.circular(10),
              gradient: LinearGradient(
                  colors: [C.bgDeep, C.bgDark]),
              border: Border.all(color: C.bgDark, width: 1.5),
              boxShadow: [
                BoxShadow(color: Colors.black.withValues(alpha: 0.8),
                    offset: const Offset(0, 1), blurRadius: 2),
              ]),
      padding: const EdgeInsets.symmetric(horizontal: 12),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding:
                EdgeInsets.only(top: maxLines > 1 ? 14 : 16),
            child: Icon(icon,
                color: isComic ? Colors.black : C.accent, size: 18),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: TextField(
              controller: controller,
              keyboardType: keyboardType,
              maxLines: maxLines,
              maxLength: maxLength,
              style: TextStyle(
                color: isComic ? Colors.black : C.text,
                fontSize: isComic ? 14 : 13,
                fontFamily: isComic ? 'ComicNeue' : 'ShareTechMono',
                fontWeight: FontWeight.w700),
              cursorColor: isComic ? Colors.black : C.primaryHi,
              decoration: InputDecoration(
                hintText: hint,
                hintStyle: TextStyle(
                  color: isComic
                      ? Colors.black.withValues(alpha: 0.4)
                      : C.text.withValues(alpha: 0.4),
                  fontFamily:
                      isComic ? 'ComicNeue' : 'ShareTechMono',
                  fontSize: isComic ? 13 : 11),
                border: InputBorder.none,
                contentPadding:
                    const EdgeInsets.symmetric(vertical: 14),
                counterStyle: TextStyle(
                  color: isComic
                      ? Colors.black.withValues(alpha: 0.4)
                      : C.text.withValues(alpha: 0.4),
                  fontSize: 9,
                  fontFamily:
                      isComic ? 'ComicNeue' : 'ShareTechMono'),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _hargaInput(AppPalette C, bool isComic) {
    return _MetalPlate(
      C: C,
      padding: EdgeInsets.zero,
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.symmetric(
                horizontal: 14, vertical: 14),
            decoration: BoxDecoration(
              gradient: isComic ? null
                  : LinearGradient(
                      colors: [C.primaryHi, C.primaryLo]),
              color: isComic ? C.primaryHi : null,
              borderRadius: const BorderRadius.horizontal(
                  left: Radius.circular(13))),
            child: Text('Rp',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: isComic ? 18 : 14,
                  fontWeight: FontWeight.w900,
                  fontFamily: isComic ? 'Bangers' : 'Orbitron',
                  shadows: isComic
                      ? const [Shadow(
                          color: Colors.black, offset: Offset(1, 1),
                          blurRadius: 0)]
                      : null)),
          ),
          Expanded(
            child: TextField(
              controller: _hargaCtrl,
              keyboardType: TextInputType.number,
              inputFormatters: [
                FilteringTextInputFormatter.digitsOnly
              ],
              style: TextStyle(
                color: isComic ? Colors.black : C.text,
                fontSize: isComic ? 18 : 16,
                fontWeight: FontWeight.w900,
                fontFamily: isComic ? 'Bangers' : 'Orbitron',
                letterSpacing: 0.5),
              cursorColor: isComic ? Colors.black : C.primaryHi,
              decoration: InputDecoration(
                hintText: '0',
                hintStyle: TextStyle(
                  color: isComic
                      ? Colors.black.withValues(alpha: 0.4)
                      : C.text.withValues(alpha: 0.3),
                  fontSize: isComic ? 18 : 16,
                  fontWeight: FontWeight.w900,
                  fontFamily:
                      isComic ? 'Bangers' : 'Orbitron'),
                border: InputBorder.none,
                contentPadding: const EdgeInsets.symmetric(
                    horizontal: 14, vertical: 14)),
            ),
          ),
        ],
      ),
    );
  }

  Widget _kategoriPicker(AppPalette C, bool isComic) {
    return Wrap(
      spacing: 8, runSpacing: 8,
      children: _kategoriList.map((kat) {
        final isActive = kat == _selectedKategori;
        return GestureDetector(
          onTap: () {
            HapticFeedback.selectionClick();
            setState(() => _selectedKategori = kat);
          },
          child: Container(
            padding: const EdgeInsets.symmetric(
                horizontal: 14, vertical: 10),
            decoration: BoxDecoration(
              borderRadius:
                  BorderRadius.circular(isComic ? 12 : 10),
              gradient: isActive && !isComic
                  ? LinearGradient(colors: [
                      C.accentHi.withValues(alpha: 0.9),
                      C.accent.withValues(alpha: 0.6)])
                  : (isComic ? null
                      : LinearGradient(colors: [
                          C.textSub.withValues(alpha: 0.9),
                          C.bg.withValues(alpha: 0.6)])),
              color: isComic
                  ? (isActive ? C.primaryHi : C.bgDark)
                  : null,
              border: Border.all(
                color: isComic
                    ? Colors.black
                    : (isActive
                        ? C.accentHi
                        : C.text.withValues(alpha: 0.4)),
                width: isComic ? 3 : (isActive ? 2 : 1),
              ),
              boxShadow: isComic
                  ? const [
                      BoxShadow(color: Colors.black,
                          offset: Offset(3, 3), blurRadius: 0),
                    ]
                  : (isActive
                      ? [BoxShadow(
                          color: C.accentHi.withValues(alpha: 0.4),
                          blurRadius: 8)]
                      : null),
            ),
            child: Text(kat,
                style: TextStyle(
                  color: isComic
                      ? (isActive ? Colors.white : Colors.black)
                      : (isActive ? C.bgDeep : C.text),
                  fontSize: isComic ? 13 : 11,
                  fontWeight: FontWeight.w900,
                  fontFamily: isComic ? 'Bangers' : 'Orbitron',
                  letterSpacing: 0.5)),
          ),
        );
      }).toList(),
    );
  }
}

// ═══════════════════════════════════════════════════════════
// HELPER WIDGETS
// ═══════════════════════════════════════════════════════════
class _Led extends StatelessWidget {
  final Color color;
  final double size;
  final bool blink;
  const _Led({required this.color, this.size = 8, this.blink = false});

  @override
  Widget build(BuildContext context) {
    final isComic = AppTheme.currentStyle.value == ThemeStyle.comic3d;
    if (isComic) {
      return Container(
        width: size, height: size,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          color: color,
          border: Border.all(color: Colors.black, width: size * 0.18)));
    }
    return Container(
      width: size, height: size,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        gradient: RadialGradient(
          center: const Alignment(-0.35, -0.35),
          colors: [
            Colors.white.withValues(alpha: 0.85),
            color.withValues(alpha: 0.9),
            color.withValues(alpha: 0.55),
          ],
          stops: const [0.0, 0.4, 1.0]),
        border: Border.all(
            color: Colors.black.withValues(alpha: 0.85),
            width: size * 0.1),
        boxShadow: [
          BoxShadow(color: color.withValues(alpha: 0.75),
              blurRadius: size * 1.4, spreadRadius: size * 0.2),
        ]),
    );
  }
}

class _Rivet extends StatelessWidget {
  final AppPalette C;
  final double size;
  const _Rivet({required this.C, this.size = 10});
  @override
  Widget build(BuildContext context) {
    if (AppTheme.currentStyle.value == ThemeStyle.comic3d) {
      return const SizedBox.shrink();
    }
    return Container(
      width: size, height: size,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        gradient: RadialGradient(
          center: const Alignment(-0.35, -0.35),
          colors: [C.accentShine, C.accentHi, C.accent, C.primaryLo],
          stops: const [0.0, 0.3, 0.65, 1.0])),
    );
  }
}

class _MetalPlate extends StatelessWidget {
  final AppPalette C;
  final Widget child;
  final EdgeInsets padding;
  final bool brass;
  final double radius;
  const _MetalPlate({
    required this.C,
    required this.child,
    this.padding = const EdgeInsets.all(16),
    this.brass = false,
    this.radius = 16,
  });

  @override
  Widget build(BuildContext context) {
    final isComic = AppTheme.currentStyle.value == ThemeStyle.comic3d;
    if (isComic) {
      return Container(
        padding: padding,
        decoration: BoxDecoration(
          color: brass ? C.primaryHi : C.bgDark,
          borderRadius: BorderRadius.circular(radius + 4),
          border: Border.all(color: Colors.black, width: 4),
          boxShadow: const [
            BoxShadow(color: Colors.black, offset: Offset(6, 6),
                blurRadius: 0),
          ]),
        child: child,
      );
    }
    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(radius),
        gradient: LinearGradient(
          begin: Alignment.topLeft, end: Alignment.bottomRight,
          colors: brass
              ? [C.accentHi, C.accent, C.primary, C.primaryLo]
              : [C.text, C.bg, C.bgDark, C.bgDeep],
          stops: const [0.0, 0.4, 0.7, 1.0]),
        boxShadow: [
          BoxShadow(color: Colors.black.withValues(alpha: 0.75),
              offset: const Offset(0, 6), blurRadius: 12),
        ],
      ),
      padding: const EdgeInsets.all(3),
      child: Container(
        padding: padding,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(radius - 3),
          gradient: LinearGradient(
            begin: Alignment.topCenter, end: Alignment.bottomCenter,
            colors: [C.bg, C.bgDark, C.bgDeep]),
          border: Border.all(color: Colors.black.withValues(alpha: 0.5)),
        ),
        child: child,
      ),
    );
  }
}

class _InsetPanel extends StatelessWidget {
  final AppPalette C;
  final bool isComic;
  final Widget child;
  final EdgeInsets padding;
  const _InsetPanel({
    required this.C,
    required this.isComic,
    required this.child,
    this.padding = const EdgeInsets.all(12),
  });

  @override
  Widget build(BuildContext context) {
    if (isComic) {
      return Container(
        padding: padding,
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: Colors.black, width: 3)),
        child: child,
      );
    }
    return Container(
      padding: padding,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(10),
        gradient: LinearGradient(
            colors: [C.bgDeep, C.bgDark]),
        boxShadow: [
          BoxShadow(color: Colors.black.withValues(alpha: 0.95),
              offset: const Offset(0, 2), blurRadius: 4),
        ],
        border: Border.all(color: C.bgDark, width: 1.5),
      ),
      child: child,
    );
  }
}

class _IndustrialButton extends StatefulWidget {
  final AppPalette C;
  final Widget child;
  final VoidCallback? onTap;
  final Color color;
  final double height;
  const _IndustrialButton({
    required this.C,
    required this.child,
    required this.onTap,
    required this.color,
    this.height = 56,
  });

  @override
  State<_IndustrialButton> createState() => _IndustrialButtonState();
}

class _IndustrialButtonState extends State<_IndustrialButton> {
  bool _pressed = false;

  @override
  Widget build(BuildContext context) {
    final C = widget.C;
    final enabled = widget.onTap != null;
    final isComic = AppTheme.currentStyle.value == ThemeStyle.comic3d;
    final light = _lighten(widget.color);
    final dark = _darken(widget.color);

    return GestureDetector(
      onTapDown: enabled ? (_) => setState(() => _pressed = true) : null,
      onTapUp: enabled ? (_) {
        setState(() => _pressed = false);
        widget.onTap?.call();
      } : null,
      onTapCancel: enabled ? () => setState(() => _pressed = false) : null,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 80),
        height: widget.height,
        transform: isComic
            ? Matrix4.translationValues(
                _pressed ? 4 : 0, _pressed ? 4 : 0, 0)
            : null,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(isComic ? 12 : 12),
          gradient: isComic ? null
              : LinearGradient(
                  begin: _pressed
                      ? Alignment.bottomCenter
                      : Alignment.topCenter,
                  end: _pressed
                      ? Alignment.topCenter
                      : Alignment.bottomCenter,
                  colors: _pressed
                      ? [dark, dark, widget.color]
                      : [light, widget.color, dark],
                  stops: const [0.0, 0.5, 1.0]),
          color: isComic ? widget.color : null,
          border: Border.all(
              color: isComic ? Colors.black
                  : dark.withValues(alpha: 0.9),
              width: isComic ? 3.5 : 1.5),
          boxShadow: isComic
              ? (_pressed ? [] : const [
                  BoxShadow(color: Colors.black,
                      offset: Offset(4, 4), blurRadius: 0),
                ])
              : null,
        ),
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 20),
          child: Center(
            child: Opacity(
                opacity: enabled ? 1 : 0.5, child: widget.child)),
        ),
      ),
    );
  }

  static Color _lighten(Color c) => Color.fromARGB(c.alpha,
      (c.red + 40).clamp(0, 255),
      (c.green + 40).clamp(0, 255),
      (c.blue + 30).clamp(0, 255));
  static Color _darken(Color c) => Color.fromARGB(c.alpha,
      (c.red - 60).clamp(0, 255),
      (c.green - 50).clamp(0, 255),
      (c.blue - 40).clamp(0, 255));
}

class _IconButton extends StatefulWidget {
  final AppPalette C;
  final bool isComic;
  final IconData icon;
  final VoidCallback onTap;
  final Color color;
  final double size;
  const _IconButton({
    required this.C,
    required this.isComic,
    required this.icon,
    required this.onTap,
    required this.color,
    this.size = 40,
  });

  @override
  State<_IconButton> createState() => _IconButtonState();
}

class _IconButtonState extends State<_IconButton> {
  bool _pressed = false;
  @override
  Widget build(BuildContext context) {
    final C = widget.C;
    return GestureDetector(
      onTapDown: (_) => setState(() => _pressed = true),
      onTapUp: (_) {
        setState(() => _pressed = false);
        widget.onTap();
      },
      onTapCancel: () => setState(() => _pressed = false),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 80),
        width: widget.size, height: widget.size,
        transform: widget.isComic
            ? Matrix4.translationValues(
                _pressed ? 2 : 0, _pressed ? 2 : 0, 0)
            : null,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(10),
          gradient: widget.isComic ? null
              : LinearGradient(
                  begin: _pressed
                      ? Alignment.bottomCenter
                      : Alignment.topCenter,
                  end: _pressed
                      ? Alignment.topCenter
                      : Alignment.bottomCenter,
                  colors: _pressed
                      ? [C.bgDark, C.bg]
                      : [C.textSub, C.bg, C.bgDark]),
          color: widget.isComic ? C.accent : null,
          border: Border.all(
              color: widget.isComic ? Colors.black
                  : Colors.black.withValues(alpha: 0.7),
              width: widget.isComic ? 3 : 1.2),
          boxShadow: widget.isComic
              ? (_pressed ? [] : const [
                  BoxShadow(color: Colors.black,
                      offset: Offset(3, 3), blurRadius: 0),
                ])
              : null,
        ),
        child: Icon(widget.icon,
            color: widget.isComic ? Colors.white : widget.color,
            size: widget.size * 0.5),
      ),
    );
  }
}

class _ComicHalftonePainter extends CustomPainter {
  final Color color;
  const _ComicHalftonePainter({required this.color});

  @override
  void paint(Canvas canvas, Size size) {
    const spacing = 22.0;
    final paint = Paint()..color = color;
    for (double x = 0; x < size.width + spacing; x += spacing) {
      for (double y = 0; y < size.height + spacing; y += spacing) {
        canvas.drawCircle(Offset(x, y), 2.5, paint);
      }
    }
  }

  @override
  bool shouldRepaint(_ComicHalftonePainter old) => old.color != color;
}