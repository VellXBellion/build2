// lib/app_theme.dart
import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

enum ThemeStyle { original, comic3d }

class ThemeStyleInfo {
  final ThemeStyle style;
  final String name;
  final String id;
  final String description;
  final IconData icon;

  const ThemeStyleInfo({
    required this.style,
    required this.name,
    required this.id,
    required this.description,
    required this.icon,
  });

  static const List<ThemeStyleInfo> all = [
    ThemeStyleInfo(
      style: ThemeStyle.original,
      name: 'ORIGINAL',
      id: 'original',
      description: 'Industrial metal · tactical · dark',
      icon: Icons.bolt_rounded,
    ),
    ThemeStyleInfo(
      style: ThemeStyle.comic3d,
      name: '3D COMIC',
      id: 'comic3d',
      description: 'Pop art · bold outline · playful',
      icon: Icons.bubble_chart_rounded,
    ),
  ];

  static ThemeStyleInfo getById(String id) {
    return all.firstWhere((s) => s.id == id, orElse: () => all.first);
  }
}

class AppPalette {
  final String name;
  final String id;
  final Color primary;
  final Color primaryHi;
  final Color primaryLo;
  final Color accent;
  final Color accentHi;
  final Color accentShine;
  final Color bg;
  final Color bgDark;
  final Color bgDeep;
  final Color text;
  final Color textSub;

  const AppPalette({
    required this.name,
    required this.id,
    required this.primary,
    required this.primaryHi,
    required this.primaryLo,
    required this.accent,
    required this.accentHi,
    required this.accentShine,
    required this.bg,
    required this.bgDark,
    required this.bgDeep,
    required this.text,
    required this.textSub,
  });
}

class AppPalettes {
  // ══════════════════════════════════════════════════════════
  // ═══ KATEGORI 1: DARK & BOLD (7) ═══
  // ══════════════════════════════════════════════════════════
  static const cyberBlue = AppPalette(
    name: 'Cyber Blue', id: 'cyber_blue',
    primary: Color(0xFF1976D2), primaryHi: Color(0xFF42A5F5),
    primaryLo: Color(0xFF0D47A1), accent: Color(0xFF00E5FF),
    accentHi: Color(0xFF80DEEA), accentShine: Color(0xFFE0F7FA),
    bg: Color(0xFF0A0A14), bgDark: Color(0xFF0A1420),
    bgDeep: Color(0xFF000000), text: Color(0xFFF0F8FF),
    textSub: Color(0xFF78909C),
  );


  static const bloodRed = AppPalette(
    name: 'Blood Red', id: 'blood_red',
    primary: Color(0xFFCC1010), primaryHi: Color(0xFFFF3030),
    primaryLo: Color(0xFF4A0000), accent: Color(0xFFD4AF37),
    accentHi: Color(0xFFF5DEB3), accentShine: Color(0xFFFFF3B0),
    bg: Color(0xFF0A0A0A), bgDark: Color(0xFF1A0A0A),
    bgDeep: Color(0xFF000000), text: Color(0xFFF5F0E8),
    textSub: Color(0xFF8A8A8A),
  );

  static const neonGreen = AppPalette(
    name: 'Neon Green', id: 'neon_green',
    primary: Color(0xFF00C853), primaryHi: Color(0xFF00E676),
    primaryLo: Color(0xFF1B5E20), accent: Color(0xFF76FF03),
    accentHi: Color(0xFFB2FF59), accentShine: Color(0xFFCCFF90),
    bg: Color(0xFF0A1408), bgDark: Color(0xFF0D2010),
    bgDeep: Color(0xFF000000), text: Color(0xFFE8F5E9),
    textSub: Color(0xFF66BB6A),
  );

  static const purpleMystic = AppPalette(
    name: 'Purple Mystic', id: 'purple_mystic',
    primary: Color(0xFF9C27B0), primaryHi: Color(0xFFCE93D8),
    primaryLo: Color(0xFF4A148C), accent: Color(0xFFE040FB),
    accentHi: Color(0xFFEA80FC), accentShine: Color(0xFFF3E5F5),
    bg: Color(0xFF0F0A14), bgDark: Color(0xFF1A0F20),
    bgDeep: Color(0xFF000000), text: Color(0xFFF3E5F5),
    textSub: Color(0xFF9575CD),
  );

  static const goldRoyal = AppPalette(
    name: 'Gold Royal', id: 'gold_royal',
    primary: Color(0xFFD4AF37), primaryHi: Color(0xFFF5DEB3),
    primaryLo: Color(0xFF6B5015), accent: Color(0xFFFFD700),
    accentHi: Color(0xFFFFF3B0), accentShine: Color(0xFFFFFDE7),
    bg: Color(0xFF141008), bgDark: Color(0xFF201808),
    bgDeep: Color(0xFF000000), text: Color(0xFFFFF8E1),
    textSub: Color(0xFFBCAAA4),
  );

  static const pinkNeon = AppPalette(
    name: 'Pink Neon', id: 'pink_neon',
    primary: Color(0xFFE91E63), primaryHi: Color(0xFFFF4081),
    primaryLo: Color(0xFF880E4F), accent: Color(0xFFFF80AB),
    accentHi: Color(0xFFFFB1C1), accentShine: Color(0xFFFFE4EC),
    bg: Color(0xFF140A10), bgDark: Color(0xFF200F18),
    bgDeep: Color(0xFF000000), text: Color(0xFFFFF0F5),
    textSub: Color(0xFFF48FB1),
  );

  static const orangeFire = AppPalette(
    name: 'Orange Fire', id: 'orange_fire',
    primary: Color(0xFFE65100), primaryHi: Color(0xFFFF9800),
    primaryLo: Color(0xFFBF360C), accent: Color(0xFFFFC107),
    accentHi: Color(0xFFFFE082), accentShine: Color(0xFFFFF8E1),
    bg: Color(0xFF140A00), bgDark: Color(0xFF201000),
    bgDeep: Color(0xFF000000), text: Color(0xFFFFF3E0),
    textSub: Color(0xFFFFB74D),
  );

  // ══════════════════════════════════════════════════════════
  // ═══ KATEGORI 2: COOL & FRESH (5) ═══
  // ══════════════════════════════════════════════════════════

  static const cyanIce = AppPalette(
    name: 'Cyan Ice', id: 'cyan_ice',
    primary: Color(0xFF00ACC1), primaryHi: Color(0xFF4DD0E1),
    primaryLo: Color(0xFF006064), accent: Color(0xFF80DEEA),
    accentHi: Color(0xFFB2EBF2), accentShine: Color(0xFFE0F7FA),
    bg: Color(0xFF08141A), bgDark: Color(0xFF0D2028),
    bgDeep: Color(0xFF000000), text: Color(0xFFE0F7FA),
    textSub: Color(0xFF4DD0E1),
  );

  static const matrixGreen = AppPalette(
    name: 'Matrix', id: 'matrix',
    primary: Color(0xFF00FF41), primaryHi: Color(0xFF69FF77),
    primaryLo: Color(0xFF003B00), accent: Color(0xFF39FF14),
    accentHi: Color(0xFF7FFF00), accentShine: Color(0xFFADFF2F),
    bg: Color(0xFF000000), bgDark: Color(0xFF001100),
    bgDeep: Color(0xFF000000), text: Color(0xFF00FF41),
    textSub: Color(0xFF00AA22),
  );

  static const oceanBlue = AppPalette(
    name: 'Ocean Blue', id: 'ocean_blue',
    primary: Color(0xFF0277BD), primaryHi: Color(0xFF039BE5),
    primaryLo: Color(0xFF01579B), accent: Color(0xFF4FC3F7),
    accentHi: Color(0xFF81D4FA), accentShine: Color(0xFFB3E5FC),
    bg: Color(0xFF0A1419), bgDark: Color(0xFF0F1F2A),
    bgDeep: Color(0xFF000000), text: Color(0xFFE1F5FE),
    textSub: Color(0xFF64B5F6),
  );

  static const mintFresh = AppPalette(
    name: 'Mint Fresh', id: 'mint_fresh',
    primary: Color(0xFF00897B), primaryHi: Color(0xFF26A69A),
    primaryLo: Color(0xFF004D40), accent: Color(0xFF4DB6AC),
    accentHi: Color(0xFF80CBC4), accentShine: Color(0xFFB2DFDB),
    bg: Color(0xFF0A1410), bgDark: Color(0xFF0F1F1A),
    bgDeep: Color(0xFF000000), text: Color(0xFFE0F2F1),
    textSub: Color(0xFF80CBC4),
  );

  static const auroraTeal = AppPalette(
    name: 'Aurora Teal', id: 'aurora_teal',
    primary: Color(0xFF14B8A6), primaryHi: Color(0xFF2DD4BF),
    primaryLo: Color(0xFF0F766E), accent: Color(0xFF67E8F9),
    accentHi: Color(0xFFA5F3FC), accentShine: Color(0xFFCFFAFE),
    bg: Color(0xFF051010), bgDark: Color(0xFF0A1A1A),
    bgDeep: Color(0xFF000000), text: Color(0xFFCCFBF1),
    textSub: Color(0xFF5EEAD4),
  );

  // ══════════════════════════════════════════════════════════
  // ═══ KATEGORI 3: SOFT & ELEGANT (5) ═══
  // ══════════════════════════════════════════════════════════

  static const blackGold = AppPalette(
    name: 'Black Gold', id: 'black_gold',
    primary: Color(0xFF1A1A1A), primaryHi: Color(0xFF2C2C2C),
    primaryLo: Color(0xFF0A0A0A), accent: Color(0xFFFFD700),
    accentHi: Color(0xFFFFF176), accentShine: Color(0xFFFFFDE7),
    bg: Color(0xFF0A0A0A), bgDark: Color(0xFF141414),
    bgDeep: Color(0xFF000000), text: Color(0xFFFFF8E1),
    textSub: Color(0xFFB0A070),
  );

  static const lavenderDream = AppPalette(
    name: 'Lavender Dream', id: 'lavender_dream',
    primary: Color(0xFF7E57C2), primaryHi: Color(0xFF9575CD),
    primaryLo: Color(0xFF4527A0), accent: Color(0xFFB39DDB),
    accentHi: Color(0xFFD1C4E9), accentShine: Color(0xFFEDE7F6),
    bg: Color(0xFF0F0A1A), bgDark: Color(0xFF1A0F2A),
    bgDeep: Color(0xFF000000), text: Color(0xFFEDE7F6),
    textSub: Color(0xFFB39DDB),
  );

  static const roseGold = AppPalette(
    name: 'Rose Gold', id: 'rose_gold',
    primary: Color(0xFFB76E79), primaryHi: Color(0xFFD48A96),
    primaryLo: Color(0xFF7A4449), accent: Color(0xFFE8B4B8),
    accentHi: Color(0xFFF5D5D8), accentShine: Color(0xFFFFF0F1),
    bg: Color(0xFF140A0C), bgDark: Color(0xFF1F0F13),
    bgDeep: Color(0xFF000000), text: Color(0xFFFFF5F5),
    textSub: Color(0xFFBCAAA4),
  );

  static const whiteSilver = AppPalette(
    name: 'White Silver', id: 'white_silver',
    primary: Color(0xFFB0BEC5), primaryHi: Color(0xFFECEFF1),
    primaryLo: Color(0xFF546E7A), accent: Color(0xFFCFD8DC),
    accentHi: Color(0xFFECEFF1), accentShine: Color(0xFFFFFFFF),
    bg: Color(0xFF0F1214), bgDark: Color(0xFF1A1F22),
    bgDeep: Color(0xFF000000), text: Color(0xFFECEFF1),
    textSub: Color(0xFF90A4AE),
  );

  static const pearlWhite = AppPalette(
    name: 'Pearl White', id: 'pearl_white',
    primary: Color(0xFF9E9E9E), primaryHi: Color(0xFFE0E0E0),
    primaryLo: Color(0xFF424242), accent: Color(0xFFF5F5F5),
    accentHi: Color(0xFFFFFFFF), accentShine: Color(0xFFFFFFFF),
    bg: Color(0xFFF5F5F5), bgDark: Color(0xFFE8E8E8),
    bgDeep: Color(0xFFD5D5D5), text: Color(0xFF1A1A1A),
    textSub: Color(0xFF616161),
  );

  // ══════════════════════════════════════════════════════════
  // ═══ KATEGORI 4: VIBRANT (5) ═══
  // ══════════════════════════════════════════════════════════

  static const cherryRed = AppPalette(
    name: 'Cherry Red', id: 'cherry_red',
    primary: Color(0xFFC62828), primaryHi: Color(0xFFE53935),
    primaryLo: Color(0xFF7F0000), accent: Color(0xFFFF8A80),
    accentHi: Color(0xFFFFAB91), accentShine: Color(0xFFFFCCBC),
    bg: Color(0xFF140A0A), bgDark: Color(0xFF200F0F),
    bgDeep: Color(0xFF000000), text: Color(0xFFFFEBEE),
    textSub: Color(0xFFEF9A9A),
  );

  static const midnightPurple = AppPalette(
    name: 'Midnight Purple', id: 'midnight_purple',
    primary: Color(0xFF4A148C), primaryHi: Color(0xFF6A1B9A),
    primaryLo: Color(0xFF1A0033), accent: Color(0xFFE040FB),
    accentHi: Color(0xFFEA80FC), accentShine: Color(0xFFF3E5F5),
    bg: Color(0xFF0A0510), bgDark: Color(0xFF14081F),
    bgDeep: Color(0xFF000000), text: Color(0xFFF3E5F5),
    textSub: Color(0xFF9575CD),
  );

  static const sunsetOrange = AppPalette(
    name: 'Sunset Orange', id: 'sunset_orange',
    primary: Color(0xFFD84315), primaryHi: Color(0xFFFF5722),
    primaryLo: Color(0xFF7A1E00), accent: Color(0xFFFFB74D),
    accentHi: Color(0xFFFFCC80), accentShine: Color(0xFFFFE0B2),
    bg: Color(0xFF1A0F0A), bgDark: Color(0xFF2A1810),
    bgDeep: Color(0xFF000000), text: Color(0xFFFFF3E0),
    textSub: Color(0xFFBCAAA4),
  );

  static const hotMagenta = AppPalette(
    name: 'Hot Magenta', id: 'hot_magenta',
    primary: Color(0xFFD500F9), primaryHi: Color(0xFFE040FB),
    primaryLo: Color(0xFF6A0080), accent: Color(0xFFFF80AB),
    accentHi: Color(0xFFFFB1C1), accentShine: Color(0xFFFFE4EC),
    bg: Color(0xFF14051A), bgDark: Color(0xFF20082A),
    bgDeep: Color(0xFF000000), text: Color(0xFFFCE4EC),
    textSub: Color(0xFFF48FB1),
  );

  static const royalBlue = AppPalette(
    name: 'Royal Blue', id: 'royal_blue',
    primary: Color(0xFF283593), primaryHi: Color(0xFF3949AB),
    primaryLo: Color(0xFF0D1240), accent: Color(0xFF64B5F6),
    accentHi: Color(0xFF90CAF9), accentShine: Color(0xFFBBDEFB),
    bg: Color(0xFF0A0A1A), bgDark: Color(0xFF101228),
    bgDeep: Color(0xFF000000), text: Color(0xFFE3F2FD),
    textSub: Color(0xFF7986CB),
  );

  // ══════════════════════════════════════════════════════════
  // ═══ KATEGORI 5: THEME POPULAR (POPULER DI CODE EDITOR) (6) ═══
  // ══════════════════════════════════════════════════════════

  // Dracula theme — khas VS Code
  static const dracula = AppPalette(
    name: 'Dracula', id: 'dracula',
    primary: Color(0xFFBD93F9), primaryHi: Color(0xFFD6ACFF),
    primaryLo: Color(0xFF6272A4), accent: Color(0xFFFF79C6),
    accentHi: Color(0xFFFFB8D9), accentShine: Color(0xFFFFD6F0),
    bg: Color(0xFF282A36), bgDark: Color(0xFF21222C),
    bgDeep: Color(0xFF191A21), text: Color(0xFFF8F8F2),
    textSub: Color(0xFF8BE9FD),
  );

  // Nord theme — cool nordic
  static const nord = AppPalette(
    name: 'Nord', id: 'nord',
    primary: Color(0xFF5E81AC), primaryHi: Color(0xFF81A1C1),
    primaryLo: Color(0xFF3B4252), accent: Color(0xFF88C0D0),
    accentHi: Color(0xFFA3D4E0), accentShine: Color(0xFFBFE3EA),
    bg: Color(0xFF2E3440), bgDark: Color(0xFF3B4252),
    bgDeep: Color(0xFF242933), text: Color(0xFFECEFF4),
    textSub: Color(0xFF81A1C1),
  );

  // Tokyo Night — khas vscode theme
  static const tokyoNight = AppPalette(
    name: 'Tokyo Night', id: 'tokyo_night',
    primary: Color(0xFF7AA2F7), primaryHi: Color(0xFF9EB8FF),
    primaryLo: Color(0xFF3D59A1), accent: Color(0xFFBB9AF7),
    accentHi: Color(0xFFD4BFFF), accentShine: Color(0xFFE8DBFF),
    bg: Color(0xFF1A1B26), bgDark: Color(0xFF16161E),
    bgDeep: Color(0xFF0F0F14), text: Color(0xFFC0CAF5),
    textSub: Color(0xFF565F89),
  );

  // Synthwave — retro 80s
  static const synthwave = AppPalette(
    name: 'Synthwave', id: 'synthwave',
    primary: Color(0xFFFF2E97), primaryHi: Color(0xFFFF6FB5),
    primaryLo: Color(0xFF8B0045), accent: Color(0xFF00E5FF),
    accentHi: Color(0xFF80DEEA), accentShine: Color(0xFFE0F7FA),
    bg: Color(0xFF1A0033), bgDark: Color(0xFF260048),
    bgDeep: Color(0xFF000000), text: Color(0xFFFFE0F0),
    textSub: Color(0xFFFF80AB),
  );

  // Gruvbox — warm retro
  static const gruvbox = AppPalette(
    name: 'Gruvbox', id: 'gruvbox',
    primary: Color(0xFFD79921), primaryHi: Color(0xFFFABD2F),
    primaryLo: Color(0xFF8B6914), accent: Color(0xFFB8BB26),
    accentHi: Color(0xFFD5D86A), accentShine: Color(0xFFE8EAA0),
    bg: Color(0xFF282828), bgDark: Color(0xFF1D2021),
    bgDeep: Color(0xFF141414), text: Color(0xFFEBDBB2),
    textSub: Color(0xFFA89984),
  );

  // Catppuccin Mocha — pastel warm
  static const catppuccin = AppPalette(
    name: 'Catppuccin', id: 'catppuccin',
    primary: Color(0xFFCBA6F7), primaryHi: Color(0xFFDDB8FF),
    primaryLo: Color(0xFF8839EF), accent: Color(0xFFF5C2E7),
    accentHi: Color(0xFFFFD4EE), accentShine: Color(0xFFFFE5F5),
    bg: Color(0xFF1E1E2E), bgDark: Color(0xFF181825),
    bgDeep: Color(0xFF11111B), text: Color(0xFFCDD6F4),
    textSub: Color(0xFFA6ADC8),
  );

  // ══════════════════════════════════════════════════════════
  // ═══ KATEGORI 6: LIGHT MODE (2) ═══
  // ══════════════════════════════════════════════════════════

  static const whiteLight = AppPalette(
    name: 'White Light', id: 'white_light',
    primary: Color(0xFF1976D2), primaryHi: Color(0xFF42A5F5),
    primaryLo: Color(0xFF0D47A1), accent: Color(0xFF7B1FA2),
    accentHi: Color(0xFF9C27B0), accentShine: Color(0xFFE1BEE7),
    bg: Color(0xFFFAFAFA), bgDark: Color(0xFFF0F0F0),
    bgDeep: Color(0xFFE0E0E0), text: Color(0xFF212121),
    textSub: Color(0xFF616161),
  );

  static const creamVanilla = AppPalette(
    name: 'Cream Vanilla', id: 'cream_vanilla',
    primary: Color(0xFFEF6C00), primaryHi: Color(0xFFFF9800),
    primaryLo: Color(0xFFB53D00), accent: Color(0xFF8D6E63),
    accentHi: Color(0xFFA1887F), accentShine: Color(0xFFD7CCC8),
    bg: Color(0xFFFFF8E1), bgDark: Color(0xFFFFECB3),
    bgDeep: Color(0xFFFFE082), text: Color(0xFF3E2723),
    textSub: Color(0xFF6D4C41),
  );

  // ══════════════════════════════════════════════════════════
  // ═══ MASTER LIST — SEMUA PALETTE ═══
  // ══════════════════════════════════════════════════════════

  static const List<AppPalette> all = [
    // Dark & Bold
    cyberBlue,
    bloodRed,
    neonGreen,
    purpleMystic,
    goldRoyal,
    pinkNeon,
    orangeFire,

    // Cool & Fresh
    cyanIce,
    matrixGreen,
    oceanBlue,
    mintFresh,
    auroraTeal,

    // Soft & Elegant
    blackGold,
    lavenderDream,
    roseGold,
    whiteSilver,
    pearlWhite,

    // Vibrant
    cherryRed,
    midnightPurple,
    sunsetOrange,
    hotMagenta,
    royalBlue,

    // Popular Themes
    dracula,
    nord,
    tokyoNight,
    synthwave,
    gruvbox,
    catppuccin,

    // Light Mode
    whiteLight,
    creamVanilla,
  ];

  static AppPalette getById(String id) =>
      all.firstWhere((p) => p.id == id, orElse: () => cyberBlue);
}

class AppTheme {
  static const String _paletteKey = 'app_theme_id';
  static const String _styleKey = 'app_style_id';

  static final ValueNotifier<AppPalette> current =
      ValueNotifier<AppPalette>(AppPalettes.cyberBlue);
  static final ValueNotifier<ThemeStyle> currentStyle =
      ValueNotifier<ThemeStyle>(ThemeStyle.original);

  static Future<void> load() async {
    final prefs = await SharedPreferences.getInstance();
    final paletteId = prefs.getString(_paletteKey) ?? 'cyber_blue';
    final styleId = prefs.getString(_styleKey) ?? 'original';
    current.value = AppPalettes.getById(paletteId);
    currentStyle.value = ThemeStyleInfo.getById(styleId).style;
  }

  static Future<void> setPalette(AppPalette palette) async {
    current.value = palette;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_paletteKey, palette.id);
  }

  static Future<void> setStyle(ThemeStyle style) async {
    currentStyle.value = style;
    final prefs = await SharedPreferences.getInstance();
    final info = ThemeStyleInfo.all.firstWhere((s) => s.style == style);
    await prefs.setString(_styleKey, info.id);
  }

  static bool get isComic => currentStyle.value == ThemeStyle.comic3d;
  static bool get isOriginal => currentStyle.value == ThemeStyle.original;
}

class StyleKit {
  final AppPalette C;
  final ThemeStyle style;
  const StyleKit({required this.C, required this.style});

  double get radiusSm => style == ThemeStyle.comic3d ? 10 : 6;
  double get radiusMd => style == ThemeStyle.comic3d ? 16 : 10;
  double get radiusLg => style == ThemeStyle.comic3d ? 22 : 14;
  double get borderThin => style == ThemeStyle.comic3d ? 2.0 : 1.0;
  double get borderMd => style == ThemeStyle.comic3d ? 3.0 : 1.5;
  double get borderThick => style == ThemeStyle.comic3d ? 4.0 : 2.0;

  Color get outline => style == ThemeStyle.comic3d
      ? const Color(0xFF000000)
      : C.primaryLo.withOpacity(0.6);

  Offset get shadowOffset =>
      style == ThemeStyle.comic3d ? const Offset(4, 4) : const Offset(0, 4);
  double get shadowBlur => style == ThemeStyle.comic3d ? 0 : 8;
  String get fontFamily => style == ThemeStyle.comic3d ? 'Bangers' : 'Orbitron';
  String get fontFamilySub =>
      style == ThemeStyle.comic3d ? 'ComicNeue' : 'ShareTechMono';

  BoxDecoration panelDecor({Color? color, double? radius, bool elevated = true}) {
    final r = radius ?? radiusMd;
    final baseColor = color ?? C.bgDark;
    if (style == ThemeStyle.comic3d) {
      return BoxDecoration(
        color: baseColor,
        borderRadius: BorderRadius.circular(r),
        border: Border.all(color: Colors.black, width: borderMd),
        boxShadow: elevated
            ? const [
                BoxShadow(color: Colors.black, offset: Offset(5, 5), blurRadius: 0),
              ]
            : null,
      );
    } else {
      return BoxDecoration(
        borderRadius: BorderRadius.circular(r),
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [C.bg, C.bgDark, C.bgDeep],
          stops: const [0.0, 0.5, 1.0],
        ),
        border: Border.all(color: outline, width: borderThin),
        boxShadow: elevated
            ? [
                BoxShadow(
                    color: Colors.black.withOpacity(0.75),
                    offset: const Offset(0, 6),
                    blurRadius: 12),
                BoxShadow(color: C.accent.withOpacity(0.15), blurRadius: 16),
              ]
            : null,
      );
    }
  }

  BoxDecoration buttonDecor({Color? color, bool pressed = false}) {
    final baseColor = color ?? C.primaryHi;
    if (style == ThemeStyle.comic3d) {
      return BoxDecoration(
        color: baseColor,
        borderRadius: BorderRadius.circular(radiusMd),
        border: Border.all(color: Colors.black, width: borderThick),
        boxShadow: pressed
            ? null
            : const [
                BoxShadow(color: Colors.black, offset: Offset(4, 4), blurRadius: 0),
              ],
      );
    } else {
      return BoxDecoration(
        borderRadius: BorderRadius.circular(radiusMd),
        gradient: LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [
            baseColor,
            baseColor.withOpacity(0.7),
            baseColor.withOpacity(0.4),
          ],
        ),
        border: Border.all(color: outline, width: borderMd),
        boxShadow: [
          BoxShadow(color: baseColor.withOpacity(0.4), blurRadius: 12),
          BoxShadow(
              color: Colors.black.withOpacity(0.6),
              offset: const Offset(0, 4),
              blurRadius: 6),
        ],
      );
    }
  }
}

class StyleBuilder extends StatelessWidget {
  final Widget Function(BuildContext, AppPalette, StyleKit) builder;
  const StyleBuilder({super.key, required this.builder});

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<AppPalette>(
      valueListenable: AppTheme.current,
      builder: (context, C, _) {
        return ValueListenableBuilder<ThemeStyle>(
          valueListenable: AppTheme.currentStyle,
          builder: (context, style, __) {
            return builder(context, C, StyleKit(C: C, style: style));
          },
        );
      },
    );
  }
}

class AppThemeScope extends InheritedWidget {
  final ThemeStyle style;
  final AppPalette palette;
  final StyleKit kit;
  const AppThemeScope({
    super.key,
    required this.style,
    required this.palette,
    required this.kit,
    required super.child,
  });

  static AppThemeScope? maybeOf(BuildContext context) =>
      context.dependOnInheritedWidgetOfExactType<AppThemeScope>();

  static ThemeStyle styleOf(BuildContext context) =>
      maybeOf(context)?.style ?? AppTheme.currentStyle.value;
  static AppPalette paletteOf(BuildContext context) =>
      maybeOf(context)?.palette ?? AppTheme.current.value;
  static StyleKit kitOf(BuildContext context) =>
      maybeOf(context)?.kit ??
      StyleKit(C: AppTheme.current.value, style: AppTheme.currentStyle.value);
  static bool isComic(BuildContext context) =>
      styleOf(context) == ThemeStyle.comic3d;

  @override
  bool updateShouldNotify(AppThemeScope old) =>
      old.style != style || old.palette.id != palette.id;
}

// ═══════════════════════════════════════════════════════════
// AUTO CONTRAST
// ═══════════════════════════════════════════════════════════
extension AppPaletteContrast on AppPalette {
  double _lum(Color c) {
    final r = c.red / 255;
    final g = c.green / 255;
    final b = c.blue / 255;
    double toLinear(double v) =>
        v <= 0.03928 ? v / 12.92 : math.pow((v + 0.055) / 1.055, 2.4).toDouble();
    return 0.2126 * toLinear(r) + 0.7152 * toLinear(g) + 0.0722 * toLinear(b);
  }

  double get _bgLuminance => (_lum(bg) + _lum(bgDark) + _lum(bgDeep)) / 3;
  bool get isDarkPalette => _bgLuminance < 0.5;
  bool get isLightPalette => !isDarkPalette;

  Color get comicText =>
      isDarkPalette ? const Color(0xFFF5F5F5) : const Color(0xFF0A0A0A);
  Color get comicTextSub =>
      isDarkPalette ? const Color(0xFFB0B0B0) : const Color(0xFF333333);
  Color get comicTextMuted =>
      isDarkPalette ? const Color(0xFF808080) : const Color(0xFF666666);
  Color get comicTextOutline => isDarkPalette ? Colors.black : Colors.white;

  Color contrastTextOn(Color background) =>
      _lum(background) > 0.5 ? Colors.black : Colors.white;
}

// ═══════════════════════════════════════════════════════════
// ADAPTIVE HELPER
// ═══════════════════════════════════════════════════════════
extension AdaptiveStyle on AppPalette {
  Color txtMain(bool isComic) => isComic ? comicText : text;
  Color txtSub2(bool isComic) => isComic ? comicTextSub : textSub;
  Color txtMuted(bool isComic) => isComic ? comicTextMuted : textSub;
  Color txtOutline2(bool isComic) => isComic ? comicTextOutline : Colors.black;
  String font(bool isComic) => isComic ? 'Bangers' : 'Orbitron';
  String fontSub(bool isComic) => isComic ? 'ComicNeue' : 'ShareTechMono';
  Color txtOnInput(bool isComic) => isComic ? Colors.black : text;
  Color txtOnButton(bool isComic, Color btnColor) =>
      isComic ? contrastTextOn(btnColor) : Colors.white;
}