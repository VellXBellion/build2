// quran_detail_page.dart — Halaman baca surah (Support Style Switcher)
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'app_theme.dart';
import 'quran_api.dart';

class QuranDetailPage extends StatefulWidget {
  final QuranSurah surah;
  const QuranDetailPage({super.key, required this.surah});

  @override
  State<QuranDetailPage> createState() => _QuranDetailPageState();
}

class _QuranDetailPageState extends State<QuranDetailPage> {
  QuranSurahDetail? _detail;
  bool _loading = true;
  String _error = '';

  @override
  void initState() {
    super.initState();
    _loadDetail();
  }

  Future<void> _loadDetail() async {
    setState(() {
      _loading = true;
      _error = '';
    });
    final result = await QuranApi.getSurahDetail(widget.surah.nomor);
    if (!mounted) return;
    setState(() {
      _detail = result;
      _loading = false;
      if (result == null) {
        _error = 'Gagal memuat surah. Cek koneksi internet.';
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<AppPalette>(
      valueListenable: AppTheme.current,
      builder: (context, C, _) {
        return ValueListenableBuilder<ThemeStyle>(
          valueListenable: AppTheme.currentStyle,
          builder: (context, style, __) {
            final isComic = style == ThemeStyle.comic3d;

            return Scaffold(
              backgroundColor: C.bgDeep,
              body: Container(
                decoration: isComic
                    ? BoxDecoration(color: C.bg)
                    : BoxDecoration(
                        gradient: RadialGradient(
                          center: const Alignment(-0.3, -0.3),
                          radius: 1.2,
                          colors: [C.bg, C.bgDark, C.bgDeep],
                          stops: const [0.0, 0.6, 1.0])),
                child: Stack(
                  children: [
                    if (isComic)
                      Positioned.fill(
                        child: IgnorePointer(
                          child: CustomPaint(
                            painter: _ComicHalftonePainter(
                                color: C.primaryLo.withValues(
                                    alpha: 0.12))))),
                    SafeArea(
                      child: Column(
                        children: [
                          const SizedBox(height: 8),
                          _buildTopBar(C, isComic),
                          const SizedBox(height: 10),
                          Expanded(
                            child: _loading
                                ? Center(
                                    child: CircularProgressIndicator(
                                        color: isComic
                                            ? Colors.black
                                            : C.accent,
                                        strokeWidth: 2))
                                : _error.isNotEmpty
                                    ? _buildError(C, isComic)
                                    : _buildContent(C, isComic),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            );
          },
        );
      },
    );
  }

  Widget _buildTopBar(AppPalette C, bool isComic) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 14),
      child: _MetalPlate(
        C: C,
        padding: const EdgeInsets.all(12),
        child: Row(
          children: [
            GestureDetector(
              onTap: () => Navigator.pop(context),
              child: Container(
                width: 36, height: 36,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(8),
                  gradient: isComic ? null
                      : LinearGradient(
                          colors: [C.text, C.bg, C.bgDark]),
                  color: isComic ? C.accent : null,
                  border: Border.all(
                      color: isComic ? Colors.black : C.primaryLo,
                      width: isComic ? 3 : 1.5)),
                child: Icon(Icons.arrow_back_ios_new_rounded,
                    color: isComic ? Colors.white : C.accent, size: 16),
              ),
            ),
            const SizedBox(width: 12),
            Container(
              width: 36, height: 36,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: isComic ? null
                    : RadialGradient(colors: [
                        C.accentHi, C.accent, C.primaryLo]),
                color: isComic ? C.primaryHi : null,
                border: Border.all(
                    color: isComic ? Colors.black : C.accentShine,
                    width: isComic ? 3 : 1.5)),
              child: Icon(Icons.book_rounded,
                  color: isComic ? Colors.white : C.bgDeep, size: 18),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(widget.surah.namaLatin.toUpperCase(),
                      style: TextStyle(
                        color: isComic ? Colors.black : C.accent,
                        fontFamily: isComic ? 'Bangers' : 'Orbitron',
                        fontWeight: FontWeight.w900,
                        fontSize: isComic ? 16 : 13,
                        letterSpacing: isComic ? 1 : 1.5),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis),
                  const SizedBox(height: 2),
                  Text('SURAH ${widget.surah.nomor} · ${widget.surah.jumlahAyat} AYAT',
                      style: TextStyle(
                        color: isComic
                            ? Colors.black.withValues(alpha: 0.5)
                            : C.text.withValues(alpha: 0.55),
                        fontFamily:
                            isComic ? 'ComicNeue' : 'ShareTechMono',
                        fontWeight: FontWeight.w700,
                        fontSize: 8,
                        letterSpacing: 1.2)),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildContent(AppPalette C, bool isComic) {
    final detail = _detail!;
    return ListView.builder(
      padding: const EdgeInsets.fromLTRB(14, 4, 14, 24),
      physics: const BouncingScrollPhysics(),
      itemCount: detail.ayat.length + 1,
      itemBuilder: (_, i) {
        if (i == 0) return _buildHeader(C, isComic, detail);
        return _buildAyatTile(C, isComic, detail.ayat[i - 1]);
      },
    );
  }

  Widget _buildHeader(
      AppPalette C, bool isComic, QuranSurahDetail detail) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 14),
      child: _MetalPlate(
        C: C,
        brass: !isComic,
        padding: const EdgeInsets.all(20),
        child: Column(
          children: [
            Text(detail.nama,
                style: TextStyle(
                  color: isComic ? Colors.black : C.bgDeep,
                  fontSize: 36,
                  fontWeight: FontWeight.w900,
                  height: 1.2),
                textDirection: TextDirection.rtl),
            const SizedBox(height: 8),
            Text(detail.namaLatin,
                style: TextStyle(
                  color: isComic ? Colors.black : C.bgDeep,
                  fontSize: isComic ? 20 : 18,
                  fontWeight: FontWeight.w900,
                  fontFamily: isComic ? 'Bangers' : 'Orbitron',
                  letterSpacing: 1)),
            const SizedBox(height: 6),
            Container(
              padding: const EdgeInsets.symmetric(
                  horizontal: 12, vertical: 4),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(isComic ? 10 : 20),
                color: isComic ? Colors.white : C.bgDeep.withValues(alpha: 0.15),
                border: Border.all(
                    color: isComic ? Colors.black : C.bgDeep.withValues(alpha: 0.4),
                    width: isComic ? 2.5 : 1)),
              child: Text(
                  '${detail.arti} · ${detail.jumlahAyat} AYAT · ${detail.tempatTurun.toUpperCase()}',
                  style: TextStyle(
                    color: isComic ? Colors.black : C.bgDeep.withValues(alpha: 0.9),
                    fontSize: isComic ? 10 : 9,
                    fontFamily:
                        isComic ? 'Bangers' : 'ShareTechMono',
                    fontWeight: FontWeight.w900,
                    letterSpacing: 1)),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildAyatTile(
      AppPalette C, bool isComic, QuranAyat ayat) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: _MetalPlate(
        C: C,
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Row(
              children: [
                Container(
                  padding: const EdgeInsets.symmetric(
                      horizontal: 10, vertical: 4),
                  decoration: BoxDecoration(
                    borderRadius:
                        BorderRadius.circular(isComic ? 10 : 6),
                    gradient: isComic ? null
                        : LinearGradient(colors: [
                            C.accentHi, C.accent, C.primaryLo]),
                    color: isComic ? C.primaryHi : null,
                    border: Border.all(
                        color: isComic ? Colors.black : C.accentShine,
                        width: isComic ? 2.5 : 1)),
                  child: Text('AYAT ${ayat.nomorAyat}',
                      style: TextStyle(
                        color: isComic ? Colors.white : C.bgDeep,
                        fontSize: isComic ? 12 : 9,
                        fontWeight: FontWeight.w900,
                        fontFamily:
                            isComic ? 'Bangers' : 'Orbitron',
                        letterSpacing: 1.5)),
                ),
              ],
            ),
            const SizedBox(height: 16),
            Container(
              padding: const EdgeInsets.symmetric(
                  horizontal: 12, vertical: 14),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(isComic ? 10 : 10),
                color: isComic
                    ? Colors.white
                    : Colors.black.withValues(alpha: 0.4),
                border: Border.all(
                    color: isComic
                        ? Colors.black
                        : C.accent.withValues(alpha: 0.25),
                    width: isComic ? 3 : 1)),
              child: Text(ayat.teksArab,
                  textAlign: TextAlign.right,
                  textDirection: TextDirection.rtl,
                  style: TextStyle(
                    color: isComic ? Colors.black : C.accentShine,
                    fontSize: isComic ? 26 : 24,
                    height: 1.9,
                    fontWeight: FontWeight.w500)),
            ),
            const SizedBox(height: 12),
            Text(ayat.teksLatin,
                style: TextStyle(
                  color: isComic
                      ? Colors.black.withValues(alpha: 0.7)
                      : C.text.withValues(alpha: 0.7),
                  fontSize: isComic ? 13 : 11.5,
                  fontStyle: FontStyle.italic,
                  height: 1.6,
                  fontFamily:
                      isComic ? 'ComicNeue' : 'ShareTechMono',
                  fontWeight: FontWeight.w600)),
            const SizedBox(height: 10),
            Text(ayat.teksIndonesia,
                style: TextStyle(
                  color: isComic ? Colors.black : C.text,
                  fontSize: isComic ? 14 : 12.5,
                  height: 1.65,
                  fontWeight: FontWeight.w600)),
          ],
        ),
      ),
    );
  }

  Widget _buildError(AppPalette C, bool isComic) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: _MetalPlate(
          C: C,
          padding: const EdgeInsets.all(20),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(Icons.error_outline_rounded,
                  color: isComic ? Colors.black : C.primaryHi, size: 42),
              const SizedBox(height: 12),
              Text(_error,
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    color: isComic ? Colors.black : C.text,
                    fontSize: isComic ? 13 : 12,
                    fontFamily:
                        isComic ? 'ComicNeue' : 'ShareTechMono',
                    fontWeight: FontWeight.w700)),
              const SizedBox(height: 18),
              GestureDetector(
                onTap: _loadDetail,
                child: Container(
                  padding: const EdgeInsets.symmetric(
                      horizontal: 24, vertical: 10),
                  decoration: BoxDecoration(
                    borderRadius:
                        BorderRadius.circular(isComic ? 12 : 8),
                    gradient: isComic ? null
                        : LinearGradient(colors: [
                            C.primaryHi, C.primary, C.primaryLo]),
                    color: isComic ? C.primaryHi : null,
                    border: Border.all(
                        color: isComic ? Colors.black : C.primaryLo,
                        width: isComic ? 3 : 1.5)),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(Icons.refresh_rounded,
                          color: isComic ? Colors.white : C.text,
                          size: 16),
                      const SizedBox(width: 8),
                      Text('COBA LAGI',
                          style: TextStyle(
                            color: isComic ? Colors.white : C.text,
                            fontSize: isComic ? 15 : 11,
                            fontWeight: FontWeight.w900,
                            fontFamily:
                                isComic ? 'Bangers' : 'Orbitron',
                            letterSpacing: 2)),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _MetalPlate extends StatelessWidget {
  final AppPalette C;
  final Widget child;
  final EdgeInsets padding;
  final bool brass;
  final double radius;
  const _MetalPlate({
    required this.C,
    required this.child,
    this.padding = const EdgeInsets.all(16),
    this.brass = false,
    this.radius = 16,
  });

  @override
  Widget build(BuildContext context) {
    final isComic = AppTheme.currentStyle.value == ThemeStyle.comic3d;
    if (isComic) {
      return Container(
        padding: padding,
        decoration: BoxDecoration(
          color: brass ? C.primaryHi : C.bgDark,
          borderRadius: BorderRadius.circular(radius + 4),
          border: Border.all(color: Colors.black, width: 4),
          boxShadow: const [
            BoxShadow(color: Colors.black, offset: Offset(5, 5),
                blurRadius: 0),
          ]),
        child: child,
      );
    }
    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(radius),
        gradient: LinearGradient(
          begin: Alignment.topLeft, end: Alignment.bottomRight,
          colors: brass
              ? [C.accentHi, C.accent, C.primary, C.primaryLo]
              : [C.text, C.bg, C.bgDark, C.bgDeep],
          stops: const [0.0, 0.4, 0.7, 1.0]),
        boxShadow: [
          BoxShadow(color: Colors.black.withValues(alpha: 0.75),
              offset: const Offset(0, 6), blurRadius: 12),
        ],
      ),
      padding: const EdgeInsets.all(3),
      child: Container(
        padding: padding,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(radius - 3),
          gradient: LinearGradient(
            begin: Alignment.topCenter, end: Alignment.bottomCenter,
            colors: [C.bg, C.bgDark, C.bgDeep]),
          border: Border.all(color: Colors.black.withValues(alpha: 0.5)),
        ),
        child: child,
      ),
    );
  }
}

class _ComicHalftonePainter extends CustomPainter {
  final Color color;
  const _ComicHalftonePainter({required this.color});

  @override
  void paint(Canvas canvas, Size size) {
    const spacing = 22.0;
    final paint = Paint()..color = color;
    for (double x = 0; x < size.width + spacing; x += spacing) {
      for (double y = 0; y < size.height + spacing; y += spacing) {
        canvas.drawCircle(Offset(x, y), 2.5, paint);
      }
    }
  }

  @override
  bool shouldRepaint(_ComicHalftonePainter old) => old.color != color;
}