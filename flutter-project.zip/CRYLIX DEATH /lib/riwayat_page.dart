// lib/riwayat_page.dart
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'app_theme.dart';
import 'api_config.dart';

class RiwayatPage extends StatefulWidget {
  final String sessionKey;
  final String role;

  const RiwayatPage({
    super.key,
    required this.sessionKey,
    required this.role,
  });

  @override
  State<RiwayatPage> createState() => _RiwayatPageState();
}

class _RiwayatPageState extends State<RiwayatPage> {
  List<ActivityModel> activities = [];
  bool isLoading = true;

  @override
  void initState() {
    super.initState();
    _loadActivities();
  }

  Future<void> _loadActivities() async {

    try {
      final response = await http.get(
        Uri.parse('$baseUrl/getMyActivity?key=${widget.sessionKey}'),
      ).timeout(const Duration(seconds: 10));

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['valid']) {
          List<dynamic> rawList = data['activities'];
          setState(() {
            activities = rawList.map((item) {
              return ActivityModel(
                type: item['type'] ?? 'system',
                title: item['title'] ?? 'Aktivitas',
                description: item['description'] ?? '-',
                timestamp: DateTime.fromMillisecondsSinceEpoch(
                    item['timestamp'] ??
                        DateTime.now().millisecondsSinceEpoch),
              );
            }).toList();
            isLoading = false;
          });
        } else {
          setState(() => isLoading = false);
        }
      } else {
        setState(() => isLoading = false);
      }
    } catch (e) {
      debugPrint("Error fetching history: $e");
      setState(() => isLoading = false);
    }
  }

  String _formatDate(DateTime date) {
    return DateFormat('dd MMM yyyy, HH:mm').format(date);
  }

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<AppPalette>(
      valueListenable: AppTheme.current,
      builder: (context, C, _) {
        return ValueListenableBuilder<ThemeStyle>(
          valueListenable: AppTheme.currentStyle,
          builder: (context, style, __) {
            final isComic = style == ThemeStyle.comic3d;

            return Scaffold(
              backgroundColor: C.bgDeep,
              appBar: isComic
                  ? AppBar(
                      backgroundColor: C.bgDark,
                      elevation: 0,
                      leading: IconButton(
                        icon: const Icon(Icons.arrow_back_ios_new,
                            size: 16, color: Colors.black),
                        onPressed: () => Navigator.pop(context),
                      ),
                      title: const Text(
                        "ACTIVITY HISTORY",
                        style: TextStyle(
                          color: Colors.black,
                          fontFamily: 'Bangers',
                          fontWeight: FontWeight.w900,
                          fontSize: 20,
                          letterSpacing: 2,
                        ),
                      ),
                      centerTitle: true,
                      bottom: PreferredSize(
                        preferredSize: const Size.fromHeight(4),
                        child: Container(height: 4, color: Colors.black),
                      ),
                    )
                  : AppBar(
                      backgroundColor: C.bgDark,
                      elevation: 0,
                      leading: IconButton(
                        icon: Icon(Icons.arrow_back_ios_new,
                            size: 16, color: C.text),
                        onPressed: () => Navigator.pop(context),
                      ),
                      title: Text(
                        "Activity History",
                        style: TextStyle(
                          color: C.primaryHi,
                          fontFamily: 'Orbitron',
                          fontWeight: FontWeight.w900,
                          fontSize: 16,
                          letterSpacing: 1,
                        ),
                      ),
                      centerTitle: true,
                      bottom: PreferredSize(
                        preferredSize: const Size.fromHeight(1),
                        child: Divider(color: C.bg, height: 1),
                      ),
                    ),
              body: Container(
                decoration: isComic
                    ? BoxDecoration(color: C.bg)
                    : BoxDecoration(
                        gradient: LinearGradient(
                          begin: Alignment.topCenter,
                          end: Alignment.bottomCenter,
                          colors: [C.bgDeep, C.bgDark, C.bgDeep],
                        ),
                      ),
                child: Stack(
                  children: [
                    if (isComic)
                      Positioned.fill(
                        child: IgnorePointer(
                          child: CustomPaint(
                            painter: _ComicHalftonePainter(
                                color: C.primaryLo.withOpacity(0.12)),
                          ),
                        ),
                      ),
                    isLoading
                        ? Center(
                            child: CircularProgressIndicator(
                                color: isComic ? Colors.black : C.primaryHi,
                                strokeWidth: 2.5),
                          )
                        : activities.isEmpty
                            ? _buildEmptyState(C, isComic)
                            : RefreshIndicator(
                                onRefresh: _loadActivities,
                                color: isComic ? Colors.black : C.primaryHi,
                                backgroundColor: C.bgDark,
                                child: ListView.builder(
                                  padding: const EdgeInsets.symmetric(
                                      horizontal: 16, vertical: 20),
                                  itemCount: activities.length,
                                  itemBuilder: (context, index) {
                                    return _buildActivityCard(
                                        C, isComic, activities[index]);
                                  },
                                ),
                              ),
                  ],
                ),
              ),
            );
          },
        );
      },
    );
  }

  Widget _buildEmptyState(AppPalette C, bool isComic) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32),
        child: Container(
          padding: const EdgeInsets.all(28),
          decoration: isComic
              ? BoxDecoration(
                  color: C.bgDark,
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(color: Colors.black, width: 4),
                  boxShadow: const [
                    BoxShadow(
                      color: Colors.black,
                      offset: Offset(6, 6),
                      blurRadius: 0,
                    ),
                  ],
                )
              : null,
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Container(
                padding: const EdgeInsets.all(28),
                decoration: BoxDecoration(
                  color: isComic
                      ? C.primaryHi
                      : C.primaryHi.withValues(alpha: 0.04),
                  shape: BoxShape.circle,
                  border: isComic
                      ? Border.all(color: Colors.black, width: 4)
                      : Border.all(
                          color: C.primaryHi.withValues(alpha: 0.10),
                          width: 2),
                  boxShadow: isComic
                      ? null
                      : [
                          BoxShadow(
                            color: C.primaryHi.withValues(alpha: 0.06),
                            blurRadius: 30,
                          ),
                        ],
                ),
                child: Icon(
                  Icons.history_toggle_off,
                  size: 50,
                  color: isComic
                      ? Colors.white
                      : C.primaryHi.withValues(alpha: 0.25),
                ),
              ),
              const SizedBox(height: 28),
              Text(
                "NO ACTIVITY YET",
                style: TextStyle(
                  color: isComic ? Colors.black : C.primaryHi,
                  fontSize: isComic ? 20 : 16,
                  fontFamily: isComic ? 'Bangers' : 'Orbitron',
                  fontWeight: FontWeight.w900,
                  letterSpacing: 2,
                ),
              ),
              const SizedBox(height: 12),
              Text(
                "Belum ada catatan aktivitas.\nPastikan server aktif.",
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: isComic
                      ? Colors.black.withOpacity(0.6)
                      : C.textSub,
                  fontSize: 12,
                  fontFamily: isComic ? 'ComicNeue' : 'ShareTechMono',
                  height: 1.6,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildActivityCard(
      AppPalette C, bool isComic, ActivityModel activity) {
    Color iconColor;
    IconData iconData;
    String typeLabel;
    Color badgeBg;
    Color badgeText;

    switch (activity.type) {
      case 'login':
        iconColor = C.primaryHi;
        iconData = Icons.login_rounded;
        typeLabel = "LOGIN";
        badgeBg = C.primaryHi.withValues(alpha: 0.10);
        badgeText = C.primaryHi;
        break;
      case 'bug':
        iconColor = C.primaryHi;
        iconData = Icons.bug_report_outlined;
        typeLabel = "ATTACK";
        badgeBg = C.primaryHi.withValues(alpha: 0.10);
        badgeText = C.primaryHi;
        break;
      case 'create':
        iconColor = C.accent;
        iconData = Icons.person_add_alt_1_rounded;
        typeLabel = "ACCOUNT";
        badgeBg = C.accent.withValues(alpha: 0.10);
        badgeText = C.accent;
        break;
      default:
        iconColor = C.textSub;
        iconData = Icons.info_outline;
        typeLabel = "SYSTEM";
        badgeBg = C.textSub.withValues(alpha: 0.08);
        badgeText = C.textSub;
    }

    if (isComic) {
      return Container(
        margin: const EdgeInsets.only(bottom: 10),
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: C.bgDark,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: Colors.black, width: 4),
          boxShadow: const [
            BoxShadow(
              color: Colors.black,
              offset: Offset(5, 5),
              blurRadius: 0,
            ),
          ],
        ),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: iconColor,
                borderRadius: BorderRadius.circular(10),
                border: Border.all(color: Colors.black, width: 3),
              ),
              child: Icon(iconData, color: Colors.white, size: 22),
            ),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Expanded(
                        child: Text(
                          activity.title,
                          style: TextStyle(
                            color: Colors.black,
                            fontSize: 15,
                            fontFamily: 'Bangers',
                            fontWeight: FontWeight.bold,
                            letterSpacing: 1,
                          ),
                          overflow: TextOverflow.ellipsis,
                        ),
                      ),
                      const SizedBox(width: 8),
                      Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 8, vertical: 3),
                        decoration: BoxDecoration(
                          color: badgeText,
                          borderRadius: BorderRadius.circular(6),
                          border: Border.all(color: Colors.black, width: 2),
                        ),
                        child: Text(
                          typeLabel,
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 10,
                            fontWeight: FontWeight.bold,
                            fontFamily: 'Bangers',
                            letterSpacing: 1,
                          ),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 6),
                  Text(
                    activity.description,
                    style: TextStyle(
                      color: Colors.black.withOpacity(0.7),
                      fontSize: 12,
                      fontFamily: 'ComicNeue',
                      height: 1.4,
                    ),
                  ),
                  const SizedBox(height: 10),
                  Row(
                    children: [
                      Icon(Icons.schedule_rounded,
                          size: 13, color: Colors.black.withOpacity(0.5)),
                      const SizedBox(width: 5),
                      Text(
                        _formatDate(activity.timestamp),
                        style: TextStyle(
                          color: Colors.black.withOpacity(0.5),
                          fontSize: 11,
                          fontFamily: 'ComicNeue',
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      );
    }

    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: C.bgDark,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: C.bg),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.4),
            blurRadius: 10,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            padding: const EdgeInsets.all(11),
            decoration: BoxDecoration(
              color: iconColor.withValues(alpha: 0.08),
              borderRadius: BorderRadius.circular(14),
              border:
                  Border.all(color: iconColor.withValues(alpha: 0.15)),
            ),
            child: Icon(iconData, color: iconColor, size: 22),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Expanded(
                      child: Text(
                        activity.title,
                        style: TextStyle(
                          color: C.text,
                          fontSize: 14,
                          fontWeight: FontWeight.bold,
                        ),
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                    const SizedBox(width: 10),
                    Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 8, vertical: 3),
                      decoration: BoxDecoration(
                        color: badgeBg,
                        borderRadius: BorderRadius.circular(6),
                        border: Border.all(
                            color: badgeText.withValues(alpha: 0.2)),
                      ),
                      child: Text(
                        typeLabel,
                        style: TextStyle(
                          color: badgeText,
                          fontSize: 9,
                          fontWeight: FontWeight.bold,
                          fontFamily: 'Orbitron',
                          letterSpacing: 0.8,
                        ),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 6),
                Text(
                  activity.description,
                  style: TextStyle(
                    color: C.textSub,
                    fontSize: 12,
                    height: 1.4,
                  ),
                ),
                const SizedBox(height: 10),
                Row(
                  children: [
                    Icon(Icons.schedule_rounded,
                        size: 13, color: C.text.withValues(alpha: 0.3)),
                    const SizedBox(width: 5),
                    Text(
                      _formatDate(activity.timestamp),
                      style: TextStyle(
                        color: C.text.withValues(alpha: 0.3),
                        fontSize: 11,
                        fontFamily: 'ShareTechMono',
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class ActivityModel {
  final String type;
  final String title;
  final String description;
  final DateTime timestamp;

  ActivityModel({
    required this.type,
    required this.title,
    required this.description,
    required this.timestamp,
  });
}

class _ComicHalftonePainter extends CustomPainter {
  final Color color;
  const _ComicHalftonePainter({required this.color});

  @override
  void paint(Canvas canvas, Size size) {
    const spacing = 22.0;
    final paint = Paint()..color = color;
    for (double x = 0; x < size.width + spacing; x += spacing) {
      for (double y = 0; y < size.height + spacing; y += spacing) {
        canvas.drawCircle(Offset(x, y), 2.5, paint);
      }
    }
  }

  @override
  bool shouldRepaint(_ComicHalftonePainter old) => old.color != color;
}