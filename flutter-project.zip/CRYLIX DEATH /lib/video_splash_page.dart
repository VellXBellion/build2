// lib/video_splash_page.dart
import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:video_player/video_player.dart';
import 'app_theme.dart';
import 'dashboard_page.dart';
import 'welcome_intro_page.dart';

// ═══════════════════════════════════════════════════════
// GLOBAL PULSE
// ═══════════════════════════════════════════════════════
class _Pulse {
  static final ValueNotifier<double> v = ValueNotifier<double>(0);
  static bool _started = false;
  static void ensureStarted() {
    if (_started) return;
    _started = true;
    _run();
  }
  static Future<void> _run() async {
    final sw = Stopwatch()..start();
    while (true) {
      await Future<void>.delayed(const Duration(milliseconds: 80));
      final t = (sw.elapsedMilliseconds % 1600) / 1600.0;
      v.value = t < 0.5 ? t * 2 : (1 - t) * 2;
    }
  }
}

// ═══════════════════════════════════════════════════════
// LED
// ═══════════════════════════════════════════════════════
class _Led extends StatelessWidget {
  final Color color;
  final double size;
  final bool blink;
  const _Led({required this.color, this.size = 8, this.blink = false});

  @override
  Widget build(BuildContext context) {
    final isComic = AppTheme.currentStyle.value == ThemeStyle.comic3d;
    if (isComic) {
      return Container(
        width: size,
        height: size,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          color: color,
          border: Border.all(color: Colors.black, width: size * 0.18),
        ),
      );
    }
    if (!blink) return _dot(1.0);
    return ValueListenableBuilder<double>(
      valueListenable: _Pulse.v,
      builder: (_, v, __) => _dot(0.45 + v * 0.55),
    );
  }

  Widget _dot(double opacity) => Container(
        width: size,
        height: size,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          gradient: RadialGradient(
            center: const Alignment(-0.35, -0.35),
            colors: [
              Colors.white.withOpacity(0.85 * opacity),
              color.withOpacity(opacity),
              color.withOpacity(0.55 * opacity),
            ],
            stops: const [0.0, 0.4, 1.0],
          ),
          border: Border.all(
            color: Colors.black.withOpacity(0.85),
            width: size * 0.1,
          ),
          boxShadow: [
            BoxShadow(
              color: color.withOpacity(0.75 * opacity),
              blurRadius: size * 1.4,
              spreadRadius: size * 0.2,
            ),
            BoxShadow(
              color: color.withOpacity(0.35 * opacity),
              blurRadius: size * 2.6,
              spreadRadius: size * 0.4,
            ),
          ],
        ),
      );
}

// ═══════════════════════════════════════════════════════
// SCREW
// ═══════════════════════════════════════════════════════
class _Screw extends StatelessWidget {
  final AppPalette C;
  final double size;
  final double rotation;
  const _Screw({required this.C, this.size = 14, this.rotation = 0.785});

  @override
  Widget build(BuildContext context) {
    if (AppTheme.currentStyle.value == ThemeStyle.comic3d) {
      return const SizedBox.shrink();
    }
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        gradient: RadialGradient(
          center: const Alignment(-0.35, -0.35),
          colors: [C.text, C.textSub, C.bg, C.bgDark],
          stops: const [0.0, 0.35, 0.7, 1.0],
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.9),
            offset: const Offset(0.8, 1.5),
            blurRadius: 2.5,
            spreadRadius: -0.5,
          ),
          const BoxShadow(
            color: Colors.white38,
            offset: Offset(-0.8, -0.8),
            blurRadius: 1.5,
          ),
        ],
      ),
      child: Center(
        child: Transform.rotate(
          angle: rotation,
          child: Container(
            width: size * 0.7,
            height: size * 0.11,
            decoration: BoxDecoration(
              color: Colors.black.withOpacity(0.9),
              borderRadius: BorderRadius.circular(size * 0.05),
            ),
          ),
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════
// RIVET
// ═══════════════════════════════════════════════════════
class _Rivet extends StatelessWidget {
  final AppPalette C;
  final double size;
  const _Rivet({required this.C, this.size = 10});

  @override
  Widget build(BuildContext context) {
    if (AppTheme.currentStyle.value == ThemeStyle.comic3d) {
      return const SizedBox.shrink();
    }
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        gradient: RadialGradient(
          center: const Alignment(-0.35, -0.35),
          colors: [C.accentShine, C.accentHi, C.accent, C.primaryLo],
          stops: const [0.0, 0.3, 0.65, 1.0],
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.9),
            offset: const Offset(0.5, 1),
            blurRadius: 1.5,
          ),
          const BoxShadow(
            color: Colors.white54,
            offset: Offset(-0.5, -0.5),
            blurRadius: 1,
          ),
        ],
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════
// METAL PLATE
// ═══════════════════════════════════════════════════════
class _MetalPlate extends StatelessWidget {
  final AppPalette C;
  final Widget child;
  final EdgeInsets padding;
  final bool brass;
  final double radius;
  const _MetalPlate({
    required this.C,
    required this.child,
    this.padding = const EdgeInsets.all(16),
    this.brass = false,
    this.radius = 16,
  });

  @override
  Widget build(BuildContext context) {
    final isComic = AppTheme.currentStyle.value == ThemeStyle.comic3d;
    if (isComic) {
      return Container(
        padding: padding,
        decoration: BoxDecoration(
          color: brass ? C.primaryHi : C.bgDark,
          borderRadius: BorderRadius.circular(radius + 4),
          border: Border.all(color: Colors.black, width: 4),
          boxShadow: const [
            BoxShadow(
              color: Colors.black,
              offset: Offset(6, 6),
              blurRadius: 0,
            ),
          ],
        ),
        child: child,
      );
    }
    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(radius),
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: brass
              ? [C.accentHi, C.accent, C.primary, C.primaryLo]
              : [C.text, C.bg, C.bgDark, C.bgDeep],
          stops: const [0.0, 0.4, 0.7, 1.0],
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.75),
            offset: const Offset(0, 6),
            blurRadius: 12,
          ),
          const BoxShadow(
            color: Colors.white12,
            offset: Offset(-1, -1),
            blurRadius: 3,
          ),
        ],
      ),
      padding: const EdgeInsets.all(3),
      child: Container(
        padding: padding,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(radius - 3),
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [C.bg, C.bgDark, C.bgDeep],
          ),
          border: Border.all(color: Colors.black.withOpacity(0.5)),
        ),
        child: child,
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════
// VIDEO SPLASH PAGE
// ═══════════════════════════════════════════════════════
class VideoSplashPage extends StatefulWidget {
  final Map<String, dynamic> dashboardArgs;

  const VideoSplashPage({super.key, required this.dashboardArgs});

  @override
  State<VideoSplashPage> createState() => _VideoSplashPageState();
}

class _VideoSplashPageState extends State<VideoSplashPage>
    with TickerProviderStateMixin {
  late VideoPlayerController _controller;
  bool _isInitialized = false;
  bool _navigated = false;

  late AnimationController _entryCtrl;
  late AnimationController _floatCtrl;
  late AnimationController _loadCtrl;
  late AnimationController _scanCtrl;

  late Animation<double> _logoFade;
  late Animation<double> _logoScale;
  late Animation<Offset> _subtitleSlide;
  late Animation<double> _loadProgress;
  late Animation<double> _ledPulse;

  @override
  void initState() {
    super.initState();
    _Pulse.ensureStarted();
    _setupAnimations();
    _initVideo();
  }

  void _setupAnimations() {
    _entryCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 2200),
    )..forward();

    _floatCtrl = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 3),
    )..repeat(reverse: true);

    _loadCtrl = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 8),
    )..forward();

    _scanCtrl = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 4),
    )..repeat();

    _logoFade = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(
        parent: _entryCtrl,
        curve: const Interval(0.0, 0.5, curve: Curves.easeOut),
      ),
    );

    _logoScale = Tween<double>(begin: 0.4, end: 1.0).animate(
      CurvedAnimation(
        parent: _entryCtrl,
        curve: const Interval(0.0, 0.7, curve: Curves.elasticOut),
      ),
    );

    _subtitleSlide = Tween<Offset>(
      begin: const Offset(0, 0.8),
      end: Offset.zero,
    ).animate(CurvedAnimation(
      parent: _entryCtrl,
      curve: const Interval(0.4, 1.0, curve: Curves.easeOutBack),
    ));

    _loadProgress = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _loadCtrl, curve: Curves.linear),
    );

    _ledPulse = Tween<double>(begin: 0.3, end: 1.0).animate(
      CurvedAnimation(parent: _floatCtrl, curve: Curves.easeInOut),
    );
  }

  Future<void> _initVideo() async {
    _controller = VideoPlayerController.asset('assets/videos/splash.mp4');

    try {
      await _controller.initialize();
      await _controller.setVolume(1.0);
      await _controller.setLooping(false);
      _controller.addListener(_onVideoEnd);
      await _controller.play();
      if (mounted) setState(() => _isInitialized = true);
    } catch (e) {
      _goToWelcome();
    }
  }

  void _onVideoEnd() {
    if (!_navigated &&
        _controller.value.position >= _controller.value.duration &&
        _controller.value.duration > Duration.zero) {
      _goToWelcome();
    }
  }

  void _goToWelcome() {
    if (_navigated) return;
    _navigated = true;
    HapticFeedback.mediumImpact();

    if (mounted) {
      Navigator.pushReplacement(
        context,
        PageRouteBuilder(
          pageBuilder: (_, __, ___) => WelcomeIntroPage(
            dashboardArgs: widget.dashboardArgs,
          ),
          transitionDuration: const Duration(milliseconds: 500),
          transitionsBuilder: (_, anim, __, child) =>
              FadeTransition(opacity: anim, child: child),
        ),
      );
    }
  }

  @override
  void dispose() {
    _controller.removeListener(_onVideoEnd);
    _controller.dispose();
    _entryCtrl.dispose();
    _floatCtrl.dispose();
    _loadCtrl.dispose();
    _scanCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<AppPalette>(
      valueListenable: AppTheme.current,
      builder: (context, C, _) {
        return ValueListenableBuilder<ThemeStyle>(
          valueListenable: AppTheme.currentStyle,
          builder: (context, style, __) {
            final isComic = style == ThemeStyle.comic3d;

            return Scaffold(
              backgroundColor: isComic ? C.bg : Colors.black,
              body: Stack(
                fit: StackFit.expand,
                children: [
                  if (_isInitialized)
                    FittedBox(
                      fit: BoxFit.cover,
                      child: SizedBox(
                        width: _controller.value.size.width,
                        height: _controller.value.size.height,
                        child: VideoPlayer(_controller),
                      ),
                    )
                  else
                    Container(
                      color: isComic ? C.bg : C.bgDeep,
                      child: Center(
                        child: CircularProgressIndicator(
                          strokeWidth: 2,
                          valueColor: AlwaysStoppedAnimation<Color>(C.accent),
                        ),
                      ),
                    ),

                  Positioned.fill(
                    child: Container(
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          begin: Alignment.topCenter,
                          end: Alignment.bottomCenter,
                          colors: [
                            Colors.black.withOpacity(0.4),
                            Colors.black.withOpacity(0.2),
                            Colors.black.withOpacity(0.5),
                            Colors.black.withOpacity(0.85),
                            Colors.black.withOpacity(0.95),
                          ],
                          stops: const [0.0, 0.25, 0.55, 0.8, 1.0],
                        ),
                      ),
                    ),
                  ),

                  AnimatedBuilder(
                    animation: _scanCtrl,
                    builder: (_, __) => Positioned(
                      top: _scanCtrl.value *
                          MediaQuery.of(context).size.height,
                      left: 0,
                      right: 0,
                      child: Container(
                        height: 2,
                        decoration: BoxDecoration(
                          gradient: LinearGradient(
                            colors: [
                              Colors.transparent,
                              C.accent.withOpacity(0.4),
                              C.accent.withOpacity(0.8),
                              C.accent.withOpacity(0.4),
                              Colors.transparent,
                            ],
                          ),
                          boxShadow: [
                            BoxShadow(
                              color: C.accent.withOpacity(0.5),
                              blurRadius: 12,
                              spreadRadius: 1,
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),

                  SafeArea(
                    child: Column(
                      children: [
                        const Spacer(flex: 2),

                        FadeTransition(
                          opacity: _logoFade,
                          child: ScaleTransition(
                            scale: _logoScale,
                            child: _buildLogoMedallion(C, isComic),
                          ),
                        ),

                        const SizedBox(height: 24),

                        FadeTransition(
                          opacity: _logoFade,
                          child: _buildTitle(C, isComic),
                        ),

                        const SizedBox(height: 12),

                        SlideTransition(
                          position: _subtitleSlide,
                          child: FadeTransition(
                            opacity: _logoFade,
                            child: _buildSubtitle(C, isComic),
                          ),
                        ),

                        const Spacer(flex: 2),

                        FadeTransition(
                          opacity: _logoFade,
                          child: _buildLoadingPanel(C, isComic),
                        ),

                        const SizedBox(height: 16),

                        FadeTransition(
                          opacity: _logoFade,
                          child: _buildEnterButton(C, isComic),
                        ),

                        const Spacer(flex: 1),
                      ],
                    ),
                  ),

                  Positioned(
                    top: MediaQuery.of(context).padding.top + 12,
                    right: 12,
                    child: FadeTransition(
                      opacity: _logoFade,
                      child: _buildSkipButton(C, isComic),
                    ),
                  ),

                  Positioned(
                    top: MediaQuery.of(context).padding.top + 12,
                    left: 12,
                    child: FadeTransition(
                      opacity: _logoFade,
                      child: _buildCornerPanel(C, isComic),
                    ),
                  ),
                ],
              ),
            );
          },
        );
      },
    );
  }

  // ═══════════════════════════════════════════════════════
  // LOGO MEDALLION
  // ═══════════════════════════════════════════════════════
  Widget _buildLogoMedallion(AppPalette C, bool isComic) {
    return SizedBox(
      width: 160,
      height: 160,
      child: Stack(
        alignment: Alignment.center,
        children: [
          AnimatedBuilder(
            animation: _floatCtrl,
            builder: (_, __) => Container(
              width: 160,
              height: 160,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: RadialGradient(
                  colors: [
                    C.accent.withOpacity(0.15 + _floatCtrl.value * 0.15),
                    Colors.transparent,
                  ],
                  stops: const [0.6, 1.0],
                ),
              ),
            ),
          ),

          Container(
            width: 140,
            height: 140,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [C.accentShine, C.accent, C.primary, C.primaryLo],
                stops: const [0.0, 0.4, 0.7, 1.0],
              ),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(0.85),
                  offset: const Offset(0, 8),
                  blurRadius: 20,
                ),
                BoxShadow(
                  color: C.primary.withOpacity(0.4),
                  blurRadius: 25,
                  spreadRadius: 3,
                ),
              ],
            ),
            padding: const EdgeInsets.all(4),
            child: Container(
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: RadialGradient(
                  colors: [C.text, C.bg, C.bgDark],
                ),
              ),
              padding: const EdgeInsets.all(6),
              child: Container(
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: LinearGradient(
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                    colors: [C.bgDark, C.bg, C.bgDeep],
                  ),
                  border: Border.all(
                    color: Colors.black.withOpacity(0.7),
                    width: 2,
                  ),
                ),
                child: Icon(
                  Icons.shield_moon_rounded,
                  color: C.accentShine,
                  size: 55,
                  shadows: [
                    Shadow(color: C.accent, blurRadius: 20),
                    const Shadow(
                      color: Colors.black,
                      offset: Offset(0, 2),
                      blurRadius: 6,
                    ),
                  ],
                ),
              ),
            ),
          ),

          if (!isComic)
            ...List.generate(8, (i) {
              final angle = (i * math.pi * 2 / 8) - math.pi / 2;
              final r = 68.0;
              return Positioned(
                left: 80 + math.cos(angle) * r - 5,
                top: 80 + math.sin(angle) * r - 5,
                child: _Rivet(C: C, size: 10),
              );
            }),

          if (!isComic)
            Positioned(
              top: 0,
              child: AnimatedBuilder(
                animation: _ledPulse,
                builder: (_, __) => _Led(
                  color: C.primaryHi,
                  size: 10,
                  blink: true,
                ),
              ),
            ),
        ],
      ),
    );
  }

  // ═══════════════════════════════════════════════════════
  // TITLE
  // ═══════════════════════════════════════════════════════
  Widget _buildTitle(AppPalette C, bool isComic) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20),
      child: Container(
        decoration: isComic
            ? BoxDecoration(
                color: C.bgDark,
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: Colors.black, width: 4),
                boxShadow: const [
                  BoxShadow(
                    color: Colors.black,
                    offset: Offset(6, 6),
                    blurRadius: 0,
                  ),
                ],
              )
            : BoxDecoration(
                borderRadius: BorderRadius.circular(12),
                gradient: LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [C.text, C.bg, C.bgDark, C.bgDeep],
                  stops: const [0.0, 0.4, 0.7, 1.0],
                ),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.85),
                    offset: const Offset(0, 8),
                    blurRadius: 16,
                  ),
                  const BoxShadow(
                    color: Colors.white24,
                    offset: Offset(-1, -1),
                    blurRadius: 3,
                  ),
                ],
              ),
        padding: EdgeInsets.all(isComic ? 4 : 3),
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
          decoration: isComic
              ? null
              : BoxDecoration(
                  borderRadius: BorderRadius.circular(9),
                  gradient: LinearGradient(
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                    colors: [C.bg, C.bgDark, C.bgDeep],
                  ),
                  border: Border.all(color: Colors.black.withOpacity(0.5)),
                ),
          child: Stack(
            children: [
              if (!isComic)
                Transform.translate(
                  offset: const Offset(1, 1),
                  child: Text(
                    'CONFLICT',
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      color: Colors.white.withOpacity(0.4),
                      fontSize: 28,
                      fontWeight: FontWeight.w900,
                      fontFamily: 'Orbitron',
                      letterSpacing: 6,
                      height: 1,
                    ),
                  ),
                ),
              Text(
                'CONFLICT',
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: isComic ? C.comicText : C.accentShine,
                  fontSize: isComic ? 30 : 28,
                  fontWeight: FontWeight.w900,
                  fontFamily: isComic ? 'Bangers' : 'Orbitron',
                  letterSpacing: isComic ? 3 : 6,
                  height: 1,
                  shadows: isComic
                      ? [
                          Shadow(
                            color: C.comicTextOutline,
                            offset: const Offset(2, 2),
                            blurRadius: 0,
                          ),
                        ]
                      : [
                          Shadow(color: C.accent, blurRadius: 15),
                          Shadow(
                            color: C.primaryLo,
                            offset: const Offset(0, 1),
                            blurRadius: 2,
                          ),
                          const Shadow(
                            color: Colors.black,
                            offset: Offset(0, 2),
                            blurRadius: 6,
                          ),
                        ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════
  // SUBTITLE
  // ═══════════════════════════════════════════════════════
  Widget _buildSubtitle(AppPalette C, bool isComic) {
    return Column(
      children: [
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
          decoration: isComic
              ? BoxDecoration(
                  borderRadius: BorderRadius.circular(12),
                  color: C.bgDark,
                  border: Border.all(color: Colors.black, width: 3),
                  boxShadow: const [
                    BoxShadow(
                      color: Colors.black,
                      offset: Offset(3, 3),
                      blurRadius: 0,
                    ),
                  ],
                )
              : BoxDecoration(
                  borderRadius: BorderRadius.circular(20),
                  color: Colors.black.withOpacity(0.6),
                  border: Border.all(color: C.bgDark, width: 1),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withOpacity(0.8),
                      offset: const Offset(0, 3),
                      blurRadius: 6,
                    ),
                  ],
                ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              _Led(color: C.accent, size: 6, blink: true),
              const SizedBox(width: 8),
              Text(
                'SYSTEM ONLINE',
                style: TextStyle(
                  color: isComic ? C.comicText : C.accent,
                  fontSize: isComic ? 12 : 10,
                  fontWeight: FontWeight.w900,
                  fontFamily: isComic ? 'Bangers' : 'Orbitron',
                  letterSpacing: 2.5,
                  shadows: isComic
                      ? [
                          Shadow(
                            color: C.comicTextOutline,
                            offset: const Offset(1, 1),
                            blurRadius: 0,
                          ),
                        ]
                      : [Shadow(color: C.accent, blurRadius: 6)],
                ),
              ),
              const SizedBox(width: 8),
              _Led(color: C.primaryHi, size: 6, blink: true),
            ],
          ),
        ),
        const SizedBox(height: 10),
        Text(
          'SECURITY · ENTERPRISE · EDITION',
          style: TextStyle(
            color: isComic
                ? C.comicTextSub
                : C.text.withOpacity(0.5),
            fontSize: 9,
            fontWeight: FontWeight.w600,
            fontFamily: isComic ? 'ComicNeue' : 'ShareTechMono',
            letterSpacing: 4,
          ),
        ),
      ],
    );
  }

  // ═══════════════════════════════════════════════════════
  // LOADING PANEL
  // ═══════════════════════════════════════════════════════
  Widget _buildLoadingPanel(AppPalette C, bool isComic) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 40),
      child: isComic
          ? Container(
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                color: C.bgDark,
                borderRadius: BorderRadius.circular(14),
                border: Border.all(color: Colors.black, width: 3.5),
                boxShadow: const [
                  BoxShadow(
                    color: Colors.black,
                    offset: Offset(4, 4),
                    blurRadius: 0,
                  ),
                ],
              ),
              child: _loadingContent(C, isComic),
            )
          : Container(
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(10),
                color: Colors.black.withOpacity(0.7),
                border: Border.all(color: C.bgDark, width: 1.5),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.9),
                    offset: const Offset(0, 3),
                    blurRadius: 8,
                  ),
                  const BoxShadow(
                    color: Colors.white10,
                    offset: Offset(0, -1),
                    blurRadius: 1,
                  ),
                ],
              ),
              child: _loadingContent(C, isComic),
            ),
    );
  }

  Widget _loadingContent(AppPalette C, bool isComic) {
    return Column(
      children: [
        Row(
          children: [
            if (!isComic) _Screw(C: C, size: 10),
            if (!isComic) const SizedBox(width: 8),
            _Led(color: C.accent, size: 6, blink: true),
            const SizedBox(width: 8),
            Expanded(
              child: AnimatedBuilder(
                animation: _loadProgress,
                builder: (_, __) => Text(
                  'INITIALIZING SYSTEM ${(_loadProgress.value * 100).toStringAsFixed(0)}%',
                  style: TextStyle(
                    color: isComic ? C.comicText : C.accent,
                    fontSize: 9,
                    fontWeight: FontWeight.w900,
                    fontFamily: isComic ? 'Bangers' : 'Orbitron',
                    letterSpacing: 1.5,
                    shadows: isComic
                        ? [
                            Shadow(
                              color: C.comicTextOutline,
                              offset: const Offset(1, 1),
                              blurRadius: 0,
                            ),
                          ]
                        : null,
                  ),
                ),
              ),
            ),
            if (!isComic) _Screw(C: C, size: 10, rotation: 0),
          ],
        ),
        const SizedBox(height: 10),
        AnimatedBuilder(
          animation: _loadProgress,
          builder: (_, __) => Container(
            height: 6,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(3),
              color: isComic ? C.contrastTextOn(C.bgDark) : Colors.black,
              border: Border.all(
                color: isComic ? Colors.black : C.bgDark,
                width: isComic ? 2 : 0.8,
              ),
            ),
            child: FractionallySizedBox(
              alignment: Alignment.centerLeft,
              widthFactor: _loadProgress.value,
              child: Container(
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(3),
                  gradient: LinearGradient(
                    colors: [C.primary, C.primaryHi, C.accentShine],
                  ),
                  boxShadow: isComic
                      ? null
                      : [
                          BoxShadow(
                            color: C.accent.withOpacity(0.8),
                            blurRadius: 6,
                          ),
                        ],
                ),
              ),
            ),
          ),
        ),
      ],
    );
  }

  // ═══════════════════════════════════════════════════════
  // ENTER BUTTON
  // ═══════════════════════════════════════════════════════
  Widget _buildEnterButton(AppPalette C, bool isComic) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 40),
      child: GestureDetector(
        onTap: _goToWelcome,
        child: isComic
            ? _buildComicEnterButton(C)
            : _buildOriginalEnterButton(C),
      ),
    );
  }

  Widget _buildComicEnterButton(AppPalette C) {
    final textColor = C.contrastTextOn(C.primaryHi);
    return Container(
      height: 58,
      decoration: BoxDecoration(
        color: C.primaryHi,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: Colors.black, width: 4),
        boxShadow: const [
          BoxShadow(
            color: Colors.black,
            offset: Offset(6, 6),
            blurRadius: 0,
          ),
        ],
      ),
      child: Center(
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              Icons.login_rounded,
              color: textColor,
              size: 20,
              shadows: [
                Shadow(
                  color: textColor == Colors.white ? Colors.black : Colors.white,
                  offset: const Offset(1, 1),
                  blurRadius: 0,
                ),
              ],
            ),
            const SizedBox(width: 12),
            Text(
              'ENTER SYSTEM',
              style: TextStyle(
                color: textColor,
                fontSize: 18,
                fontWeight: FontWeight.w900,
                fontFamily: 'Bangers',
                letterSpacing: 2,
                shadows: [
                  Shadow(
                    color: textColor == Colors.white ? Colors.black : Colors.white,
                    offset: const Offset(2, 2),
                    blurRadius: 0,
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildOriginalEnterButton(AppPalette C) {
    return Container(
      height: 54,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(14),
        gradient: LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [C.accentShine, C.accentHi, C.primary, C.primaryLo],
          stops: const [0.0, 0.3, 0.7, 1.0],
        ),
        border: Border.all(color: C.primaryLo, width: 2),
        boxShadow: [
          BoxShadow(
            color: C.primary.withOpacity(0.5),
            blurRadius: 15,
            spreadRadius: 1,
          ),
          BoxShadow(
            color: Colors.black.withOpacity(0.8),
            offset: const Offset(0, 5),
            blurRadius: 8,
          ),
        ],
      ),
      child: Stack(
        alignment: Alignment.center,
        children: [
          Positioned(
            top: 3,
            left: 15,
            right: 15,
            child: Container(
              height: 10,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(8),
                gradient: LinearGradient(
                  colors: [
                    Colors.white.withOpacity(0.5),
                    Colors.transparent,
                  ],
                ),
              ),
            ),
          ),
          Positioned(top: 5, left: 5, child: _Rivet(C: C, size: 6)),
          Positioned(top: 5, right: 5, child: _Rivet(C: C, size: 6)),
          Positioned(bottom: 5, left: 5, child: _Rivet(C: C, size: 6)),
          Positioned(bottom: 5, right: 5, child: _Rivet(C: C, size: 6)),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              _Led(color: C.bgDeep, size: 8, blink: false),
              const SizedBox(width: 12),
              Text(
                'ENTER SYSTEM',
                style: TextStyle(
                  color: C.bgDeep,
                  fontSize: 14,
                  fontWeight: FontWeight.w900,
                  fontFamily: 'Orbitron',
                  letterSpacing: 3,
                  shadows: const [
                    Shadow(
                      color: Colors.white54,
                      offset: Offset(0, 1),
                      blurRadius: 1,
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 12),
              _Led(color: C.bgDeep, size: 8, blink: false),
            ],
          ),
        ],
      ),
    );
  }

  // ═══════════════════════════════════════════════════════
  // SKIP BUTTON
  // ═══════════════════════════════════════════════════════
  Widget _buildSkipButton(AppPalette C, bool isComic) {
    return GestureDetector(
      onTap: _goToWelcome,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
        decoration: isComic
            ? BoxDecoration(
                borderRadius: BorderRadius.circular(12),
                color: C.bgDark,
                border: Border.all(color: Colors.black, width: 3),
                boxShadow: const [
                  BoxShadow(
                    color: Colors.black,
                    offset: Offset(3, 3),
                    blurRadius: 0,
                  ),
                ],
              )
            : BoxDecoration(
                borderRadius: BorderRadius.circular(20),
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [C.bg, C.bgDark],
                ),
                border: Border.all(
                  color: C.textSub.withOpacity(0.5),
                  width: 1,
                ),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.75),
                    offset: const Offset(0, 3),
                    blurRadius: 6,
                  ),
                ],
              ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            _Led(color: C.accent, size: 5, blink: true),
            const SizedBox(width: 8),
            Text(
              'SKIP',
              style: TextStyle(
                color: isComic ? C.comicText : C.text,
                fontSize: isComic ? 12 : 10,
                fontWeight: FontWeight.w900,
                fontFamily: isComic ? 'Bangers' : 'Orbitron',
                letterSpacing: 2,
                shadows: isComic
                    ? [
                        Shadow(
                          color: C.comicTextOutline,
                          offset: const Offset(1, 1),
                          blurRadius: 0,
                        ),
                      ]
                    : null,
              ),
            ),
            const SizedBox(width: 6),
            Icon(
              Icons.skip_next_rounded,
              color: C.primaryHi,
              size: 14,
            ),
          ],
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════
  // CORNER PANEL
  // ═══════════════════════════════════════════════════════
  Widget _buildCornerPanel(AppPalette C, bool isComic) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
      decoration: isComic
          ? BoxDecoration(
              borderRadius: BorderRadius.circular(10),
              color: C.bgDark,
              border: Border.all(color: Colors.black, width: 3),
            )
          : BoxDecoration(
              borderRadius: BorderRadius.circular(6),
              gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [C.bg, C.bgDark],
              ),
              border: Border.all(
                color: C.textSub.withOpacity(0.5),
                width: 1,
              ),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(0.75),
                  offset: const Offset(0, 3),
                  blurRadius: 6,
                ),
              ],
            ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          if (!isComic) _Screw(C: C, size: 8),
          if (!isComic) const SizedBox(width: 6),
          _Led(color: C.primaryHi, size: 5, blink: true),
          const SizedBox(width: 6),
          Text(
            'LATEST',
            style: TextStyle(
              color: isComic ? C.comicText : C.primaryHi,
              fontSize: isComic ? 10 : 9,
              fontWeight: FontWeight.w900,
              fontFamily: isComic ? 'Bangers' : 'Orbitron',
              letterSpacing: 1.5,
              shadows: isComic
                  ? [
                      Shadow(
                        color: C.comicTextOutline,
                        offset: const Offset(1, 1),
                        blurRadius: 0,
                      ),
                    ]
                  : null,
            ),
          ),
        ],
      ),
    );
  }
}