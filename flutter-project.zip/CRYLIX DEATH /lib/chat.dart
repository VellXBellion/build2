// lib/chat.dart
import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:web_socket_channel/web_socket_channel.dart';
import 'app_theme.dart';
import 'api_config.dart';

// ═══════════════════════════════════════════════════════════
// REUSABLE COMPONENTS
// ═══════════════════════════════════════════════════════════
class _Led extends StatelessWidget {
  final Color color;
  final double size;
  const _Led({required this.color, this.size = 7});

  @override
  Widget build(BuildContext context) {
    final isComic = AppTheme.currentStyle.value == ThemeStyle.comic3d;
    if (isComic) {
      return Container(
        width: size,
        height: size,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          color: color,
          border: Border.all(color: Colors.black, width: size * 0.18),
        ),
      );
    }
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        color: color,
        boxShadow: [
          BoxShadow(
              color: color.withOpacity(0.6),
              blurRadius: size,
              spreadRadius: 0.5),
        ],
      ),
    );
  }
}

class _Screw extends StatelessWidget {
  final AppPalette C;
  final double size;
  const _Screw({required this.C, this.size = 10});
  @override
  Widget build(BuildContext context) {
    if (AppTheme.currentStyle.value == ThemeStyle.comic3d) {
      return const SizedBox.shrink();
    }
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [C.text, C.bgDark],
        ),
      ),
      child: Center(
        child: Container(
          width: size * 0.6,
          height: 1.2,
          color: Colors.black.withOpacity(0.7),
        ),
      ),
    );
  }
}

class _SoftPanel extends StatelessWidget {
  final AppPalette C;
  final Widget child;
  final EdgeInsets padding;
  final double radius;
  final Color? accent;
  const _SoftPanel({
    required this.C,
    required this.child,
    this.padding = const EdgeInsets.all(14),
    this.radius = 12,
    this.accent,
  });

  @override
  Widget build(BuildContext context) {
    final isComic = AppTheme.currentStyle.value == ThemeStyle.comic3d;
    final accentColor = accent ?? C.textSub;

    if (isComic) {
      return Container(
        padding: padding,
        decoration: BoxDecoration(
          color: C.bgDark,
          borderRadius: BorderRadius.circular(radius + 4),
          border: Border.all(color: Colors.black, width: 4),
          boxShadow: const [
            BoxShadow(
              color: Colors.black,
              offset: Offset(5, 5),
              blurRadius: 0,
            ),
          ],
        ),
        child: child,
      );
    }

    return Container(
      padding: padding,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(radius),
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [C.bg, C.bgDark],
        ),
        border: Border.all(color: accentColor, width: 1.2),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.5),
            offset: const Offset(0, 4),
            blurRadius: 8,
          ),
        ],
      ),
      child: child,
    );
  }
}

class _SoftInset extends StatelessWidget {
  final AppPalette C;
  final Widget child;
  final EdgeInsets padding;
  const _SoftInset({
    required this.C,
    required this.child,
    this.padding = const EdgeInsets.symmetric(horizontal: 12),
  });

  @override
  Widget build(BuildContext context) {
    final isComic = AppTheme.currentStyle.value == ThemeStyle.comic3d;

    if (isComic) {
      return Container(
        padding: padding,
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(10),
          border: Border.all(color: Colors.black, width: 3),
        ),
        child: child,
      );
    }

    return Container(
      padding: padding,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(8),
        color: C.bgDeep,
        border: Border.all(color: C.bgDark, width: 1.5),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.8),
            offset: const Offset(0, 1),
            blurRadius: 2,
          ),
        ],
      ),
      child: child,
    );
  }
}

// ═══════════════════════════════════════════════════════════
// CHAT PAGE
// ═══════════════════════════════════════════════════════════
class ChatPage extends StatefulWidget {
  final String username;
  final String sessionKey;

  const ChatPage({
    super.key,
    required this.username,
    required this.sessionKey,
  });

  @override
  State<ChatPage> createState() => _ChatPageState();
}

class _ChatPageState extends State<ChatPage>
    with SingleTickerProviderStateMixin {
  late TabController _tabController;
  WebSocketChannel? _channel;

  List<dynamic> _globalMessages = [];
  bool _globalLoading = true;
  final TextEditingController _globalInputCtrl = TextEditingController();
  final ScrollController _globalScrollCtrl = ScrollController();
  Map<String, dynamic>? _globalReplyTo;

  List<dynamic> _privateChats = [];
  List<dynamic> _privateMessages = [];
  String? _selectedUser;
  bool _privateLoading = true;
  final TextEditingController _privateInputCtrl = TextEditingController();
  final ScrollController _privateScrollCtrl = ScrollController();
  Map<String, dynamic>? _privateReplyTo;

  Map<String, dynamic> _myProfile = {};

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);
    _initialize();
  }

  @override
  void dispose() {
    _tabController.dispose();
    _channel?.sink.close();
    _globalInputCtrl.dispose();
    _globalScrollCtrl.dispose();
    _privateInputCtrl.dispose();
    _privateScrollCtrl.dispose();
    super.dispose();
  }

  void _initialize() {
    _loadProfile();
    _connectWebSocket();
    _loadGlobalMessages();
    _loadPrivateChats();
  }

  Future<void> _loadProfile() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final sessionKey =
          prefs.getString('session_key') ?? widget.sessionKey;
      final res = await http.get(
          Uri.parse('$baseUrl/chat/profile?key=$sessionKey'));
      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        if (data['valid'] == true && mounted) {
          setState(() => _myProfile = data['profile']);
        }
      }
    } catch (_) {}
  }

  void _connectWebSocket() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final sessionKey =
          prefs.getString('session_key') ?? widget.sessionKey;
      _channel = WebSocketChannel.connect(Uri.parse(WS_URL));
      _channel!.stream.listen(_handleWebSocketMessage, onError: (_) {});
      _channel!.sink.add(jsonEncode({'type': 'auth', 'key': sessionKey}));
    } catch (_) {}
  }

  void _handleWebSocketMessage(dynamic data) {
    try {
      final msg = jsonDecode(data);
      if (msg['type'] == 'global_message') {
        _addGlobalMessage(msg['message']);
      } else if (msg['type'] == 'private_message') {
        _addPrivateMessage(msg['message']);
      } else if (msg['type'] == 'refresh_chat_list') {
        _loadPrivateChats();
      }
    } catch (_) {}
  }

  Future<void> _loadGlobalMessages() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final sessionKey =
          prefs.getString('session_key') ?? widget.sessionKey;
      final res = await http.get(Uri.parse(
          '$baseUrl/chat/global/messages?key=$sessionKey&limit=100'));
      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        if (data['valid'] == true && mounted) {
          setState(() {
            _globalMessages = data['messages'];
            _globalLoading = false;
          });
          WidgetsBinding.instance.addPostFrameCallback((_) {
            _scrollToBottom(_globalScrollCtrl);
          });
        }
      }
    } catch (_) {
      if (mounted) setState(() => _globalLoading = false);
    }
  }

  void _addGlobalMessage(dynamic msg) {
    if (!mounted) return;
    setState(() => _globalMessages.add(msg));
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _scrollToBottom(_globalScrollCtrl);
    });
  }

  void _scrollToBottom(ScrollController controller) {
    if (controller.hasClients) {
      controller.animateTo(
        controller.position.maxScrollExtent,
        duration: const Duration(milliseconds: 300),
        curve: Curves.easeOut,
      );
    }
  }

  Future<void> _sendGlobalMessage() async {
    final text = _globalInputCtrl.text.trim();
    if (text.isEmpty && _globalReplyTo == null) return;

    String finalText = text;
    if (_globalReplyTo != null) {
      finalText = '@${_globalReplyTo!['sender']} $text';
    }

    setState(() => _globalInputCtrl.text = '');

    try {
      final prefs = await SharedPreferences.getInstance();
      final sessionKey =
          prefs.getString('session_key') ?? widget.sessionKey;
      final body = jsonEncode({
        'message': finalText,
        'type': 'text',
        'replyTo': _globalReplyTo?['id'],
      });

      final res = await http.post(
        Uri.parse('$baseUrl/chat/global/send?key=$sessionKey'),
        headers: {'Content-Type': 'application/json'},
        body: body,
      );

      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        if (data['valid'] == true && mounted) {
          setState(() => _globalReplyTo = null);
          _loadGlobalMessages();
        }
      }
    } catch (_) {}
  }

  Future<void> _loadPrivateChats() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final sessionKey =
          prefs.getString('session_key') ?? widget.sessionKey;
      final res = await http.get(Uri.parse(
          '$baseUrl/chat/private/users?key=$sessionKey'));
      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        if (data['valid'] == true && mounted) {
          setState(() {
            _privateChats = data['users'];
            _privateLoading = false;
          });
        }
      }
    } catch (_) {
      if (mounted) setState(() => _privateLoading = false);
    }
  }

  Future<void> _loadPrivateMessages(String withUser) async {
    setState(() => _privateLoading = true);
    try {
      final prefs = await SharedPreferences.getInstance();
      final sessionKey =
          prefs.getString('session_key') ?? widget.sessionKey;
      final res = await http.get(Uri.parse(
          '$baseUrl/chat/private/messages/$withUser?key=$sessionKey&limit=100'));
      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        if (data['valid'] == true && mounted) {
          setState(() {
            _privateMessages = data['messages'];
            _privateLoading = false;
          });
          WidgetsBinding.instance.addPostFrameCallback((_) {
            _scrollToBottom(_privateScrollCtrl);
          });

          await http.post(Uri.parse(
              '$baseUrl/chat/private/mark-read/$withUser?key=$sessionKey'));
        }
      }
    } catch (_) {
      if (mounted) setState(() => _privateLoading = false);
    }
  }

  void _addPrivateMessage(dynamic msg) {
    if (!mounted) return;
    final isCurrentChat = _selectedUser == msg['sender'] ||
        _selectedUser == msg['receiver'];
    if (isCurrentChat) {
      setState(() => _privateMessages.add(msg));
      WidgetsBinding.instance.addPostFrameCallback((_) {
        _scrollToBottom(_privateScrollCtrl);
      });
    }
    _loadPrivateChats();
  }

  Future<void> _sendPrivateMessage() async {
    final text = _privateInputCtrl.text.trim();
    if (text.isEmpty || _selectedUser == null) return;

    String finalText = text;
    if (_privateReplyTo != null) {
      finalText = '@${_privateReplyTo!['sender']} $text';
    }

    setState(() => _privateInputCtrl.text = '');

    try {
      final prefs = await SharedPreferences.getInstance();
      final sessionKey =
          prefs.getString('session_key') ?? widget.sessionKey;
      final body = jsonEncode({
        'message': finalText,
        'type': 'text',
        'replyTo': _privateReplyTo?['id'],
      });

      final res = await http.post(
        Uri.parse('$baseUrl/chat/private/send/$_selectedUser?key=$sessionKey'),
        headers: {'Content-Type': 'application/json'},
        body: body,
      );

      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        if (data['valid'] == true && mounted) {
          setState(() => _privateReplyTo = null);
          _loadPrivateMessages(_selectedUser!);
        }
      }
    } catch (_) {}
  }

  Future<void> _searchAndStartChat() async {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (ctx) => _SearchUserSheet(
        sessionKey: widget.sessionKey,
        currentUsername: widget.username,
        onSelectUser: (user) {
          Navigator.pop(ctx);
          setState(() {
            _selectedUser = user['username'];
            _privateReplyTo = null;
          });
          _loadPrivateMessages(user['username']);
          _tabController.animateTo(1);
        },
      ),
    );
  }

  String _formatTime(String? timestamp) {
    if (timestamp == null) return '';
    try {
      final time = DateTime.parse(timestamp);
      final now = DateTime.now();
      final diff = now.difference(time);
      if (diff.inSeconds < 60) return 'Just now';
      if (diff.inMinutes < 60) return '${diff.inMinutes}m ago';
      if (diff.inHours < 24) return '${diff.inHours}h ago';
      return '${diff.inDays}d ago';
    } catch (_) {
      return '';
    }
  }

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<AppPalette>(
      valueListenable: AppTheme.current,
      builder: (context, C, _) {
        return ValueListenableBuilder<ThemeStyle>(
          valueListenable: AppTheme.currentStyle,
          builder: (context, style, __) {
            final isComic = style == ThemeStyle.comic3d;

            return Scaffold(
              backgroundColor: C.bgDark,
              body: Container(
                decoration: isComic
                    ? BoxDecoration(color: C.bg)
                    : BoxDecoration(
                        gradient: LinearGradient(
                          begin: Alignment.topCenter,
                          end: Alignment.bottomCenter,
                          colors: [C.bg, C.bgDark, C.bgDeep],
                        ),
                      ),
                child: Stack(
                  children: [
                    if (isComic)
                      Positioned.fill(
                        child: IgnorePointer(
                          child: CustomPaint(
                            painter: _ComicHalftonePainter(
                                color: C.primaryLo.withOpacity(0.12)),
                          ),
                        ),
                      ),
                    SafeArea(
                      child: Column(
                        children: [
                          _buildTopBar(C, isComic),
                          _buildTabBar(C, isComic),
                          Expanded(
                            child: TabBarView(
                              controller: _tabController,
                              children: [
                                _buildGlobalChat(C, isComic),
                                _buildPrivateChat(C, isComic),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            );
          },
        );
      },
    );
  }

  Widget _buildTopBar(AppPalette C, bool isComic) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
      child: _SoftPanel(
        C: C,
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
        accent: C.textSub,
        child: Row(
          children: [
            if (!isComic) _Screw(C: C, size: 12),
            if (!isComic) const SizedBox(width: 8),
            _MetalIconButton(
              C: C,
              icon: Icons.arrow_back_rounded,
              onTap: () => Navigator.pop(context),
            ),
            const SizedBox(width: 10),
            _Led(color: C.accentHi, size: 7),
            const SizedBox(width: 10),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text(
                    'NULL TR4SHER CHAT',
                    style: TextStyle(
                      color: isComic ? Colors.black : C.accent,
                      fontFamily: isComic ? 'Bangers' : 'Orbitron',
                      fontWeight: FontWeight.w900,
                      fontSize: isComic ? 16 : 12,
                      letterSpacing: isComic ? 1.5 : 2,
                    ),
                  ),
                  const SizedBox(height: 1),
                  Text(
                    '@${widget.username}',
                    style: TextStyle(
                      color: isComic
                          ? Colors.black.withOpacity(0.5)
                          : C.text.withOpacity(0.55),
                      fontSize: 9,
                      fontFamily:
                          isComic ? 'ComicNeue' : 'ShareTechMono',
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                ],
              ),
            ),
            _MetalIconButton(
              C: C,
              icon: Icons.refresh_rounded,
              onTap: () {
                _loadGlobalMessages();
                _loadPrivateChats();
                if (_selectedUser != null) {
                  _loadPrivateMessages(_selectedUser!);
                }
              },
            ),
            if (!isComic) const SizedBox(width: 8),
            if (!isComic) _Screw(C: C, size: 12),
          ],
        ),
      ),
    );
  }

  Widget _buildTabBar(AppPalette C, bool isComic) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 4),
      child: _SoftPanel(
        C: C,
        padding: const EdgeInsets.all(3),
        accent: C.textSub,
        child: SizedBox(
          height: 42,
          child: TabBar(
            controller: _tabController,
            indicator: BoxDecoration(
              borderRadius: BorderRadius.circular(isComic ? 8 : 7),
              gradient: isComic
                  ? null
                  : LinearGradient(
                      begin: Alignment.topCenter,
                      end: Alignment.bottomCenter,
                      colors: [C.accentHi, C.accent, C.primaryLo]),
              color: isComic ? C.primaryHi : null,
              border: isComic
                  ? Border.all(color: Colors.black, width: 3)
                  : null,
              boxShadow: isComic
                  ? null
                  : [
                      BoxShadow(
                        color: C.accentHi.withOpacity(0.4),
                        blurRadius: 8,
                      ),
                    ],
            ),
            labelColor: Colors.white,
            unselectedLabelColor: isComic
                ? Colors.black.withOpacity(0.5)
                : C.text.withOpacity(0.6),
            dividerColor: Colors.transparent,
            labelStyle: TextStyle(
              fontSize: isComic ? 14 : 11,
              fontWeight: FontWeight.w900,
              fontFamily: isComic ? 'Bangers' : 'Orbitron',
              letterSpacing: 1.5,
            ),
            unselectedLabelStyle: TextStyle(
              fontSize: isComic ? 13 : 11,
              fontWeight: FontWeight.w700,
              fontFamily: isComic ? 'Bangers' : 'Orbitron',
              letterSpacing: 1.5,
            ),
            indicatorSize: TabBarIndicatorSize.tab,
            tabs: const [
              Tab(
                height: 36,
                icon: Icon(Icons.public_rounded, size: 16),
                text: 'GLOBAL',
              ),
              Tab(
                height: 36,
                icon: Icon(Icons.lock_rounded, size: 16),
                text: 'PRIVATE',
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildGlobalChat(AppPalette C, bool isComic) {
    return Column(
      children: [
        if (_globalReplyTo != null)
          _buildReplyPreviewBar(C, isComic, isGlobal: true),
        Expanded(
          child: _globalLoading
              ? Center(
                  child: CircularProgressIndicator(
                      color: isComic ? Colors.black : C.accent,
                      strokeWidth: 2))
              : _globalMessages.isEmpty
                  ? _buildEmptyState(C, isComic, 'Belum ada pesan',
                      'Jadilah yang pertama mengirim pesan!')
                  : ListView.builder(
                      controller: _globalScrollCtrl,
                      padding: const EdgeInsets.only(
                          left: 14, right: 14, bottom: 12),
                      itemCount: _globalMessages.length,
                      itemBuilder: (ctx, i) =>
                          _buildGlobalMessageBubble(C, isComic,
                              _globalMessages[i]),
                    ),
        ),
        _buildInputBar(C, isComic,
          controller: _globalInputCtrl,
          onSend: _sendGlobalMessage,
          hint: 'Type a message...',
          isGlobal: true,
        ),
      ],
    );
  }

  Widget _buildGlobalMessageBubble(
      AppPalette C, bool isComic, dynamic msg) {
    final isMe = msg['sender'] == widget.username;
    final profile = msg['senderProfile'] ?? {};
    final name = profile['name'] ?? msg['sender'];
    final replyTo = msg['replyTo'];
    final initial = name.isNotEmpty ? name[0].toUpperCase() : '?';

    return GestureDetector(
      onLongPress: () {
        setState(() {
          _globalReplyTo = {
            'id': msg['id'],
            'sender': msg['sender'],
            'message': msg['message'],
          };
        });
      },
      child: Container(
        margin: EdgeInsets.only(
          left: isMe ? 50 : 0,
          right: isMe ? 0 : 50,
          top: 6,
          bottom: 6,
        ),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisAlignment:
              isMe ? MainAxisAlignment.end : MainAxisAlignment.start,
          children: [
            if (!isMe) ...[
              GestureDetector(
                onTap: () {
                  if (msg['sender'] != widget.username) {
                    setState(() {
                      _selectedUser = msg['sender'];
                      _privateReplyTo = null;
                    });
                    _loadPrivateMessages(msg['sender']);
                    _tabController.animateTo(1);
                  }
                },
                child: Container(
                  width: 36,
                  height: 36,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    gradient: isComic
                        ? null
                        : LinearGradient(colors: [C.accent, C.primaryLo]),
                    color: isComic ? C.primaryHi : null,
                    border: Border.all(
                        color: isComic
                            ? Colors.black
                            : C.accentHi.withOpacity(0.6),
                        width: isComic ? 3 : 1),
                  ),
                  child: Center(
                    child: Text(
                      initial,
                      style: TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.w900,
                        fontFamily: isComic ? 'Bangers' : 'Orbitron',
                        fontSize: isComic ? 16 : 13,
                      ),
                    ),
                  ),
                ),
              ),
              const SizedBox(width: 8),
            ],
            Flexible(
              child: Column(
                crossAxisAlignment: isMe
                    ? CrossAxisAlignment.end
                    : CrossAxisAlignment.start,
                children: [
                  if (!isMe)
                    Padding(
                      padding: const EdgeInsets.only(left: 4, bottom: 4),
                      child: Text(
                        name,
                        style: TextStyle(
                          color: isComic
                              ? Colors.black.withOpacity(0.6)
                              : C.text.withOpacity(0.55),
                          fontSize: 9,
                          fontFamily:
                              isComic ? 'ComicNeue' : 'ShareTechMono',
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                    ),
                  if (replyTo != null)
                    _buildReplyBubble(C, isComic, replyTo, isMe),
                  _buildBubbleContent(C, isComic, msg['message'] ?? '', isMe),
                  Padding(
                    padding: const EdgeInsets.only(top: 4, left: 4, right: 4),
                    child: Text(
                      _formatTime(msg['timestamp']),
                      style: TextStyle(
                        color: isComic
                            ? Colors.black.withOpacity(0.5)
                            : C.text.withOpacity(0.4),
                        fontSize: 9,
                        fontFamily:
                            isComic ? 'ComicNeue' : 'ShareTechMono',
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildPrivateChat(AppPalette C, bool isComic) {
    return _selectedUser == null
        ? _buildChatList(C, isComic)
        : Column(
            children: [
              _buildChatHeader(C, isComic),
              if (_privateReplyTo != null)
                _buildReplyPreviewBar(C, isComic, isGlobal: false),
              Expanded(
                child: _privateLoading
                    ? Center(
                        child: CircularProgressIndicator(
                            color: isComic ? Colors.black : C.accent,
                            strokeWidth: 2))
                    : _privateMessages.isEmpty
                        ? _buildEmptyState(C, isComic, 'Belum ada pesan',
                            'Kirim pesan pertama untuk memulai!')
                        : ListView.builder(
                            controller: _privateScrollCtrl,
                            padding: const EdgeInsets.only(
                                left: 14, right: 14, bottom: 12),
                            itemCount: _privateMessages.length,
                            itemBuilder: (ctx, i) =>
                                _buildPrivateMessageBubble(C, isComic,
                                    _privateMessages[i]),
                          ),
              ),
              _buildInputBar(C, isComic,
                controller: _privateInputCtrl,
                onSend: _sendPrivateMessage,
                hint: 'E2EE encrypted message...',
                isGlobal: false,
              ),
            ],
          );
  }

  Widget _buildChatList(AppPalette C, bool isComic) {
    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
          child: _SearchBarButton(C: C, onTap: _searchAndStartChat),
        ),
        Expanded(
          child: _privateChats.isEmpty
              ? _buildEmptyState(C, isComic, 'Belum ada chat',
                  'Cari user untuk memulai percakapan private!')
              : ListView.builder(
                  padding: const EdgeInsets.symmetric(horizontal: 14),
                  itemCount: _privateChats.length,
                  itemBuilder: (ctx, i) =>
                      _buildChatListItem(C, isComic, _privateChats[i]),
                ),
        ),
      ],
    );
  }

  Widget _buildChatListItem(AppPalette C, bool isComic, dynamic chat) {
    final profile = chat['profile'] ?? {};
    final lastMsg = chat['lastMessage'];
    final isUnread = lastMsg != null &&
        lastMsg['sender'] != widget.username &&
        lastMsg['read'] != true;
    final username = chat['username'] as String;
    final initial = username.isNotEmpty ? username[0].toUpperCase() : '?';

    return GestureDetector(
      onTap: () {
        setState(() {
          _selectedUser = chat['username'];
          _privateReplyTo = null;
        });
        _loadPrivateMessages(chat['username']);
      },
      child: Container(
        margin: const EdgeInsets.only(bottom: 8),
        child: _SoftPanel(
          C: C,
          padding: const EdgeInsets.all(12),
          accent: isUnread
              ? C.accentHi.withOpacity(0.6)
              : C.textSub,
          child: Row(
            children: [
              Stack(
                alignment: Alignment.center,
                children: [
                  Container(
                    width: 46,
                    height: 46,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      gradient: isComic
                          ? null
                          : LinearGradient(
                              colors: [C.accent, C.primaryLo]),
                      color: isComic ? C.primaryHi : null,
                      border: Border.all(
                        color: isComic
                            ? Colors.black
                            : (isUnread
                                ? C.accentHi
                                : C.accent.withOpacity(0.5)),
                        width: isComic ? 3 : 1.5,
                      ),
                    ),
                    child: Center(
                      child: Text(
                        initial,
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: isComic ? 20 : 18,
                          fontWeight: FontWeight.w900,
                          fontFamily:
                              isComic ? 'Bangers' : 'Orbitron',
                        ),
                      ),
                    ),
                  ),
                  if (!isComic)
                    Positioned(
                      bottom: 0,
                      right: 0,
                      child: _Led(
                        color: isUnread ? C.accentHi : C.primaryHi,
                        size: 9,
                      ),
                    ),
                ],
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Expanded(
                          child: Text(
                            profile['name'] ?? chat['username'],
                            style: TextStyle(
                              color: isComic ? Colors.black : C.text,
                              fontWeight: FontWeight.w900,
                              fontSize: isComic ? 15 : 12,
                              fontFamily:
                                  isComic ? 'Bangers' : 'Orbitron',
                              letterSpacing: isComic ? 1 : 0.5,
                            ),
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                          ),
                        ),
                        if (isUnread)
                          Container(
                            width: 18,
                            height: 18,
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              gradient: isComic
                                  ? null
                                  : LinearGradient(
                                      colors: [C.accentHi, C.accent]),
                              color: isComic ? C.accent : null,
                              border: isComic
                                  ? Border.all(
                                      color: Colors.black, width: 2)
                                  : null,
                            ),
                            child: const Center(
                              child: Text(
                                '!',
                                style: TextStyle(
                                  color: Colors.white,
                                  fontSize: 11,
                                  fontWeight: FontWeight.w900,
                                ),
                              ),
                            ),
                          ),
                      ],
                    ),
                    if (lastMsg != null) ...[
                      const SizedBox(height: 3),
                      Text(
                        '${lastMsg['sender'] == widget.username ? "You: " : ""}${lastMsg['message'] ?? ''}',
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(
                          color: isComic
                              ? Colors.black
                                  .withOpacity(isUnread ? 0.8 : 0.5)
                              : C.text.withOpacity(
                                  isUnread ? 0.75 : 0.5),
                          fontSize: 10,
                          fontFamily:
                              isComic ? 'ComicNeue' : 'ShareTechMono',
                          fontWeight: isUnread
                              ? FontWeight.w700
                              : FontWeight.w500,
                        ),
                      ),
                    ],
                  ],
                ),
              ),
              if (lastMsg != null) ...[
                const SizedBox(width: 8),
                Text(
                  _formatTime(lastMsg['timestamp']),
                  style: TextStyle(
                    color: isComic
                        ? Colors.black.withOpacity(0.5)
                        : C.text.withOpacity(0.4),
                    fontSize: 8,
                    fontFamily:
                        isComic ? 'ComicNeue' : 'ShareTechMono',
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildChatHeader(AppPalette C, bool isComic) {
    final profile = _privateChats.firstWhere(
      (c) => c['username'] == _selectedUser,
      orElse: () => ({'profile': {}}),
    )['profile'] ??
        {};

    final initial = _selectedUser!.isNotEmpty
        ? _selectedUser![0].toUpperCase()
        : '?';

    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 14, vertical: 4),
      child: _SoftPanel(
        C: C,
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
        accent: C.textSub,
        child: Row(
          children: [
            _MetalIconButton(
              C: C,
              icon: Icons.arrow_back_rounded,
              size: 30,
              onTap: () => setState(() {
                _selectedUser = null;
                _privateReplyTo = null;
              }),
            ),
            const SizedBox(width: 8),
            Stack(
              alignment: Alignment.center,
              children: [
                Container(
                  width: 36,
                  height: 36,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    gradient: isComic
                        ? null
                        : LinearGradient(
                            colors: [C.accent, C.primaryLo]),
                    color: isComic ? C.primaryHi : null,
                    border: Border.all(
                        color: isComic
                            ? Colors.black
                            : C.accentHi.withOpacity(0.6),
                        width: isComic ? 3 : 1),
                  ),
                  child: Center(
                    child: Text(
                      initial,
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: isComic ? 18 : 14,
                        fontWeight: FontWeight.w900,
                        fontFamily: isComic ? 'Bangers' : 'Orbitron',
                      ),
                    ),
                  ),
                ),
                if (!isComic)
                  Positioned(
                    bottom: 0,
                    right: 0,
                    child: _Led(color: C.primaryHi, size: 8),
                  ),
              ],
            ),
            const SizedBox(width: 10),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    profile['name'] ?? _selectedUser!,
                    style: TextStyle(
                      color: isComic ? Colors.black : C.text,
                      fontWeight: FontWeight.w900,
                      fontSize: isComic ? 15 : 12,
                      fontFamily: isComic ? 'Bangers' : 'Orbitron',
                      letterSpacing: isComic ? 1 : 0.5,
                    ),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                  if (profile['bio'] != null &&
                      profile['bio'].toString().isNotEmpty) ...[
                    const SizedBox(height: 2),
                    Text(
                      profile['bio'],
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(
                        color: isComic
                            ? Colors.black.withOpacity(0.5)
                            : C.text.withOpacity(0.5),
                        fontSize: 9,
                        fontFamily:
                            isComic ? 'ComicNeue' : 'ShareTechMono',
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                  ],
                ],
              ),
            ),
            Container(
              padding:
                  const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(isComic ? 6 : 4),
                color: isComic ? C.primaryHi : C.primaryLo,
                border: Border.all(
                    color: isComic ? Colors.black : C.primaryHi.withOpacity(0.6),
                    width: isComic ? 2.5 : 1),
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  _Led(color: isComic ? Colors.white : C.primaryHi, size: 5),
                  const SizedBox(width: 5),
                  Text(
                    'E2EE',
                    style: TextStyle(
                      color: isComic ? Colors.white : C.primaryHi,
                      fontSize: isComic ? 10 : 8,
                      fontWeight: FontWeight.w900,
                      fontFamily: isComic ? 'Bangers' : 'Orbitron',
                      letterSpacing: 1,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildPrivateMessageBubble(
      AppPalette C, bool isComic, dynamic msg) {
    final isMe = msg['fromMe'] == true;
    final replyTo = msg['replyTo'];

    return GestureDetector(
      onLongPress: () {
        setState(() {
          _privateReplyTo = {
            'id': msg['id'],
            'sender': msg['sender'],
            'message': msg['message'],
          };
        });
      },
      child: Container(
        margin: EdgeInsets.only(
          left: isMe ? 50 : 0,
          right: isMe ? 0 : 50,
          top: 6,
          bottom: 6,
        ),
        child: Column(
          crossAxisAlignment:
              isMe ? CrossAxisAlignment.end : CrossAxisAlignment.start,
          children: [
            if (replyTo != null)
              _buildReplyBubble(C, isComic, replyTo, isMe),
            _buildBubbleContent(C, isComic, msg['message'] ?? '', isMe),
            Padding(
              padding: const EdgeInsets.only(top: 4, left: 4, right: 4),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Container(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 4, vertical: 2),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(isComic ? 5 : 3),
                      color: isComic ? C.primaryHi : C.primaryLo,
                      border: Border.all(
                          color: isComic
                              ? Colors.black
                              : C.primaryHi.withOpacity(0.4),
                          width: isComic ? 1.5 : 0.8),
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(Icons.lock_outline_rounded,
                            color: isComic ? Colors.white : C.primaryHi,
                            size: isComic ? 9 : 7),
                        const SizedBox(width: 2),
                        Text(
                          'E2EE',
                          style: TextStyle(
                            color: isComic ? Colors.white : C.primaryHi,
                            fontSize: isComic ? 8 : 6,
                            fontWeight: FontWeight.w900,
                            fontFamily:
                                isComic ? 'Bangers' : 'Orbitron',
                            letterSpacing: 0.5,
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(width: 4),
                  Text(
                    _formatTime(msg['timestamp']),
                    style: TextStyle(
                      color: isComic
                          ? Colors.black.withOpacity(0.5)
                          : C.text.withOpacity(0.4),
                      fontSize: 9,
                      fontFamily: isComic ? 'ComicNeue' : 'ShareTechMono',
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                  if (isMe && msg['read'] == true)
                    Padding(
                      padding: const EdgeInsets.only(left: 4),
                      child: Icon(
                        Icons.done_all_rounded,
                        color: isComic ? Colors.black : C.primaryHi,
                        size: 10,
                      ),
                    ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildBubbleContent(
      AppPalette C, bool isComic, String message, bool isMe) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 9),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(isComic ? 14 : 12),
        gradient: isComic
            ? null
            : (isMe
                ? LinearGradient(
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                    colors: [C.accentHi, C.accent])
                : LinearGradient(
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                    colors: [C.bg, C.bgDark])),
        color: isComic ? (isMe ? C.primaryHi : C.bgDark) : null,
        border: Border.all(
          color: isComic
              ? Colors.black
              : (isMe ? C.accentHi.withOpacity(0.6) : C.textSub),
          width: isComic ? 3 : 1,
        ),
        boxShadow: isComic
            ? const [
                BoxShadow(
                  color: Colors.black,
                  offset: Offset(4, 4),
                  blurRadius: 0,
                ),
              ]
            : [
                BoxShadow(
                  color: isMe
                      ? C.accentHi.withOpacity(0.3)
                      : Colors.black.withOpacity(0.4),
                  offset: const Offset(0, 2),
                  blurRadius: 5,
                ),
              ],
      ),
      child: Text(
        message,
        style: TextStyle(
          color: isComic
              ? Colors.white
              : (isMe ? Colors.white : C.text),
          fontSize: isComic ? 14 : 12,
          fontFamily: isComic ? 'ComicNeue' : 'ShareTechMono',
          fontWeight: FontWeight.w700,
          height: 1.4,
          shadows: isMe && !isComic
              ? const [
                  Shadow(
                    color: Colors.black38,
                    offset: Offset(0, 1),
                    blurRadius: 2,
                  ),
                ]
              : null,
        ),
      ),
    );
  }

  Widget _buildReplyBubble(
      AppPalette C, bool isComic, Map replyTo, bool isMe) {
    return Container(
      margin: const EdgeInsets.only(bottom: 4, left: 4, right: 4),
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 6),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(isComic ? 8 : 6),
        color: isComic ? Colors.white : Colors.black.withOpacity(0.4),
        border: isComic
            ? Border.all(color: Colors.black, width: 2)
            : Border(
                left: BorderSide(
                  color: isMe ? C.accentHi : C.accent,
                  width: 3,
                ),
              ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(
                Icons.reply_rounded,
                color: isComic
                    ? Colors.black
                    : (isMe ? C.accentHi : C.accent),
                size: 10,
              ),
              const SizedBox(width: 4),
              Text(
                '@${replyTo['sender']}',
                style: TextStyle(
                  color: isComic
                      ? Colors.black
                      : (isMe ? C.accentHi : C.accent),
                  fontSize: isComic ? 10 : 8,
                  fontWeight: FontWeight.w900,
                  fontFamily: isComic ? 'Bangers' : 'Orbitron',
                  letterSpacing: 0.5,
                ),
              ),
            ],
          ),
          const SizedBox(height: 2),
          Text(
            replyTo['message'] ?? '',
            maxLines: 2,
            overflow: TextOverflow.ellipsis,
            style: TextStyle(
              color: isComic
                  ? Colors.black.withOpacity(0.7)
                  : C.text.withOpacity(0.6),
              fontSize: isComic ? 11 : 9,
              fontFamily: isComic ? 'ComicNeue' : 'ShareTechMono',
              fontWeight: FontWeight.w700,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildReplyPreviewBar(AppPalette C, bool isComic,
      {required bool isGlobal}) {
    final replyData = isGlobal ? _globalReplyTo : _privateReplyTo;
    if (replyData == null) return const SizedBox();

    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 14, vertical: 4),
      child: _SoftPanel(
        C: C,
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
        accent: C.accent,
        child: Row(
          children: [
            Icon(Icons.reply_rounded,
                color: isComic ? Colors.black : C.accent, size: 14),
            const SizedBox(width: 8),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'REPLYING TO @${replyData['sender']}'.toUpperCase(),
                    style: TextStyle(
                      color: isComic ? Colors.black : C.accent,
                      fontSize: isComic ? 11 : 8,
                      fontFamily: isComic ? 'Bangers' : 'Orbitron',
                      fontWeight: FontWeight.w900,
                      letterSpacing: 1,
                    ),
                  ),
                  const SizedBox(height: 2),
                  Text(
                    replyData['message'] ?? '',
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(
                      color: isComic
                          ? Colors.black.withOpacity(0.6)
                          : C.text.withOpacity(0.6),
                      fontSize: isComic ? 11 : 10,
                      fontFamily: isComic ? 'ComicNeue' : 'ShareTechMono',
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                ],
              ),
            ),
            GestureDetector(
              onTap: () => setState(() {
                if (isGlobal) {
                  _globalReplyTo = null;
                } else {
                  _privateReplyTo = null;
                }
              }),
              child: Container(
                padding: const EdgeInsets.all(4),
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: isComic ? C.accent : C.bgDark,
                  border: Border.all(
                      color: isComic ? Colors.black : C.textSub,
                      width: isComic ? 2 : 1),
                ),
                child: Icon(
                  Icons.close_rounded,
                  color: isComic ? Colors.white : C.accent,
                  size: 12,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildInputBar(AppPalette C, bool isComic, {
    required TextEditingController controller,
    required VoidCallback onSend,
    required String hint,
    required bool isGlobal,
  }) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
      child: _SoftPanel(
        C: C,
        padding: const EdgeInsets.all(4),
        accent: C.textSub,
        child: Row(
          children: [
            Expanded(
              child: _SoftInset(
                C: C,
                padding: const EdgeInsets.symmetric(horizontal: 12),
                child: TextField(
                  controller: controller,
                  style: TextStyle(
                    color: isComic ? Colors.black : C.text,
                    fontFamily: isComic ? 'ComicNeue' : 'ShareTechMono',
                    fontSize: 13,
                    fontWeight: FontWeight.w700,
                  ),
                  cursorColor: isComic ? Colors.black : C.accent,
                  cursorWidth: 2,
                  decoration: InputDecoration(
                    hintText: hint,
                    hintStyle: TextStyle(
                      color: isComic
                          ? Colors.black.withOpacity(0.4)
                          : C.text.withOpacity(0.3),
                      fontFamily:
                          isComic ? 'ComicNeue' : 'ShareTechMono',
                      fontSize: 12,
                    ),
                    border: InputBorder.none,
                    contentPadding:
                        const EdgeInsets.symmetric(vertical: 12),
                  ),
                  onSubmitted: (_) => onSend(),
                ),
              ),
            ),
            const SizedBox(width: 8),
            _SendButton(
              C: C,
              onTap: onSend,
              color: isGlobal ? C.accent : C.primaryHi,
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildEmptyState(
      AppPalette C, bool isComic, String title, String message) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: _SoftPanel(
          C: C,
          padding:
              const EdgeInsets.symmetric(vertical: 32, horizontal: 24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                width: 72,
                height: 72,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: isComic
                      ? null
                      : LinearGradient(
                          colors: [C.accent, C.primaryLo]),
                  color: isComic ? C.primaryHi : null,
                  border: Border.all(
                      color: isComic
                          ? Colors.black
                          : C.accentHi.withOpacity(0.6),
                      width: isComic ? 4 : 1.5),
                ),
                child: Icon(
                  Icons.chat_bubble_outline_rounded,
                  color: Colors.white,
                  size: 30,
                ),
              ),
              const SizedBox(height: 18),
              Text(
                title.toUpperCase(),
                style: TextStyle(
                  color: isComic ? Colors.black : C.accent,
                  fontSize: isComic ? 16 : 12,
                  fontWeight: FontWeight.w900,
                  fontFamily: isComic ? 'Bangers' : 'Orbitron',
                  letterSpacing: isComic ? 1.5 : 2,
                ),
              ),
              const SizedBox(height: 10),
              Text(
                message,
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: isComic
                      ? Colors.black.withOpacity(0.6)
                      : C.text.withOpacity(0.6),
                  fontSize: isComic ? 12 : 11,
                  fontFamily: isComic ? 'ComicNeue' : 'ShareTechMono',
                  fontWeight: FontWeight.w700,
                  height: 1.5,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════
// SEND BUTTON
// ═══════════════════════════════════════════════════════════
class _SendButton extends StatefulWidget {
  final AppPalette C;
  final VoidCallback onTap;
  final Color color;
  const _SendButton({
    required this.C,
    required this.onTap,
    required this.color,
  });

  @override
  State<_SendButton> createState() => _SendButtonState();
}

class _SendButtonState extends State<_SendButton> {
  bool _pressed = false;

  @override
  Widget build(BuildContext context) {
    final C = widget.C;
    final isComic = AppTheme.currentStyle.value == ThemeStyle.comic3d;
    return GestureDetector(
      onTapDown: (_) => setState(() => _pressed = true),
      onTapUp: (_) {
        setState(() => _pressed = false);
        widget.onTap();
      },
      onTapCancel: () => setState(() => _pressed = false),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 80),
        width: 44,
        height: 44,
        transform: isComic
            ? Matrix4.translationValues(_pressed ? 3 : 0,
                _pressed ? 3 : 0, 0)
            : null,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          gradient: isComic
              ? null
              : LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [
                    widget.color.withOpacity(0.9),
                    widget.color,
                    widget.color.withOpacity(0.7),
                  ]),
          color: isComic ? widget.color : null,
          border: Border.all(
            color: isComic
                ? Colors.black
                : widget.color.withOpacity(0.9),
            width: isComic ? 3.5 : 1.5,
          ),
          boxShadow: isComic
              ? (_pressed
                  ? []
                  : const [
                      BoxShadow(
                        color: Colors.black,
                        offset: Offset(3, 3),
                        blurRadius: 0,
                      ),
                    ])
              : [
                  BoxShadow(
                    color: widget.color.withOpacity(0.4),
                    blurRadius: 10,
                  ),
                ],
        ),
        child: const Icon(
          Icons.send_rounded,
          color: Colors.white,
          size: 18,
          shadows: [
            Shadow(
              color: Colors.black38,
              offset: Offset(0, 1),
              blurRadius: 2,
            ),
          ],
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════
// SEARCH BAR BUTTON
// ═══════════════════════════════════════════════════════════
class _SearchBarButton extends StatefulWidget {
  final AppPalette C;
  final VoidCallback onTap;
  const _SearchBarButton({required this.C, required this.onTap});

  @override
  State<_SearchBarButton> createState() => _SearchBarButtonState();
}

class _SearchBarButtonState extends State<_SearchBarButton> {
  bool _pressed = false;

  @override
  Widget build(BuildContext context) {
    final C = widget.C;
    final isComic = AppTheme.currentStyle.value == ThemeStyle.comic3d;
    return GestureDetector(
      onTapDown: (_) => setState(() => _pressed = true),
      onTapUp: (_) {
        setState(() => _pressed = false);
        widget.onTap();
      },
      onTapCancel: () => setState(() => _pressed = false),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 80),
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
        transform: isComic
            ? Matrix4.translationValues(_pressed ? 3 : 0,
                _pressed ? 3 : 0, 0)
            : null,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(isComic ? 14 : 10),
          gradient: isComic
              ? null
              : LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [C.bg, C.bgDark]),
          color: isComic ? C.bgDark : null,
          border: Border.all(
              color: isComic ? Colors.black : C.textSub,
              width: isComic ? 4 : 1),
          boxShadow: isComic
              ? const [
                  BoxShadow(
                    color: Colors.black,
                    offset: Offset(4, 4),
                    blurRadius: 0,
                  ),
                ]
              : [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.5),
                    offset: const Offset(0, 3),
                    blurRadius: 5,
                  ),
                ],
        ),
        child: Row(
          children: [
            Icon(Icons.search_rounded,
                color: isComic ? Colors.black : C.accent, size: 16),
            const SizedBox(width: 10),
            Text(
              'CARI USER BARU...',
              style: TextStyle(
                color: isComic
                    ? Colors.black.withOpacity(0.6)
                    : C.text.withOpacity(0.5),
                fontFamily: isComic ? 'Bangers' : 'Orbitron',
                fontWeight: FontWeight.w900,
                fontSize: isComic ? 14 : 10,
                letterSpacing: 1.5,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════
// METAL ICON BUTTON
// ═══════════════════════════════════════════════════════════
class _MetalIconButton extends StatefulWidget {
  final AppPalette C;
  final IconData icon;
  final VoidCallback onTap;
  final double size;
  const _MetalIconButton({
    required this.C,
    required this.icon,
    required this.onTap,
    this.size = 34,
  });

  @override
  State<_MetalIconButton> createState() => _MetalIconButtonState();
}

class _MetalIconButtonState extends State<_MetalIconButton> {
  bool _pressed = false;

  @override
  Widget build(BuildContext context) {
    final C = widget.C;
    final isComic = AppTheme.currentStyle.value == ThemeStyle.comic3d;
    return GestureDetector(
      onTapDown: (_) => setState(() => _pressed = true),
      onTapUp: (_) {
        setState(() => _pressed = false);
        widget.onTap();
      },
      onTapCancel: () => setState(() => _pressed = false),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 80),
        width: widget.size,
        height: widget.size,
        transform: isComic
            ? Matrix4.translationValues(_pressed ? 2 : 0,
                _pressed ? 2 : 0, 0)
            : null,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          gradient: isComic
              ? null
              : LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [C.textSub, C.bgDark]),
          color: isComic ? C.accent : null,
          border: Border.all(
            color: isComic ? Colors.black : C.text.withOpacity(0.5),
            width: isComic ? 3 : 1,
          ),
          boxShadow: isComic
              ? (_pressed
                  ? []
                  : const [
                      BoxShadow(
                        color: Colors.black,
                        offset: Offset(3, 3),
                        blurRadius: 0,
                      ),
                    ])
              : [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.6),
                    offset: const Offset(0, 2),
                    blurRadius: 3,
                  ),
                ],
        ),
        child: Icon(
          widget.icon,
          color: isComic ? Colors.white : C.accent,
          size: widget.size * 0.42,
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════
// SEARCH USER SHEET
// ═══════════════════════════════════════════════════════════
class _SearchUserSheet extends StatefulWidget {
  final String sessionKey;
  final String currentUsername;
  final Function(Map<String, dynamic>) onSelectUser;

  const _SearchUserSheet({
    required this.sessionKey,
    required this.currentUsername,
    required this.onSelectUser,
  });

  @override
  State<_SearchUserSheet> createState() => _SearchUserSheetState();
}

class _SearchUserSheetState extends State<_SearchUserSheet> {
  final TextEditingController _searchCtrl = TextEditingController();
  List<dynamic> _results = [];
  bool _loading = false;
  Timer? _debounce;

  @override
  void dispose() {
    _debounce?.cancel();
    _searchCtrl.dispose();
    super.dispose();
  }

  void _search(String query) {
    _debounce?.cancel();
    _debounce = Timer(const Duration(milliseconds: 500), () async {
      if (query.length < 2) {
        if (mounted) setState(() => _results = []);
        return;
      }
      if (mounted) setState(() => _loading = true);
      try {
        final prefs = await SharedPreferences.getInstance();
        final sessionKey =
            prefs.getString('session_key') ?? widget.sessionKey;
        final res = await http.get(Uri.parse(
            '$baseUrl/chat/search-users?key=$sessionKey&q=$query'));
        if (res.statusCode == 200) {
          final data = jsonDecode(res.body);
          if (data['valid'] == true && mounted) {
            setState(() => _results = data['users'] ?? []);
          }
        }
      } catch (_) {}
      if (mounted) setState(() => _loading = false);
    });
  }

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<AppPalette>(
      valueListenable: AppTheme.current,
      builder: (context, C, _) {
        final isComic = AppTheme.currentStyle.value == ThemeStyle.comic3d;
        return Container(
          height: MediaQuery.of(context).size.height * 0.75,
          decoration: BoxDecoration(
            borderRadius: const BorderRadius.vertical(
                top: Radius.circular(20)),
            gradient: isComic
                ? null
                : LinearGradient(
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                    colors: [C.bg, C.bgDark, C.bgDeep]),
            color: isComic ? C.bg : null,
            border: isComic
                ? Border.all(color: Colors.black, width: 4)
                : null,
          ),
          child: SafeArea(
            top: false,
            child: Column(
              children: [
                Container(
                  margin: const EdgeInsets.only(top: 10),
                  width: 50,
                  height: isComic ? 5 : 4,
                  decoration: BoxDecoration(
                    color: isComic ? Colors.black : C.textSub,
                    borderRadius: BorderRadius.circular(3),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.fromLTRB(14, 14, 14, 10),
                  child: _SoftPanel(
                    C: C,
                    padding: const EdgeInsets.all(10),
                    accent: C.textSub,
                    child: Row(
                      children: [
                        Container(
                          padding: const EdgeInsets.all(7),
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            gradient: isComic
                                ? null
                                : LinearGradient(
                                    colors: [C.accentHi, C.accent]),
                            color: isComic ? C.primaryHi : null,
                            border: Border.all(
                                color: isComic
                                    ? Colors.black
                                    : C.accentHi.withOpacity(0.6),
                                width: isComic ? 2.5 : 1),
                          ),
                          child: const Icon(Icons.search_rounded,
                              color: Colors.white, size: 14),
                        ),
                        const SizedBox(width: 10),
                        Expanded(
                          child: Text(
                            'CARI USER',
                            style: TextStyle(
                              color: isComic ? Colors.black : C.accent,
                              fontSize: isComic ? 16 : 12,
                              fontWeight: FontWeight.w900,
                              fontFamily:
                                  isComic ? 'Bangers' : 'Orbitron',
                              letterSpacing: isComic ? 1.5 : 2,
                            ),
                          ),
                        ),
                        _MetalIconButton(
                          C: C,
                          icon: Icons.close_rounded,
                          size: 30,
                          onTap: () => Navigator.pop(context),
                        ),
                      ],
                    ),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 14),
                  child: _SoftInset(
                    C: C,
                    padding: const EdgeInsets.symmetric(horizontal: 12),
                    child: TextField(
                      controller: _searchCtrl,
                      onChanged: _search,
                      style: TextStyle(
                        color: isComic ? Colors.black : C.text,
                        fontFamily:
                            isComic ? 'ComicNeue' : 'ShareTechMono',
                        fontSize: 13,
                        fontWeight: FontWeight.w700,
                      ),
                      cursorColor: isComic ? Colors.black : C.accent,
                      cursorWidth: 2,
                      decoration: InputDecoration(
                        hintText: 'Masukkan username...',
                        hintStyle: TextStyle(
                          color: isComic
                              ? Colors.black.withOpacity(0.4)
                              : C.text.withOpacity(0.3),
                          fontFamily:
                              isComic ? 'ComicNeue' : 'ShareTechMono',
                          fontSize: 12,
                        ),
                        prefixIcon: Icon(
                          Icons.person_search_rounded,
                          color: isComic ? Colors.black : C.accent,
                          size: 16,
                        ),
                        border: InputBorder.none,
                        contentPadding:
                            const EdgeInsets.symmetric(vertical: 14),
                      ),
                    ),
                  ),
                ),
                const SizedBox(height: 10),
                Expanded(
                  child: _loading
                      ? Center(
                          child: CircularProgressIndicator(
                              color:
                                  isComic ? Colors.black : C.accent,
                              strokeWidth: 2))
                      : _results.isEmpty
                          ? _buildEmptyResults(C, isComic)
                          : ListView.builder(
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 14, vertical: 4),
                              itemCount: _results.length,
                              itemBuilder: (ctx, i) =>
                                  _buildUserItem(C, isComic, _results[i]),
                            ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _buildEmptyResults(AppPalette C, bool isComic) {
    return Center(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            width: 60,
            height: 60,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: isComic
                  ? null
                  : LinearGradient(
                      colors: [C.bg, C.bgDark]),
              color: isComic ? C.primaryHi : null,
              border: Border.all(
                  color: isComic ? Colors.black : C.textSub,
                  width: isComic ? 4 : 1.5),
            ),
            child: Icon(
              Icons.person_search_rounded,
              color: isComic ? Colors.white : C.textSub,
              size: 26,
            ),
          ),
          const SizedBox(height: 14),
          Text(
            'TIDAK ADA USER',
            style: TextStyle(
              color: isComic ? Colors.black : C.accent,
              fontSize: isComic ? 14 : 11,
              fontFamily: isComic ? 'Bangers' : 'Orbitron',
              fontWeight: FontWeight.w900,
              letterSpacing: 2,
            ),
          ),
          const SizedBox(height: 6),
          Text(
            'Cari username lain',
            style: TextStyle(
              color: isComic
                  ? Colors.black.withOpacity(0.5)
                  : C.text.withOpacity(0.5),
              fontSize: isComic ? 11 : 10,
              fontFamily: isComic ? 'ComicNeue' : 'ShareTechMono',
              fontWeight: FontWeight.w700,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildUserItem(
      AppPalette C, bool isComic, dynamic user) {
    final profile = user['profile'] ?? {};
    final username = user['username'] as String;
    final initial =
        username.isNotEmpty ? username[0].toUpperCase() : '?';

    return GestureDetector(
      onTap: () => widget.onSelectUser(user),
      child: Container(
        margin: const EdgeInsets.only(bottom: 8),
        child: _SoftPanel(
          C: C,
          padding: const EdgeInsets.all(12),
          accent: C.textSub,
          child: Row(
            children: [
              Container(
                width: 42,
                height: 42,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: isComic
                      ? null
                      : LinearGradient(
                          colors: [C.accent, C.primaryLo]),
                  color: isComic ? C.primaryHi : null,
                  border: Border.all(
                      color: isComic
                          ? Colors.black
                          : C.accentHi.withOpacity(0.6),
                      width: isComic ? 3 : 1.5),
                ),
                child: Center(
                  child: Text(
                    initial,
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: isComic ? 18 : 16,
                      fontWeight: FontWeight.w900,
                      fontFamily: isComic ? 'Bangers' : 'Orbitron',
                    ),
                  ),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      profile['name'] ?? username,
                      style: TextStyle(
                        color: isComic ? Colors.black : C.text,
                        fontWeight: FontWeight.w900,
                        fontSize: isComic ? 15 : 12,
                        fontFamily: isComic ? 'Bangers' : 'Orbitron',
                        letterSpacing: isComic ? 1 : 0.5,
                      ),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                    if (profile['bio'] != null &&
                        profile['bio'].toString().isNotEmpty) ...[
                      const SizedBox(height: 2),
                      Text(
                        profile['bio'],
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(
                          color: isComic
                              ? Colors.black.withOpacity(0.5)
                              : C.text.withOpacity(0.5),
                          fontSize: 9,
                          fontFamily:
                              isComic ? 'ComicNeue' : 'ShareTechMono',
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                    ],
                  ],
                ),
              ),
              Container(
                padding: const EdgeInsets.symmetric(
                    horizontal: 8, vertical: 3),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(isComic ? 6 : 4),
                  color: isComic ? C.accent : C.primaryLo.withOpacity(0.4),
                  border: Border.all(
                      color: isComic
                          ? Colors.black
                          : C.accent.withOpacity(0.6),
                      width: isComic ? 2 : 1),
                ),
                child: Text(
                  (user['role'] ?? 'MEMBER').toString().toUpperCase(),
                  style: TextStyle(
                    color: isComic ? Colors.white : C.accent,
                    fontSize: isComic ? 10 : 7,
                    fontWeight: FontWeight.w900,
                    fontFamily: isComic ? 'Bangers' : 'Orbitron',
                    letterSpacing: 1,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════
// COMIC HALFTONE PAINTER
// ═══════════════════════════════════════════════════════════
class _ComicHalftonePainter extends CustomPainter {
  final Color color;
  const _ComicHalftonePainter({required this.color});

  @override
  void paint(Canvas canvas, Size size) {
    const spacing = 22.0;
    final paint = Paint()..color = color;
    for (double x = 0; x < size.width + spacing; x += spacing) {
      for (double y = 0; y < size.height + spacing; y += spacing) {
        canvas.drawCircle(Offset(x, y), 2.5, paint);
      }
    }
  }

  @override
  bool shouldRepaint(_ComicHalftonePainter old) => old.color != color;
}