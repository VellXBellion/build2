import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'app_theme.dart';
import 'api_config.dart';

class ChangePasswordPage extends StatefulWidget {
  final String username;
  final String sessionKey;

  const ChangePasswordPage({
    super.key,
    required this.username,
    required this.sessionKey,
  });

  @override
  State<ChangePasswordPage> createState() => _ChangePasswordPageState();
}

class _ChangePasswordPageState extends State<ChangePasswordPage> {
  final oldPassCtrl     = TextEditingController();
  final newPassCtrl     = TextEditingController();
  final confirmPassCtrl = TextEditingController();

  bool _isLoading       = false;
  bool _obscureOld      = true;
  bool _obscureNew      = true;
  bool _obscureConfirm  = true;

  @override
  void dispose() {
    oldPassCtrl.dispose();
    newPassCtrl.dispose();
    confirmPassCtrl.dispose();
    super.dispose();
  }

  Future<void> _changePassword(AppPalette C) async {
    HapticFeedback.lightImpact();
    final oldPass     = oldPassCtrl.text.trim();
    final newPass     = newPassCtrl.text.trim();
    final confirmPass = confirmPassCtrl.text.trim();

    if (oldPass.isEmpty || newPass.isEmpty || confirmPass.isEmpty) {
      _showMessage(C, "Semua field harus diisi.");
      return;
    }
    if (newPass != confirmPass) {
      _showMessage(C, "Password baru tidak cocok dengan konfirmasi.");
      return;
    }
    if (newPass.length < 6) {
      _showMessage(C, "Password minimal 6 karakter.");
      return;
    }

    setState(() => _isLoading = true);
    try {
      final res = await http.post(
        Uri.parse("$baseUrl/changepass"),
        body: {
          "username": widget.username,
          "oldPass": oldPass,
          "newPass": newPass,
          "sessionKey": widget.sessionKey,
        },
      ).timeout(const Duration(seconds: 10));

      final data = jsonDecode(res.body);
      if (data['success'] == true) {
        _showMessage(C, "Password berhasil diubah!", isSuccess: true);
        oldPassCtrl.clear();
        newPassCtrl.clear();
        confirmPassCtrl.clear();
      } else {
        _showMessage(C, data['message'] ?? "Gagal mengubah password");
      }
    } catch (e) {
      _showMessage(C, "Koneksi error. Periksa jaringan.");
    }
    if (mounted) setState(() => _isLoading = false);
  }

  void _showMessage(AppPalette C, String msg, {bool isSuccess = false}) {
    HapticFeedback.mediumImpact();
    final color = isSuccess ? C.primaryHi : C.accent;
    final icon = isSuccess
        ? Icons.check_circle_rounded
        : Icons.warning_amber_rounded;

    showDialog(
      context: context,
      barrierColor: Colors.black.withOpacity(0.85),
      builder: (_) => Dialog(
        backgroundColor: Colors.transparent,
        insetPadding: const EdgeInsets.symmetric(horizontal: 24),
        child: _SoftPanel(
          C: C,
          padding: const EdgeInsets.all(20),
          accent: color.withOpacity(0.6),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: color.withOpacity(0.15),
                  border: Border.all(
                      color: color.withOpacity(0.6), width: 1.5),
                  boxShadow: [
                    BoxShadow(
                      color: color.withOpacity(0.3),
                      blurRadius: 12,
                      spreadRadius: 0,
                    ),
                  ],
                ),
                child: Icon(icon, color: color, size: 26),
              ),
              const SizedBox(height: 14),
              Text(
                isSuccess ? 'SUKSES' : 'PERINGATAN',
                style: TextStyle(
                  color: color,
                  fontFamily: 'Orbitron',
                  fontWeight: FontWeight.w900,
                  fontSize: 13,
                  letterSpacing: 2,
                  shadows: const [
                    Shadow(
                      color: Colors.black,
                      offset: Offset(0, 1),
                      blurRadius: 2,
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 10),
              Text(
                msg,
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: C.text.withOpacity(0.7),
                  fontFamily: 'ShareTechMono',
                  fontWeight: FontWeight.w700,
                  fontSize: 11,
                  height: 1.6,
                ),
              ),
              const SizedBox(height: 20),
              _MetalButton(
                C: C,
                label: 'OK',
                color: color,
                height: 42,
                onTap: () => Navigator.pop(context),
              ),
            ],
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<AppPalette>(
      valueListenable: AppTheme.current,
      builder: (context, C, _) {
        return Scaffold(
          backgroundColor: C.bgDark,
          body: Container(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [C.bg, C.bgDark, C.bgDeep],
              ),
            ),
            child: SafeArea(
              child: Column(
                children: [
                  _buildTopBar(C),
                  Expanded(
                    child: SingleChildScrollView(
                      physics: const BouncingScrollPhysics(),
                      padding: const EdgeInsets.fromLTRB(14, 8, 14, 20),
                      child: Column(
                        children: [
                          const SizedBox(height: 8),
                          _buildLockIcon(C),
                          const SizedBox(height: 16),
                          Text(
                            'SECURITY UPDATE',
                            style: TextStyle(
                              color: C.accent,
                              fontFamily: 'Orbitron',
                              fontWeight: FontWeight.w900,
                              fontSize: 16,
                              letterSpacing: 3,
                              shadows: [
                                const Shadow(
                                  color: Colors.black,
                                  offset: Offset(0, 1),
                                  blurRadius: 2,
                                ),
                                Shadow(
                                  color: C.primaryHi,
                                  offset: const Offset(0, 0),
                                  blurRadius: 8,
                                ),
                              ],
                            ),
                          ),
                          const SizedBox(height: 8),
                          Container(
                            width: 60,
                            height: 1,
                            decoration: BoxDecoration(
                              gradient: LinearGradient(
                                colors: [
                                  Colors.transparent,
                                  C.primaryHi,
                                  Colors.transparent,
                                ],
                              ),
                            ),
                          ),
                          const SizedBox(height: 10),
                          Text(
                            'Masukkan password lama dan baru kamu.',
                            textAlign: TextAlign.center,
                            style: TextStyle(
                              color: C.text.withOpacity(0.55),
                              fontFamily: 'ShareTechMono',
                              fontWeight: FontWeight.w700,
                              fontSize: 10,
                              letterSpacing: 0.5,
                            ),
                          ),
                          const SizedBox(height: 24),
                          _buildSectionHeader(C, 'CREDENTIALS'),
                          const SizedBox(height: 10),
                          _SoftPanel(
                            C: C,
                            padding: const EdgeInsets.all(14),
                            accent: C.primaryHi.withOpacity(0.4),
                            child: Column(
                              children: [
                                _buildInput(C,
                                  controller: oldPassCtrl,
                                  label: 'OLD PASSWORD',
                                  icon: Icons.lock_outline_rounded,
                                  obscure: _obscureOld,
                                  onToggle: () =>
                                      setState(() => _obscureOld = !_obscureOld),
                                ),
                                const SizedBox(height: 12),
                                _buildInput(C,
                                  controller: newPassCtrl,
                                  label: 'NEW PASSWORD',
                                  icon: Icons.vpn_key_rounded,
                                  obscure: _obscureNew,
                                  onToggle: () =>
                                      setState(() => _obscureNew = !_obscureNew),
                                ),
                                const SizedBox(height: 12),
                                _buildInput(C,
                                  controller: confirmPassCtrl,
                                  label: 'CONFIRM PASSWORD',
                                  icon: Icons.enhanced_encryption_rounded,
                                  obscure: _obscureConfirm,
                                  onToggle: () => setState(
                                      () => _obscureConfirm = !_obscureConfirm),
                                ),
                              ],
                            ),
                          ),
                          const SizedBox(height: 24),
                          _MetalButton(
                            C: C,
                            label: _isLoading
                                ? 'PROCESSING...'
                                : 'UPDATE PASSWORD',
                            color: C.primaryHi,
                            height: 56,
                            icon: _isLoading ? null : Icons.security_rounded,
                            loading: _isLoading,
                            onTap: _isLoading ? null : () => _changePassword(C),
                          ),
                          const SizedBox(height: 16),
                          _SoftPanel(
                            C: C,
                            padding: const EdgeInsets.all(12),
                            child: Row(
                              children: [
                                Container(
                                  padding: const EdgeInsets.all(6),
                                  decoration: BoxDecoration(
                                    shape: BoxShape.circle,
                                    color: C.primaryLo,
                                    border: Border.all(
                                        color: C.accent.withOpacity(0.5),
                                        width: 1),
                                  ),
                                  child: Icon(Icons.info_outline_rounded,
                                      color: C.accent, size: 12),
                                ),
                                const SizedBox(width: 10),
                                Expanded(
                                  child: Text(
                                    'Gunakan password yang kuat & mudah diingat.',
                                    style: TextStyle(
                                      color: C.text.withOpacity(0.55),
                                      fontFamily: 'ShareTechMono',
                                      fontWeight: FontWeight.w700,
                                      fontSize: 9,
                                      height: 1.4,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          const SizedBox(height: 20),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  Widget _buildTopBar(AppPalette C) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
      child: Container(
        height: 54,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(10),
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [C.bg, C.bgDark],
          ),
          border: Border.all(
            color: C.primaryHi.withOpacity(0.4),
            width: 1.2,
          ),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.6),
              offset: const Offset(0, 3),
              blurRadius: 6,
            ),
            BoxShadow(
              color: C.primaryHi.withOpacity(0.15),
              blurRadius: 12,
              spreadRadius: 0,
            ),
          ],
        ),
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 10),
          child: Row(
            children: [
              _Screw(C: C, size: 12),
              const SizedBox(width: 8),
              _MetalIconButton(
                C: C,
                icon: Icons.arrow_back_ios_new_rounded,
                onTap: () => Navigator.pop(context),
              ),
              const SizedBox(width: 10),
              _Led(color: C.primaryHi, size: 8),
              const SizedBox(width: 10),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text(
                      'CHANGE PASSWORD',
                      style: TextStyle(
                        color: C.primaryHi,
                        fontFamily: 'Orbitron',
                        fontWeight: FontWeight.w900,
                        fontSize: 12,
                        letterSpacing: 2,
                        shadows: [
                          const Shadow(
                            color: Colors.black,
                            offset: Offset(0, 1),
                            blurRadius: 2,
                          ),
                          Shadow(
                            color: C.primaryHi,
                            offset: const Offset(0, 0),
                            blurRadius: 6,
                          ),
                        ],
                      ),
                      overflow: TextOverflow.ellipsis,
                    ),
                    const SizedBox(height: 1),
                    Text(
                      '@${widget.username}',
                      style: TextStyle(
                        color: C.text.withOpacity(0.55),
                        fontSize: 9,
                        fontFamily: 'ShareTechMono',
                        fontWeight: FontWeight.w700,
                        letterSpacing: 0.5,
                      ),
                    ),
                  ],
                ),
              ),
              _Screw(C: C, size: 12),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildSectionHeader(AppPalette C, String title) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 4),
      child: Row(
        children: [
          _Led(color: C.accent, size: 6),
          const SizedBox(width: 10),
          Text(
            '// $title',
            style: TextStyle(
              color: C.accent,
              fontFamily: 'Orbitron',
              fontWeight: FontWeight.w900,
              fontSize: 10,
              letterSpacing: 2,
              shadows: const [
                Shadow(
                  color: Colors.black,
                  offset: Offset(0, 1),
                  blurRadius: 2,
                ),
              ],
            ),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Container(
              height: 1,
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [
                    C.primaryHi.withOpacity(0.5),
                    Colors.transparent,
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildLockIcon(AppPalette C) {
    return Stack(
      alignment: Alignment.center,
      children: [
        Container(
          width: 90,
          height: 90,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [C.textSub, C.bgDark],
            ),
            border: Border.all(
              color: C.primaryHi.withOpacity(0.5),
              width: 1.5,
            ),
            boxShadow: [
              BoxShadow(
                color: C.primaryHi.withOpacity(0.2),
                blurRadius: 15,
                spreadRadius: 1,
              ),
              BoxShadow(
                color: Colors.black.withOpacity(0.6),
                offset: const Offset(0, 4),
                blurRadius: 8,
              ),
            ],
          ),
        ),
        Container(
          width: 70,
          height: 70,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: C.bgDeep,
            border: Border.all(
              color: C.primaryHi.withOpacity(0.6),
              width: 1.2,
            ),
          ),
          child: Icon(
            Icons.lock_reset_rounded,
            color: C.primaryHi,
            size: 32,
          ),
        ),
        Positioned(
          top: 0,
          right: 0,
          child: _Led(color: C.primaryHi, size: 10),
        ),
        Positioned(
          bottom: 2,
          child: _Rivet(C: C, size: 6),
        ),
      ],
    );
  }

  Widget _buildInput(AppPalette C, {
    required TextEditingController controller,
    required String label,
    required IconData icon,
    required bool obscure,
    required VoidCallback onToggle,
  }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.only(left: 4, bottom: 6),
          child: Text(
            label,
            style: TextStyle(
              color: C.text.withOpacity(0.5),
              fontSize: 8,
              fontFamily: 'Orbitron',
              fontWeight: FontWeight.w900,
              letterSpacing: 1.5,
            ),
          ),
        ),
        _SoftInset(
          C: C,
          padding: const EdgeInsets.symmetric(horizontal: 12),
          child: Row(
            children: [
              Container(
                padding: const EdgeInsets.all(6),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(6),
                  color: C.primaryLo,
                  border: Border.all(
                      color: C.primaryHi.withOpacity(0.6), width: 1),
                ),
                child: Icon(icon, color: C.primaryHi, size: 13),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: TextField(
                  controller: controller,
                  obscureText: obscure,
                  style: TextStyle(
                    color: C.text,
                    fontSize: 13,
                    fontFamily: 'ShareTechMono',
                    fontWeight: FontWeight.w700,
                    letterSpacing: 1,
                  ),
                  cursorColor: C.accent,
                  cursorWidth: 2,
                  decoration: const InputDecoration(
                    border: InputBorder.none,
                    contentPadding: EdgeInsets.symmetric(vertical: 16),
                  ),
                ),
              ),
              GestureDetector(
                onTap: onToggle,
                child: Container(
                  padding: const EdgeInsets.all(6),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(6),
                    color: C.bg.withOpacity(0.5),
                    border: Border.all(color: C.bgDark, width: 1),
                  ),
                  child: Icon(
                    obscure
                        ? Icons.visibility_off_outlined
                        : Icons.visibility_outlined,
                    color: C.accent,
                    size: 13,
                  ),
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}

// ─── Helper Widgets ─────────────────────────────────────────

class _Led extends StatelessWidget {
  final Color color;
  final double size;
  const _Led({required this.color, this.size = 7});
  @override
  Widget build(BuildContext context) => Container(
        width: size, height: size,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          color: color,
          boxShadow: [
            BoxShadow(color: color.withOpacity(0.7), blurRadius: size, spreadRadius: 0.5),
            BoxShadow(color: color.withOpacity(0.4), blurRadius: size * 2, spreadRadius: 1),
          ],
        ),
      );
}

class _Rivet extends StatelessWidget {
  final AppPalette C;
  final double size;
  const _Rivet({required this.C, this.size = 5});
  @override
  Widget build(BuildContext context) => Container(
        width: size, height: size,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [C.accentHi, C.primaryLo],
          ),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.5),
              offset: const Offset(1, 1),
              blurRadius: 1,
            ),
          ],
        ),
      );
}

class _Screw extends StatelessWidget {
  final AppPalette C;
  final double size;
  const _Screw({required this.C, this.size = 10});
  @override
  Widget build(BuildContext context) => Container(
        width: size, height: size,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [C.text, C.bgDark],
          ),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.6),
              offset: const Offset(1, 1),
              blurRadius: 2,
            ),
          ],
        ),
        child: Center(
          child: Container(
            width: size * 0.6, height: 1.2,
            color: Colors.black.withOpacity(0.7),
          ),
        ),
      );
}

class _SoftPanel extends StatelessWidget {
  final AppPalette C;
  final Widget child;
  final EdgeInsets padding;
  final double radius;
  final Color? accent;
  const _SoftPanel({
    required this.C,
    required this.child,
    this.padding = const EdgeInsets.all(14),
    this.radius = 12,
    this.accent,
  });
  @override
  Widget build(BuildContext context) {
    final accentColor = accent ?? C.textSub;
    return Container(
      padding: padding,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(radius),
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [C.bg, C.bgDark],
        ),
        border: Border.all(color: accentColor, width: 1.2),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.55),
            offset: const Offset(0, 4),
            blurRadius: 8,
          ),
          BoxShadow(
            color: Colors.white.withOpacity(0.06),
            offset: const Offset(-1, -1),
            blurRadius: 2,
          ),
        ],
      ),
      child: child,
    );
  }
}

class _SoftInset extends StatelessWidget {
  final AppPalette C;
  final Widget child;
  final EdgeInsets padding;
  const _SoftInset({
    required this.C,
    required this.child,
    this.padding = const EdgeInsets.symmetric(horizontal: 12),
  });
  @override
  Widget build(BuildContext context) => Container(
        padding: padding,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(8),
          color: C.bgDeep,
          border: Border.all(color: C.bgDark, width: 1.5),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.8),
              offset: const Offset(0, 1),
              blurRadius: 2,
            ),
            BoxShadow(
              color: Colors.white.withOpacity(0.04),
              offset: const Offset(0, -1),
              blurRadius: 1,
            ),
          ],
        ),
        child: child,
      );
}

class _MetalButton extends StatefulWidget {
  final AppPalette C;
  final String label;
  final Color color;
  final double height;
  final VoidCallback? onTap;
  final IconData? icon;
  final bool loading;
  const _MetalButton({
    required this.C,
    required this.label,
    required this.color,
    required this.height,
    required this.onTap,
    this.icon,
    this.loading = false,
  });
  @override
  State<_MetalButton> createState() => _MetalButtonState();
}

class _MetalButtonState extends State<_MetalButton> {
  bool _pressed = false;
  @override
  Widget build(BuildContext context) {
    final C = widget.C;
    final disabled = widget.onTap == null;
    return GestureDetector(
      onTapDown: disabled ? null : (_) => setState(() => _pressed = true),
      onTapUp: disabled ? null : (_) {
        setState(() => _pressed = false);
        widget.onTap?.call();
      },
      onTapCancel: () => setState(() => _pressed = false),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 80),
        height: widget.height,
        width: double.infinity,
        transform: Matrix4.translationValues(_pressed ? 1.5 : 0, _pressed ? 1.5 : 0, 0),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(10),
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: disabled
                ? [C.bg, C.bgDark]
                : [widget.color.withOpacity(0.9), widget.color, widget.color.withOpacity(0.7)],
          ),
          border: Border.all(
            color: disabled ? C.bgDark : widget.color.withOpacity(0.9),
            width: 1.5,
          ),
          boxShadow: _pressed || disabled
              ? []
              : [
                  BoxShadow(color: widget.color.withOpacity(0.35), blurRadius: 8, spreadRadius: 0),
                  BoxShadow(color: Colors.black.withOpacity(0.5), offset: const Offset(0, 3), blurRadius: 5),
                ],
        ),
        child: Stack(
          children: [
            Positioned(top: 4, left: 4, child: _Rivet(C: C, size: 5)),
            Positioned(top: 4, right: 4, child: _Rivet(C: C, size: 5)),
            Positioned(bottom: 4, left: 4, child: _Rivet(C: C, size: 5)),
            Positioned(bottom: 4, right: 4, child: _Rivet(C: C, size: 5)),
            Center(
              child: widget.loading
                  ? Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        SizedBox(
                          width: 16, height: 16,
                          child: CircularProgressIndicator(color: C.text, strokeWidth: 2),
                        ),
                        const SizedBox(width: 10),
                        Text(
                          widget.label,
                          style: TextStyle(
                            color: C.text,
                            fontSize: 11,
                            fontWeight: FontWeight.w900,
                            fontFamily: 'Orbitron',
                            letterSpacing: 2,
                          ),
                        ),
                      ],
                    )
                  : Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        if (widget.icon != null) ...[
                          Icon(widget.icon, color: C.text, size: 15),
                          const SizedBox(width: 8),
                        ],
                        Text(
                          widget.label,
                          style: TextStyle(
                            color: C.text,
                            fontSize: 12,
                            fontWeight: FontWeight.w900,
                            fontFamily: 'Orbitron',
                            letterSpacing: 2,
                            shadows: const [
                              Shadow(
                                color: Colors.black54,
                                offset: Offset(0, 1),
                                blurRadius: 2,
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
            ),
          ],
        ),
      ),
    );
  }
}

class _MetalIconButton extends StatefulWidget {
  final AppPalette C;
  final IconData icon;
  final VoidCallback onTap;
  final double size;
  const _MetalIconButton({
    required this.C,
    required this.icon,
    required this.onTap,
    this.size = 34,
  });
  @override
  State<_MetalIconButton> createState() => _MetalIconButtonState();
}

class _MetalIconButtonState extends State<_MetalIconButton> {
  bool _pressed = false;
  @override
  Widget build(BuildContext context) {
    final C = widget.C;
    return GestureDetector(
      onTapDown: (_) => setState(() => _pressed = true),
      onTapUp: (_) {
        setState(() => _pressed = false);
        widget.onTap();
      },
      onTapCancel: () => setState(() => _pressed = false),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 80),
        width: widget.size,
        height: widget.size,
        transform: Matrix4.translationValues(_pressed ? 1 : 0, _pressed ? 1 : 0, 0),
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [C.textSub, C.bgDark],
          ),
          border: Border.all(color: C.text.withOpacity(0.5), width: 1),
          boxShadow: _pressed
              ? []
              : [
                  BoxShadow(color: Colors.black.withOpacity(0.6), offset: const Offset(0, 2), blurRadius: 3),
                ],
        ),
        child: Icon(widget.icon, color: C.primaryHi, size: widget.size * 0.42),
      ),
    );
  }
}