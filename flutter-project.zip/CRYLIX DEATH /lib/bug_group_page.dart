// lib/bug_group_page.dart — Send Bug to Groups (Support Style Switcher)
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'app_theme.dart';
import 'api_config.dart';

class BugGroupPage extends StatefulWidget {
  final String sessionKey;
  final String role;

  const BugGroupPage({
    super.key,
    required this.sessionKey,
    required this.role,
  });

  @override
  State<BugGroupPage> createState() => _BugGroupPageState();
}

class _BugGroupPageState extends State<BugGroupPage> {
  final TextEditingController _groupIdCtrl = TextEditingController();
  final TextEditingController _messageCtrl = TextEditingController();

  bool _isSending = false;
  String _bugType = 'crash';
  bool _useDelay = true;

  final List<Map<String, String>> _bugTypes = [
    {'id': 'crash', 'label': 'CRASH', 'icon': '💥'},
    {'id': 'blank', 'label': 'BLANK', 'icon': '⬜'},
    {'id': 'freeze', 'label': 'FREEZE', 'icon': '🧊'},
    {'id': 'loop', 'label': 'LOOP', 'icon': '🔄'},
  ];

  Future<void> _sendBug(AppPalette C, bool isComic) async {
    final groupId = _groupIdCtrl.text.trim();
    if (groupId.isEmpty) {
      _showMessage(C, isComic, 'Masukkan ID Group dulu!', isError: true);
      return;
    }

    setState(() => _isSending = true);

    try {
      final uri = Uri.parse(
          '$baseUrl/sendBugToGroup?key=${widget.sessionKey}');
      final res = await http.post(
        uri,
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'groupId': groupId,
          'bugType': _bugType,
          'message': _messageCtrl.text.trim(),
          'delay': _useDelay,
        }),
      ).timeout(const Duration(seconds: 20));

      final data = jsonDecode(res.body);

      if (!mounted) return;

      if (data['valid'] == true || data['success'] == true) {
        _showMessage(C, isComic, 'Bug berhasil dikirim ke group!',
            isError: false);
        _messageCtrl.clear();
        HapticFeedback.heavyImpact();
      } else {
        _showMessage(C, isComic,
            data['message'] ?? 'Gagal mengirim bug', isError: true);
      }
    } catch (e) {
      if (mounted) {
        _showMessage(C, isComic, 'Koneksi error: $e', isError: true);
      }
    } finally {
      if (mounted) setState(() => _isSending = false);
    }
  }

  void _showMessage(AppPalette C, bool isComic, String msg,
      {bool isError = false}) {
    final c = isError ? C.primaryHi : C.primaryHi;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Row(
          children: [
            _Led(color: c, size: 8, blink: !isComic),
            const SizedBox(width: 12),
            Expanded(
              child: Text(msg,
                  style: TextStyle(
                    color: C.text,
                    fontSize: isComic ? 13 : 12,
                    fontWeight: FontWeight.w700,
                    fontFamily:
                        isComic ? 'ComicNeue' : 'ShareTechMono',
                    letterSpacing: 0.3)),
            ),
          ],
        ),
        backgroundColor: C.bgDark,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(isComic ? 12 : 8),
          side: BorderSide(color: c, width: isComic ? 3 : 1.5)),
        margin: const EdgeInsets.all(16),
        duration: const Duration(seconds: 3),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<AppPalette>(
      valueListenable: AppTheme.current,
      builder: (context, C, _) {
        return ValueListenableBuilder<ThemeStyle>(
          valueListenable: AppTheme.currentStyle,
          builder: (context, style, __) {
            final isComic = style == ThemeStyle.comic3d;

            return Scaffold(
              backgroundColor: C.bgDeep,
              body: Container(
                decoration: isComic
                    ? BoxDecoration(color: C.bg)
                    : BoxDecoration(
                        gradient: RadialGradient(
                          center: const Alignment(-0.3, -0.3),
                          radius: 1.2,
                          colors: [C.bg, C.bgDark, C.bgDeep],
                          stops: const [0.0, 0.6, 1.0])),
                child: Stack(
                  children: [
                    if (isComic)
                      Positioned.fill(
                        child: IgnorePointer(
                          child: CustomPaint(
                            painter: _ComicHalftonePainter(
                                color: C.primaryLo.withOpacity(0.12))))),
                    SafeArea(
                      child: Column(
                        children: [
                          const SizedBox(height: 8),
                          _buildAppBar(C, isComic),
                          const SizedBox(height: 12),
                          Expanded(
                            child: SingleChildScrollView(
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 14),
                              physics: const BouncingScrollPhysics(),
                              child: Column(
                                crossAxisAlignment:
                                    CrossAxisAlignment.start,
                                children: [
                                  _buildHeaderPanel(C, isComic),
                                  const SizedBox(height: 14),
                                  _buildBugTypeSelector(C, isComic),
                                  const SizedBox(height: 14),
                                  _buildGroupIdInput(C, isComic),
                                  const SizedBox(height: 14),
                                  _buildMessageInput(C, isComic),
                                  const SizedBox(height: 14),
                                  _buildDelayToggle(C, isComic),
                                  const SizedBox(height: 20),
                                  _buildSendButton(C, isComic),
                                  const SizedBox(height: 30),
                                ],
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            );
          },
        );
      },
    );
  }

  Widget _buildAppBar(AppPalette C, bool isComic) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 12),
      child: _MetalPlate(
        C: C,
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
        child: Row(
          children: [
            GestureDetector(
              onTap: () => Navigator.pop(context),
              child: Container(
                width: 40, height: 40,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(10),
                  gradient: isComic ? null
                      : LinearGradient(
                          begin: Alignment.topCenter,
                          end: Alignment.bottomCenter,
                          colors: [C.textSub, C.bg, C.bgDark]),
                  color: isComic ? C.accent : null,
                  border: Border.all(
                      color: isComic ? Colors.black
                          : Colors.black.withOpacity(0.7),
                      width: isComic ? 3 : 1.2)),
                child: Icon(Icons.arrow_back_ios_new_rounded,
                    color: isComic ? Colors.white : C.accent, size: 16),
              ),
            ),
            const SizedBox(width: 12),
            Stack(
              alignment: Alignment.center,
              children: [
                Container(
                  width: 40, height: 40,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    gradient: isComic ? null
                        : RadialGradient(colors: [C.text, C.bg, C.bgDark]),
                    color: isComic ? C.primaryHi : null,
                    border: Border.all(
                        color: isComic ? Colors.black : C.primaryHi,
                        width: isComic ? 3 : 2)),
                  child: Icon(Icons.groups_rounded,
                      color: isComic ? Colors.white : C.primaryHi,
                      size: 20),
                ),
                if (!isComic)
                  Positioned(top: -2, right: -2,
                      child: _Led(color: C.accent, size: 6, blink: true)),
              ],
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('BUG GROUP',
                      style: TextStyle(
                        color: isComic ? Colors.black : C.accentHi,
                        fontSize: isComic ? 18 : 13,
                        fontWeight: FontWeight.w900,
                        fontFamily: isComic ? 'Bangers' : 'Orbitron',
                        letterSpacing: isComic ? 1.5 : 2, height: 1,
                        shadows: isComic ? null : [
                          Shadow(color: C.primaryLo,
                              offset: const Offset(0, 1), blurRadius: 1),
                          const Shadow(color: Colors.black,
                              offset: Offset(0, 2), blurRadius: 3),
                        ])),
                  const SizedBox(height: 3),
                  Row(
                    children: [
                      _Led(color: C.primaryHi, size: 4, blink: !isComic),
                      const SizedBox(width: 5),
                      Text('SEND TO GROUP',
                          style: TextStyle(
                            color: isComic
                                ? Colors.black.withOpacity(0.5)
                                : C.text.withOpacity(0.55),
                            fontSize: 8,
                            fontWeight: FontWeight.w700,
                            fontFamily:
                                isComic ? 'ComicNeue' : 'ShareTechMono',
                            letterSpacing: 1.2)),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildHeaderPanel(AppPalette C, bool isComic) {
    return _MetalPlate(
      C: C,
      padding: const EdgeInsets.all(14),
      child: Row(
        children: [
          Container(
            width: 44, height: 44,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: isComic ? null
                  : RadialGradient(colors: [C.text, C.bg, C.bgDark]),
              color: isComic ? C.primaryHi : null,
              border: Border.all(
                  color: isComic ? Colors.black : C.accentHi,
                  width: isComic ? 3 : 2)),
            child: Icon(Icons.groups_rounded,
                color: isComic ? Colors.white : C.accentHi, size: 22),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('KIRIM BUG KE GROUP',
                    style: TextStyle(
                      color: isComic ? Colors.black : C.accentHi,
                      fontSize: isComic ? 15 : 12,
                      fontWeight: FontWeight.w900,
                      fontFamily: isComic ? 'Bangers' : 'Orbitron',
                      letterSpacing: 1.5)),
                const SizedBox(height: 4),
                Text('Pilih tipe bug & masukkan ID Group\nuntuk mengirim attack.',
                    style: TextStyle(
                      color: isComic
                          ? Colors.black.withOpacity(0.7)
                          : C.text.withOpacity(0.7),
                      fontSize: isComic ? 12 : 10,
                      fontFamily: isComic ? 'ComicNeue' : 'ShareTechMono',
                      height: 1.5,
                      fontWeight: isComic ? FontWeight.w700 : null)),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildBugTypeSelector(AppPalette C, bool isComic) {
    return _MetalPlate(
      C: C,
      padding: const EdgeInsets.all(14),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              if (!isComic) _Screw(C: C, size: 12),
              if (!isComic) const SizedBox(width: 10),
              Icon(Icons.bug_report_rounded,
                  color: isComic ? Colors.black : C.primaryHi, size: 16),
              const SizedBox(width: 8),
              Text('PILIH TIPE BUG',
                  style: TextStyle(
                    color: isComic ? Colors.black : C.primaryHi,
                    fontSize: isComic ? 14 : 11,
                    fontWeight: FontWeight.w900,
                    fontFamily: isComic ? 'Bangers' : 'Orbitron',
                    letterSpacing: 1.5)),
            ],
          ),
          const SizedBox(height: 12),
          Wrap(
            spacing: 8, runSpacing: 8,
            children: _bugTypes.map((type) {
              final isSelected = _bugType == type['id'];
              return GestureDetector(
                onTap: () {
                  HapticFeedback.selectionClick();
                  setState(() => _bugType = type['id']!);
                },
                child: AnimatedContainer(
                  duration: const Duration(milliseconds: 150),
                  padding: const EdgeInsets.symmetric(
                      horizontal: 16, vertical: 12),
                  decoration: BoxDecoration(
                    borderRadius:
                        BorderRadius.circular(isComic ? 12 : 10),
                    gradient: isSelected && !isComic
                        ? LinearGradient(colors: [
                            C.primaryHi, C.primary, C.primaryLo])
                        : null,
                    color: isComic
                        ? (isSelected ? C.primaryHi : C.bg)
                        : null,
                    border: Border.all(
                        color: isComic
                            ? Colors.black
                            : (isSelected
                                ? C.primaryHi
                                : C.textSub.withOpacity(0.4)),
                        width: isComic ? 3 : 1.5),
                    boxShadow: isComic
                        ? const [
                            BoxShadow(color: Colors.black,
                                offset: Offset(3, 3), blurRadius: 0),
                          ]
                        : (isSelected
                            ? [BoxShadow(
                                color: C.primaryHi.withOpacity(0.5),
                                blurRadius: 10)]
                            : null),
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Text(type['icon']!,
                          style: TextStyle(fontSize: isComic ? 18 : 16)),
                      const SizedBox(width: 8),
                      Text(type['label']!,
                          style: TextStyle(
                            color: isComic
                                ? (isSelected ? Colors.white : Colors.black)
                                : (isSelected ? C.bgDeep : C.text),
                            fontSize: isComic ? 14 : 11,
                            fontWeight: FontWeight.w900,
                            fontFamily:
                                isComic ? 'Bangers' : 'Orbitron',
                            letterSpacing: 1)),
                    ],
                  ),
                ),
              );
            }).toList(),
          ),
        ],
      ),
    );
  }

  Widget _buildGroupIdInput(AppPalette C, bool isComic) {
    return _MetalPlate(
      C: C,
      padding: const EdgeInsets.all(14),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(Icons.link_rounded,
                  color: isComic ? Colors.black : C.accent, size: 16),
              const SizedBox(width: 8),
              Text('ID GROUP',
                  style: TextStyle(
                    color: isComic ? Colors.black : C.accent,
                    fontSize: isComic ? 14 : 11,
                    fontWeight: FontWeight.w900,
                    fontFamily: isComic ? 'Bangers' : 'Orbitron',
                    letterSpacing: 1.5)),
            ],
          ),
          const SizedBox(height: 10),
          Container(
            decoration: isComic
                ? BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(color: Colors.black, width: 3))
                : null,
            child: TextField(
              controller: _groupIdCtrl,
              style: TextStyle(
                color: isComic ? Colors.black : C.text,
                fontSize: isComic ? 14 : 13,
                fontFamily: isComic ? 'ComicNeue' : 'ShareTechMono',
                fontWeight: FontWeight.w700),
              cursorColor: isComic ? Colors.black : C.accent,
              decoration: InputDecoration(
                hintText: 'Contoh: 123456789@g.us',
                hintStyle: TextStyle(
                  color: isComic
                      ? Colors.black.withOpacity(0.4)
                      : C.text.withOpacity(0.3),
                  fontSize: isComic ? 13 : 11,
                  fontFamily: isComic ? 'ComicNeue' : 'ShareTechMono'),
                prefixIcon: Icon(Icons.group_rounded,
                    color: isComic ? Colors.black : C.accent, size: 20),
                filled: !isComic,
                fillColor: isComic ? null : C.bgDeep,
                border: isComic
                    ? InputBorder.none
                    : OutlineInputBorder(
                        borderRadius: BorderRadius.circular(10),
                        borderSide: BorderSide(
                            color: C.accent.withOpacity(0.3), width: 1.5)),
                enabledBorder: isComic
                    ? InputBorder.none
                    : OutlineInputBorder(
                        borderRadius: BorderRadius.circular(10),
                        borderSide: BorderSide(
                            color: C.accent.withOpacity(0.3), width: 1.5)),
                focusedBorder: isComic
                    ? InputBorder.none
                    : OutlineInputBorder(
                        borderRadius: BorderRadius.circular(10),
                        borderSide: BorderSide(color: C.accent, width: 2)),
                contentPadding: const EdgeInsets.symmetric(
                    horizontal: 14, vertical: 14)),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildMessageInput(AppPalette C, bool isComic) {
    return _MetalPlate(
      C: C,
      padding: const EdgeInsets.all(14),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(Icons.message_rounded,
                  color: isComic ? Colors.black : C.accent, size: 16),
              const SizedBox(width: 8),
              Text('PESAN (OPSIONAL)',
                  style: TextStyle(
                    color: isComic ? Colors.black : C.accent,
                    fontSize: isComic ? 14 : 11,
                    fontWeight: FontWeight.w900,
                    fontFamily: isComic ? 'Bangers' : 'Orbitron',
                    letterSpacing: 1.5)),
            ],
          ),
          const SizedBox(height: 10),
          Container(
            decoration: isComic
                ? BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(color: Colors.black, width: 3))
                : null,
            child: TextField(
              controller: _messageCtrl,
              maxLines: 3,
              style: TextStyle(
                color: isComic ? Colors.black : C.text,
                fontSize: isComic ? 14 : 13,
                fontFamily: isComic ? 'ComicNeue' : 'ShareTechMono',
                fontWeight: FontWeight.w700),
              cursorColor: isComic ? Colors.black : C.accent,
              decoration: InputDecoration(
                hintText: 'Tulis pesan untuk grup...',
                hintStyle: TextStyle(
                  color: isComic
                      ? Colors.black.withOpacity(0.4)
                      : C.text.withOpacity(0.3),
                  fontSize: isComic ? 13 : 11,
                  fontFamily: isComic ? 'ComicNeue' : 'ShareTechMono'),
                filled: !isComic,
                fillColor: isComic ? null : C.bgDeep,
                border: isComic
                    ? InputBorder.none
                    : OutlineInputBorder(
                        borderRadius: BorderRadius.circular(10),
                        borderSide: BorderSide(
                            color: C.accent.withOpacity(0.3), width: 1.5)),
                enabledBorder: isComic
                    ? InputBorder.none
                    : OutlineInputBorder(
                        borderRadius: BorderRadius.circular(10),
                        borderSide: BorderSide(
                            color: C.accent.withOpacity(0.3), width: 1.5)),
                focusedBorder: isComic
                    ? InputBorder.none
                    : OutlineInputBorder(
                        borderRadius: BorderRadius.circular(10),
                        borderSide: BorderSide(color: C.accent, width: 2)),
                contentPadding: const EdgeInsets.all(14)),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildDelayToggle(AppPalette C, bool isComic) {
    return _MetalPlate(
      C: C,
      padding: const EdgeInsets.all(14),
      child: Row(
        children: [
          Icon(Icons.timer_rounded,
              color: isComic ? Colors.black : C.accent, size: 18),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('PAKAI DELAY',
                    style: TextStyle(
                      color: isComic ? Colors.black : C.accent,
                      fontSize: isComic ? 14 : 12,
                      fontWeight: FontWeight.w900,
                      fontFamily: isComic ? 'Bangers' : 'Orbitron',
                      letterSpacing: 1)),
                const SizedBox(height: 3),
                Text('Delay 2 detik antar pesan biar aman',
                    style: TextStyle(
                      color: isComic
                          ? Colors.black.withOpacity(0.6)
                          : C.text.withOpacity(0.6),
                      fontSize: isComic ? 11 : 10,
                      fontFamily:
                          isComic ? 'ComicNeue' : 'ShareTechMono')),
              ],
            ),
          ),
          Switch(
            value: _useDelay,
            onChanged: (v) {
              HapticFeedback.selectionClick();
              setState(() => _useDelay = v);
            },
            activeColor: isComic ? Colors.white : C.primaryHi,
            activeTrackColor: isComic ? C.primaryHi : C.primaryHi.withOpacity(0.5),
            inactiveThumbColor: isComic ? Colors.black : C.textSub,
            inactiveTrackColor:
                isComic ? Colors.white : C.bgDeep,
          ),
        ],
      ),
    );
  }

  Widget _buildSendButton(AppPalette C, bool isComic) {
    return GestureDetector(
      onTap: _isSending ? null : () => _sendBug(C, isComic),
      child: Container(
        height: 60,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(isComic ? 16 : 14),
          gradient: isComic
              ? null
              : LinearGradient(
                  colors: [C.primaryHi, C.primary, C.primaryLo]),
          color: isComic ? C.primaryHi : null,
          border: Border.all(
              color: isComic ? Colors.black : C.primaryLo,
              width: isComic ? 5 : 2),
          boxShadow: isComic
              ? const [
                  BoxShadow(color: Colors.black,
                      offset: Offset(6, 6), blurRadius: 0),
                ]
              : [
                  BoxShadow(
                      color: C.primaryHi.withOpacity(0.4),
                      blurRadius: 15),
                ],
        ),
        child: Center(
          child: _isSending
              ? Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    SizedBox(
                      width: 22, height: 22,
                      child: CircularProgressIndicator(
                        strokeWidth: 2.5,
                        valueColor:
                            AlwaysStoppedAnimation<Color>(Colors.white))),
                    const SizedBox(width: 12),
                    Text('MENGIRIM...',
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: isComic ? 18 : 14,
                          fontWeight: FontWeight.w900,
                          fontFamily:
                              isComic ? 'Bangers' : 'Orbitron',
                          letterSpacing: 2)),
                  ],
                )
              : Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(Icons.send_rounded,
                        color: Colors.white,
                        size: isComic ? 24 : 22),
                    const SizedBox(width: 10),
                    Text('KIRIM BUG',
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: isComic ? 20 : 16,
                          fontWeight: FontWeight.w900,
                          fontFamily:
                              isComic ? 'Bangers' : 'Orbitron',
                          letterSpacing: isComic ? 3 : 3,
                          shadows: const [
                            Shadow(color: Colors.black54,
                                offset: Offset(0, 1), blurRadius: 2),
                          ])),
                  ],
                ),
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════
// HELPER WIDGETS
// ═══════════════════════════════════════════════════════════
class _Led extends StatelessWidget {
  final Color color;
  final double size;
  final bool blink;
  const _Led({required this.color, this.size = 8, this.blink = false});

  @override
  Widget build(BuildContext context) {
    final isComic = AppTheme.currentStyle.value == ThemeStyle.comic3d;
    if (isComic) {
      return Container(
        width: size, height: size,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          color: color,
          border: Border.all(color: Colors.black, width: size * 0.18)));
    }
    return Container(
      width: size, height: size,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        gradient: RadialGradient(
          center: const Alignment(-0.35, -0.35),
          colors: [
            Colors.white.withOpacity(0.85),
            color.withOpacity(0.9),
            color.withOpacity(0.55),
          ],
          stops: const [0.0, 0.4, 1.0]),
        border: Border.all(
            color: Colors.black.withOpacity(0.85),
            width: size * 0.1),
        boxShadow: [
          BoxShadow(color: color.withOpacity(0.75),
              blurRadius: size * 1.4, spreadRadius: size * 0.2),
        ]),
    );
  }
}

class _Screw extends StatelessWidget {
  final AppPalette C;
  final double size;
  const _Screw({required this.C, this.size = 14});
  @override
  Widget build(BuildContext context) {
    if (AppTheme.currentStyle.value == ThemeStyle.comic3d) {
      return const SizedBox.shrink();
    }
    return Container(
      width: size, height: size,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        gradient: RadialGradient(
          center: const Alignment(-0.35, -0.35),
          colors: [C.text, C.textSub, C.bg, C.bgDark],
          stops: const [0.0, 0.35, 0.7, 1.0])),
      child: Center(
        child: Transform.rotate(
          angle: 0.785,
          child: Container(
            width: size * 0.7, height: size * 0.11,
            color: Colors.black.withOpacity(0.9)),
        ),
      ),
    );
  }
}

class _MetalPlate extends StatelessWidget {
  final AppPalette C;
  final Widget child;
  final EdgeInsets padding;
  final bool brass;
  final double radius;
  const _MetalPlate({
    required this.C,
    required this.child,
    this.padding = const EdgeInsets.all(16),
    this.brass = false,
    this.radius = 16,
  });

  @override
  Widget build(BuildContext context) {
    final isComic = AppTheme.currentStyle.value == ThemeStyle.comic3d;
    if (isComic) {
      return Container(
        padding: padding,
        decoration: BoxDecoration(
          color: brass ? C.primaryHi : C.bgDark,
          borderRadius: BorderRadius.circular(radius + 4),
          border: Border.all(color: Colors.black, width: 4),
          boxShadow: const [
            BoxShadow(color: Colors.black, offset: Offset(6, 6),
                blurRadius: 0),
          ]),
        child: child,
      );
    }
    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(radius),
        gradient: LinearGradient(
          begin: Alignment.topLeft, end: Alignment.bottomRight,
          colors: brass
              ? [C.accentHi, C.accent, C.primary, C.primaryLo]
              : [C.text, C.bg, C.bgDark, C.bgDeep],
          stops: const [0.0, 0.4, 0.7, 1.0]),
        boxShadow: [
          BoxShadow(color: Colors.black.withOpacity(0.75),
              offset: const Offset(0, 6), blurRadius: 12),
        ],
      ),
      padding: const EdgeInsets.all(3),
      child: Container(
        padding: padding,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(radius - 3),
          gradient: LinearGradient(
            begin: Alignment.topCenter, end: Alignment.bottomCenter,
            colors: [C.bg, C.bgDark, C.bgDeep]),
          border: Border.all(color: Colors.black.withOpacity(0.5)),
        ),
        child: child,
      ),
    );
  }
}

class _ComicHalftonePainter extends CustomPainter {
  final Color color;
  const _ComicHalftonePainter({required this.color});

  @override
  void paint(Canvas canvas, Size size) {
    const spacing = 22.0;
    final paint = Paint()..color = color;
    for (double x = 0; x < size.width + spacing; x += spacing) {
      for (double y = 0; y < size.height + spacing; y += spacing) {
        canvas.drawCircle(Offset(x, y), 2.5, paint);
      }
    }
  }

  @override
  bool shouldRepaint(_ComicHalftonePainter old) => old.color != color;
}