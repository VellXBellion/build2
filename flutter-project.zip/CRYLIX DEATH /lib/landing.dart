// lib/landing.dart
import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'app_theme.dart';
import 'smart_widgets.dart';
import 'login_page.dart';

class LandingPage extends StatefulWidget {
  const LandingPage({super.key});

  @override
  State<LandingPage> createState() => _LandingPageState();
}

class _LandingPageState extends State<LandingPage>
    with TickerProviderStateMixin {
  // ── Phase control ──
  bool _verified = false;

  // ── Fingerprint animations ──
  late AnimationController _fpPulseCtrl;
  late AnimationController _fpHoldCtrl;
  late AnimationController _scanCtrl;
  late AnimationController _welcomeCtrl;

  late Animation<double> _fpPulse;
  late Animation<double> _scanLine;
  late Animation<double> _welcomeSlide;
  late Animation<double> _welcomeFade;

  // ── Carousel (4 cards Crylix) ──
  final PageController _carouselCtrl = PageController(viewportFraction: 0.88);
  int _carouselIndex = 0;

  // ── Info cards (3 cards — kenapa, update, community) ──
  final PageController _infoCardsCtrl =
      PageController(viewportFraction: 0.88);
  int _infoCardIndex = 0;

  bool _holding = false;

  @override
  void initState() {
    super.initState();

    _fpPulseCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1800),
    )..repeat(reverse: true);

    _fpHoldCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 900),
    );

    _scanCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1600),
    )..repeat();

    _welcomeCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1400),
    );

    _fpPulse = Tween<double>(begin: 0.4, end: 1.0).animate(
      CurvedAnimation(parent: _fpPulseCtrl, curve: Curves.easeInOut),
    );

    _scanLine = Tween<double>(begin: -0.15, end: 1.15).animate(
      CurvedAnimation(parent: _scanCtrl, curve: Curves.easeInOut),
    );

    _welcomeSlide = Tween<double>(begin: -1.0, end: 1.0).animate(
      CurvedAnimation(parent: _welcomeCtrl, curve: Curves.easeOutCubic),
    );

    _welcomeFade = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(
        parent: _welcomeCtrl,
        curve: const Interval(0.3, 1.0, curve: Curves.easeOut),
      ),
    );
  }

  @override
  void dispose() {
    _fpPulseCtrl.dispose();
    _fpHoldCtrl.dispose();
    _scanCtrl.dispose();
    _welcomeCtrl.dispose();
    _carouselCtrl.dispose();
    _infoCardsCtrl.dispose();
    super.dispose();
  }

  // ── Fingerprint hold logic ──
  void _onFpHoldStart() {
    if (_verified) return;
    HapticFeedback.mediumImpact();
    setState(() => _holding = true);
    _fpHoldCtrl.forward();
  }

  void _onFpHoldEnd() {
    if (_verified) return;
    if (!_holding) return;
    setState(() => _holding = false);
    _fpHoldCtrl.reverse();
  }

  // ── Verify success ──
  void _completeVerify() {
    if (_verified) return;
    HapticFeedback.heavyImpact();
    setState(() => _verified = true);
    _welcomeCtrl.forward();
  }

  // ── Listener progress untuk auto success ──
  void _setupHoldListener() {
    _fpHoldCtrl.addStatusListener((status) {
      if (status == AnimationStatus.completed && !_verified) {
        _completeVerify();
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    _setupHoldListener();

    return StyleBuilder(
      builder: (context, C, kit) {
        final isComic = kit.style == ThemeStyle.comic3d;

        return Scaffold(
          backgroundColor: C.bgDeep,
          body: Stack(
            children: [
              // Background
              Positioned.fill(
                child: isComic
                    ? CustomPaint(
                        painter: _HalftonePainter(
                            color: C.primaryLo.withOpacity(0.12)),
                      )
                    : Container(
                        decoration: BoxDecoration(
                          gradient: RadialGradient(
                            center: const Alignment(-0.4, -0.4),
                            radius: 1.5,
                            colors: [C.bg, C.bgDark, C.bgDeep],
                            stops: const [0.0, 0.6, 1.0],
                          ),
                        ),
                      ),
              ),

              // Phase content
              AnimatedSwitcher(
                duration: const Duration(milliseconds: 550),
                switchInCurve: Curves.easeOutCubic,
                switchOutCurve: Curves.easeInCubic,
                child: _verified
                    ? _buildContentPhase(C, isComic)
                    : _buildFingerprintPhase(C, isComic),
              ),
            ],
          ),
        );
      },
    );
  }

  // ═══════════════════════════════════════════════════════════
  // PHASE 1 — FINGERPRINT
  // ═══════════════════════════════════════════════════════════
  Widget _buildFingerprintPhase(AppPalette C, bool isComic) {
    return SafeArea(
      key: const ValueKey('fp-phase'),
      child: Center(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 32),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text(
                'VERIFIKASI',
                style: TextStyle(
                  color: isComic ? C.comicText : C.accent,
                  fontFamily: isComic ? 'Bangers' : 'Orbitron',
                  fontSize: isComic ? 26 : 18,
                  fontWeight: FontWeight.w900,
                  letterSpacing: isComic ? 3 : 6,
                  shadows: isComic
                      ? [
                          Shadow(
                            color: C.comicTextOutline,
                            offset: const Offset(2, 2),
                            blurRadius: 0,
                          ),
                        ]
                      : [
                          Shadow(color: C.accent, blurRadius: 12),
                        ],
                ),
              ),
              const SizedBox(height: 8),
              Text(
                'Tap & tahan sidik jari untuk masuk',
                style: TextStyle(
                  color: isComic ? C.comicTextSub : C.textSub,
                  fontFamily: isComic ? 'ComicNeue' : 'ShareTechMono',
                  fontSize: isComic ? 13 : 11,
                  letterSpacing: 1.2,
                ),
              ),
              const SizedBox(height: 60),

              _buildFingerprintPad(C, isComic),

              const SizedBox(height: 50),

              AnimatedBuilder(
                animation: _fpHoldCtrl,
                builder: (_, __) {
                  final progress = _fpHoldCtrl.value;
                  return Column(
                    children: [
                      Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 18, vertical: 10),
                        decoration: BoxDecoration(
                          color: isComic
                              ? C.bgDark
                              : Colors.black.withOpacity(0.4),
                          borderRadius: BorderRadius.circular(
                              isComic ? 12 : 30),
                          border: Border.all(
                            color: isComic
                                ? Colors.black
                                : C.accent.withOpacity(0.3),
                            width: isComic ? 3 : 1.2,
                          ),
                          boxShadow: isComic
                              ? const [
                                  BoxShadow(
                                    color: Colors.black,
                                    offset: Offset(4, 4),
                                    blurRadius: 0,
                                  ),
                                ]
                              : null,
                        ),
                        child: Text(
                          progress >= 1.0
                              ? '✓ TERVERIFIKASI'
                              : progress > 0
                                  ? 'MEMPROSES...'
                                  : 'MENUNGGU SIDIK JARI',
                          style: TextStyle(
                            color: isComic
                                ? (progress >= 1.0
                                    ? C.accent
                                    : C.comicText)
                                : (progress > 0
                                    ? C.primaryHi
                                    : C.textSub),
                            fontFamily:
                                isComic ? 'Bangers' : 'ShareTechMono',
                            fontSize: isComic ? 14 : 11,
                            fontWeight: FontWeight.w900,
                            letterSpacing: 2,
                          ),
                        ),
                      ),
                      const SizedBox(height: 18),
                      SizedBox(
                        width: 220,
                        child: ClipRRect(
                          borderRadius: BorderRadius.circular(4),
                          child: LinearProgressIndicator(
                            value: progress,
                            minHeight: 6,
                            backgroundColor: isComic
                                ? Colors.black.withOpacity(0.3)
                                : C.bgDark,
                            valueColor: AlwaysStoppedAnimation(
                              isComic ? C.primaryHi : C.accent,
                            ),
                          ),
                        ),
                      ),
                    ],
                  );
                },
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildFingerprintPad(AppPalette C, bool isComic) {
    return GestureDetector(
      onLongPressStart: (_) => _onFpHoldStart(),
      onLongPressEnd: (_) => _onFpHoldEnd(),
      onLongPressCancel: () => _onFpHoldEnd(),
      onTapDown: (_) => _onFpHoldStart(),
      onTapUp: (_) => _onFpHoldEnd(),
      onTapCancel: () => _onFpHoldEnd(),
      child: AnimatedBuilder(
        animation: Listenable.merge([_fpPulse, _fpHoldCtrl, _scanLine]),
        builder: (_, __) {
          final progress = _fpHoldCtrl.value;
          final pulse = _fpPulse.value;
          final size = 180.0 + (progress * 20);

          return Stack(
            alignment: Alignment.center,
            children: [
              ...List.generate(3, (i) {
                final ringSize = size + (i * 30);
                return Container(
                  width: ringSize,
                  height: ringSize,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    border: Border.all(
                      color: (isComic ? C.primaryHi : C.accent)
                          .withOpacity(0.12 * pulse * (3 - i) / 3),
                      width: isComic ? 3 : 1.5,
                    ),
                  ),
                );
              }),

              Container(
                width: size,
                height: size,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: isComic ? C.bgDark : C.bgDark.withOpacity(0.6),
                  border: Border.all(
                    color: isComic
                        ? Colors.black
                        : (progress > 0
                            ? C.accent
                            : C.accent.withOpacity(0.3)),
                    width: isComic ? 5 : (progress > 0 ? 2.5 : 1.5),
                  ),
                  boxShadow: isComic
                      ? const [
                          BoxShadow(
                            color: Colors.black,
                            offset: Offset(8, 8),
                            blurRadius: 0,
                          ),
                        ]
                      : [
                          BoxShadow(
                            color: (progress > 0
                                    ? C.accent
                                    : C.accentHi)
                                .withOpacity(0.4 * pulse),
                            blurRadius: 30,
                            spreadRadius: 4,
                          ),
                        ],
                ),
                child: ClipOval(
                  child: Stack(
                    alignment: Alignment.center,
                    children: [
                      if (_holding)
                        AnimatedBuilder(
                          animation: _scanLine,
                          builder: (_, __) => Positioned(
                            top: size * _scanLine.value,
                            left: 0,
                            right: 0,
                            child: Container(
                              height: 4,
                              decoration: BoxDecoration(
                                gradient: LinearGradient(
                                  colors: [
                                    Colors.transparent,
                                    C.accent,
                                    Colors.transparent,
                                  ],
                                ),
                                boxShadow: [
                                  BoxShadow(
                                    color: C.accent,
                                    blurRadius: 12,
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ),
                      AnimatedContainer(
                        duration: const Duration(milliseconds: 200),
                        child: Icon(
                          Icons.fingerprint_rounded,
                          size: size * 0.5,
                          color: isComic
                              ? (progress >= 1.0
                                  ? C.primaryHi
                                  : C.comicText.withOpacity(
                                      0.5 + progress * 0.5))
                              : (progress > 0
                                  ? C.accent
                                  : C.accent
                                      .withOpacity(0.5 + pulse * 0.3)),
                          shadows: isComic
                              ? [
                                  Shadow(
                                    color: C.comicTextOutline,
                                    offset: const Offset(2, 2),
                                    blurRadius: 0,
                                  ),
                                ]
                              : null,
                        ),
                      ),
                    ],
                  ),
                ),
              ),

              if (progress >= 1.0)
                Positioned(
                  bottom: 20,
                  right: 20,
                  child: Container(
                    padding: const EdgeInsets.all(10),
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: C.primaryHi,
                      border: Border.all(
                        color: isComic ? Colors.black : C.accentShine,
                        width: isComic ? 4 : 2,
                      ),
                      boxShadow: isComic
                          ? const [
                              BoxShadow(
                                color: Colors.black,
                                offset: Offset(3, 3),
                                blurRadius: 0,
                              ),
                            ]
                          : null,
                    ),
                    child: Icon(
                      Icons.check_rounded,
                      color: isComic
                          ? C.contrastTextOn(C.primaryHi)
                          : Colors.white,
                      size: 22,
                    ),
                  ),
                ),
            ],
          );
        },
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════
  // PHASE 2 — CONTENT
  // ═══════════════════════════════════════════════════════════
  Widget _buildContentPhase(AppPalette C, bool isComic) {
    return SafeArea(
      key: const ValueKey('content-phase'),
      child: SingleChildScrollView(
        physics: const BouncingScrollPhysics(),
        padding: const EdgeInsets.symmetric(vertical: 20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            const SizedBox(height: 20),

            // ── WELCOME (slide animation) ──
            AnimatedBuilder(
              animation: _welcomeCtrl,
              builder: (_, __) {
                return ClipRect(
                  child: Transform.translate(
                    offset: Offset(
                      _welcomeSlide.value *
                          -MediaQuery.of(context).size.width,
                      0,
                    ),
                    child: Opacity(
                      opacity: _welcomeFade.value,
                      child: _buildWelcome(C, isComic),
                    ),
                  ),
                );
              },
            ),

            const SizedBox(height: 30),

            // ── 3 INFO CARDS (SWIPE HORIZONTAL) ──
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20),
              child: Text(
                '// KENAPA CONFLICT?',
                style: TextStyle(
                  color: isComic ? C.comicText : C.accent,
                  fontFamily: isComic ? 'Bangers' : 'Orbitron',
                  fontSize: isComic ? 16 : 12,
                  fontWeight: FontWeight.w900,
                  letterSpacing: isComic ? 2 : 3,
                  shadows: isComic
                      ? [
                          Shadow(
                            color: C.comicTextOutline,
                            offset: const Offset(1, 1),
                            blurRadius: 0,
                          ),
                        ]
                      : null,
                ),
              ),
            ),
            const SizedBox(height: 14),

            SizedBox(
              height: 260,
              child: PageView.builder(
                controller: _infoCardsCtrl,
                itemCount: _infoCards.length,
                onPageChanged: (i) =>
                    setState(() => _infoCardIndex = i),
                itemBuilder: (context, i) {
                  final card = _infoCards[i];
                  return Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 8),
                    child: _buildInfoCard(
                      C,
                      isComic,
                      icon: card['icon'] as IconData,
                      title: card['title'] as String,
                      body: card['body'] as String,
                      color: card['color'] as Color,
                    ),
                  );
                },
              ),
            ),

            // Dots indicator
            const SizedBox(height: 12),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: List.generate(_infoCards.length, (i) {
                final active = i == _infoCardIndex;
                return AnimatedContainer(
                  duration: const Duration(milliseconds: 250),
                  margin: const EdgeInsets.symmetric(horizontal: 4),
                  width: active ? 24 : 8,
                  height: 8,
                  decoration: BoxDecoration(
                    color: active
                        ? (isComic ? C.primaryHi : C.accent)
                        : (isComic
                            ? C.bgDark
                            : C.textSub.withOpacity(0.3)),
                    borderRadius: BorderRadius.circular(4),
                    border: isComic
                        ? Border.all(color: Colors.black, width: 2)
                        : null,
                  ),
                );
              }),
            ),

            const SizedBox(height: 30),

            // ── 4 CRYLIX CARDS ──
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20),
              child: Text(
                '// CONFLICT CARDS',
                style: TextStyle(
                  color: isComic ? C.comicText : C.accent,
                  fontFamily: isComic ? 'Bangers' : 'Orbitron',
                  fontSize: isComic ? 16 : 12,
                  fontWeight: FontWeight.w900,
                  letterSpacing: isComic ? 2 : 3,
                  shadows: isComic
                      ? [
                          Shadow(
                            color: C.comicTextOutline,
                            offset: const Offset(1, 1),
                            blurRadius: 0,
                          ),
                        ]
                      : null,
                ),
              ),
            ),
            const SizedBox(height: 14),

            SizedBox(
              height: 240,
              child: PageView.builder(
                controller: _carouselCtrl,
                itemCount: _cards.length,
                onPageChanged: (i) =>
                    setState(() => _carouselIndex = i),
                itemBuilder: (context, i) {
                  final card = _cards[i];
                  return Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 8),
                    child: _buildComicCard(C, isComic, card),
                  );
                },
              ),
            ),

            // Dots indicator
            const SizedBox(height: 14),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: List.generate(_cards.length, (i) {
                final active = i == _carouselIndex;
                return AnimatedContainer(
                  duration: const Duration(milliseconds: 250),
                  margin: const EdgeInsets.symmetric(horizontal: 4),
                  width: active ? 24 : 8,
                  height: 8,
                  decoration: BoxDecoration(
                    color: active
                        ? (isComic ? C.primaryHi : C.accent)
                        : (isComic
                            ? C.bgDark
                            : C.textSub.withOpacity(0.3)),
                    borderRadius: BorderRadius.circular(4),
                    border: isComic
                        ? Border.all(color: Colors.black, width: 2)
                        : null,
                  ),
                );
              }),
            ),

            const SizedBox(height: 40),

            // ── Login button ──
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20),
              child: _buildLoginButton(C, isComic),
            ),

            const SizedBox(height: 30),
          ],
        ),
      ),
    );
  }

  Widget _buildWelcome(AppPalette C, bool isComic) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20),
      child: Column(
        children: [
          Text(
            'WELCOME TO',
            textAlign: TextAlign.center,
            style: TextStyle(
              color: isComic ? C.comicTextSub : C.textSub,
              fontFamily: isComic ? 'ComicNeue' : 'ShareTechMono',
              fontSize: isComic ? 16 : 12,
              fontWeight: FontWeight.w700,
              letterSpacing: isComic ? 4 : 6,
            ),
          ),
          const SizedBox(height: 6),
          Text(
            'CONFLICT',
            textAlign: TextAlign.center,
            style: TextStyle(
              color: isComic ? C.comicText : C.text,
              fontFamily: isComic ? 'Bangers' : 'Orbitron',
              fontSize: isComic ? 42 : 32,
              fontWeight: FontWeight.w900,
              letterSpacing: isComic ? 4 : 8,
              height: 1,
              shadows: isComic
                  ? [
                      Shadow(
                        color: C.comicTextOutline,
                        offset: const Offset(3, 3),
                        blurRadius: 0,
                      ),
                    ]
                  : [
                      Shadow(
                        color: C.accent.withOpacity(0.8),
                        blurRadius: 20,
                      ),
                    ],
            ),
          ),
          const SizedBox(height: 12),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Container(
                width: 30,
                height: 2,
                color: isComic ? C.comicText : C.accent,
              ),
              const SizedBox(width: 12),
              Text(
                'WHATSAPP CRASHER & TOOLS',
                style: TextStyle(
                  color: isComic ? C.comicTextSub : C.textSub,
                  fontFamily: isComic ? 'ComicNeue' : 'ShareTechMono',
                  fontSize: isComic ? 11 : 9,
                  fontWeight: FontWeight.w700,
                  letterSpacing: 3,
                ),
              ),
              const SizedBox(width: 12),
              Container(
                width: 30,
                height: 2,
                color: isComic ? C.comicText : C.accent,
              ),
            ],
          ),
        ],
      ),
    );
  }

  // ── Info cards data (3 cards swipeable) ──
  final List<Map<String, dynamic>> _infoCards = [
    {
      'icon': Icons.workspace_premium_rounded,
      'title': 'KENAPA PILIH CONFLICT?',
      'body':
          'CONFLICT adalah aplikasi WhatsApp crasher & tools yang stabil, cepat, dan update rutin. Dibuat dengan fokus ke performa dan keamanan user, semua fitur bisa diakses dengan mudah tanpa ribet.',
      'color': Color(0xFF2196F3), // biru
    },
    {
      'icon': Icons.system_update_alt_rounded,
      'title': 'SEBERAPA SERING UPDATE?',
      'body':
          'Kami update aplikasi ini secara berkala — minimal 2 kali seminggu, dan update bug fix darurat kapanpun dibutuhkan. Semua update otomatis tersedia tanpa perlu install ulang.',
      'color': Color(0xFF9C27B0), // ungu
    },
    {
      'icon': Icons.groups_rounded,
      'title': 'JOIN COMMUNITY',
      'body':
          'Gabung grup Telegram kami untuk update, support, dan info terbaru.\n\n@testi4vell',
      'color': Color(0xFF9C27B0), // ungu
    },
  ];

  Widget _buildInfoCard(
    AppPalette C,
    bool isComic, {
    required IconData icon,
    required String title,
    required String body,
    required Color color,
  }) {
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: isComic ? C.bgDark : Colors.black.withOpacity(0.4),
        borderRadius: BorderRadius.circular(isComic ? 20 : 16),
        border: Border.all(
          color: isComic ? Colors.black : color.withOpacity(0.4),
          width: isComic ? 4 : 1.5,
        ),
        boxShadow: isComic
            ? const [
                BoxShadow(
                  color: Colors.black,
                  offset: Offset(6, 6),
                  blurRadius: 0,
                ),
              ]
            : [
                BoxShadow(
                  color: color.withOpacity(0.15),
                  blurRadius: 20,
                ),
              ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Header icon + title
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: isComic ? color : color.withOpacity(0.2),
                  border: Border.all(
                    color: isComic ? Colors.black : color,
                    width: isComic ? 3 : 1.2,
                  ),
                ),
                child: Icon(
                  icon,
                  color: isComic
                      ? C.contrastTextOn(color)
                      : color,
                  size: 20,
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Text(
                  title,
                  style: TextStyle(
                    color: isComic ? C.comicText : color,
                    fontFamily: isComic ? 'Bangers' : 'Orbitron',
                    fontSize: isComic ? 14 : 11,
                    fontWeight: FontWeight.w900,
                    letterSpacing: isComic ? 1.2 : 1.5,
                    height: 1.3,
                    shadows: isComic
                        ? [
                            Shadow(
                              color: C.comicTextOutline,
                              offset: const Offset(1, 1),
                              blurRadius: 0,
                            ),
                          ]
                        : null,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 14),
          // Body text
          Expanded(
            child: SingleChildScrollView(
              physics: const BouncingScrollPhysics(),
              child: Text(
                body,
                style: TextStyle(
                  color: isComic
                      ? C.comicTextSub
                      : C.text.withOpacity(0.8),
                  fontFamily:
                      isComic ? 'ComicNeue' : 'ShareTechMono',
                  fontSize: isComic ? 13 : 11,
                  height: 1.6,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ── 4 Cards (CRYLIX Cards) ──
  final List<Map<String, dynamic>> _cards = [
    {
      'title': 'SELAMAT DATANG',
      'subtitle': 'Di CONFLICT',
      'body':
          'Terima kasih sudah menggunakan aplikasi ini, Nikmati fitur fitur keren nya',
      'icon': Icons.celebration_rounded,
      'emoji': '🎉',
    },
    {
      'title': 'PESAN PENTING',
      'subtitle': '"Jangan terlalu meninggi,\nnanti jatuhnya sakit"',
      'body': 'Tetap rendah hati, tetap santuy, tetap asik.',
      'icon': Icons.psychology_alt_rounded,
      'emoji': '💭',
    },
    {
      'title': 'DEVELOPER',
      'subtitle': '@MarvelNovaX',
      'body': 'Dibuat dengan senang hati dan dedikasi tinggi oleh 4vell',
      'icon': Icons.code_rounded,
      'emoji': '👀',
    },
    {
      'title': 'CONFLICT',
      'subtitle': 'By 4vell',
      'body':
          'Aplikasi WhatsApp Crasher & Tools paling stabil dan update rutin.',
      'icon': Icons.workspace_premium_rounded,
      'emoji': '👑',
    },
  ];

  Widget _buildComicCard(
      AppPalette C, bool isComic, Map<String, dynamic> card) {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: isComic ? C.bgDark : Colors.black.withOpacity(0.5),
        borderRadius: BorderRadius.circular(isComic ? 20 : 16),
        border: Border.all(
          color: isComic ? Colors.black : C.accent.withOpacity(0.4),
          width: isComic ? 5 : 1.5,
        ),
        boxShadow: isComic
            ? const [
                BoxShadow(
                  color: Colors.black,
                  offset: Offset(8, 8),
                  blurRadius: 0,
                ),
              ]
            : [
                BoxShadow(
                  color: C.accent.withOpacity(0.25),
                  blurRadius: 20,
                ),
              ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            card['emoji'] as String,
            style: const TextStyle(fontSize: 40),
          ),
          const SizedBox(height: 12),

          Text(
            card['title'] as String,
            style: TextStyle(
              color: isComic ? C.comicText : C.accent,
              fontFamily: isComic ? 'Bangers' : 'Orbitron',
              fontSize: isComic ? 18 : 13,
              fontWeight: FontWeight.w900,
              letterSpacing: isComic ? 1.5 : 2,
              shadows: isComic
                  ? [
                      Shadow(
                        color: C.comicTextOutline,
                        offset: const Offset(1, 1),
                        blurRadius: 0,
                      ),
                    ]
                  : null,
            ),
          ),
          const SizedBox(height: 4),

          Text(
            card['subtitle'] as String,
            style: TextStyle(
              color: isComic
                  ? C.comicTextSub
                  : C.text.withOpacity(0.85),
              fontFamily:
                  isComic ? 'ComicNeue' : 'ShareTechMono',
              fontSize: isComic ? 14 : 12,
              fontWeight: FontWeight.w700,
              height: 1.4,
            ),
          ),
          const Spacer(),

          Container(
            height: isComic ? 3 : 1,
            color: isComic ? Colors.black : C.accent.withOpacity(0.3),
          ),
          const SizedBox(height: 10),

          Text(
            card['body'] as String,
            style: TextStyle(
              color: isComic ? C.comicTextMuted : C.textSub,
              fontFamily:
                  isComic ? 'ComicNeue' : 'ShareTechMono',
              fontSize: isComic ? 12 : 10,
              height: 1.5,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildLoginButton(AppPalette C, bool isComic) {
    return GestureDetector(
      onTap: () {
        HapticFeedback.mediumImpact();
        Navigator.of(context).push(
          PageRouteBuilder(
            pageBuilder: (_, __, ___) => const LoginPage(),
            transitionDuration: const Duration(milliseconds: 400),
            transitionsBuilder: (_, anim, __, child) {
              return FadeTransition(
                opacity: anim,
                child: SlideTransition(
                  position: Tween<Offset>(
                    begin: const Offset(0, 0.08),
                    end: Offset.zero,
                  ).animate(CurvedAnimation(
                    parent: anim,
                    curve: Curves.easeOutCubic,
                  )),
                  child: child,
                ),
              );
            },
          ),
        );
      },
      child: Container(
        height: isComic ? 62 : 58,
        decoration: BoxDecoration(
          color: isComic ? C.primaryHi : null,
          gradient: isComic
              ? null
              : LinearGradient(
                  colors: [C.primaryHi, C.primary],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
          borderRadius: BorderRadius.circular(isComic ? 14 : 12),
          border: Border.all(
            color: isComic ? Colors.black : C.accent,
            width: isComic ? 4 : 1.5,
          ),
          boxShadow: isComic
              ? const [
                  BoxShadow(
                    color: Colors.black,
                    offset: Offset(6, 6),
                    blurRadius: 0,
                  ),
                ]
              : [
                  BoxShadow(
                    color: C.primaryHi.withOpacity(0.5),
                    blurRadius: 20,
                    offset: const Offset(0, 8),
                  ),
                ],
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              Icons.arrow_forward_rounded,
              color: isComic
                  ? C.contrastTextOn(C.primaryHi)
                  : Colors.white,
              size: 22,
            ),
            const SizedBox(width: 12),
            Text(
              'LOGIN KE CONFLICT',
              style: TextStyle(
                color: isComic
                    ? C.contrastTextOn(C.primaryHi)
                    : Colors.white,
                fontFamily: isComic ? 'Bangers' : 'Orbitron',
                fontSize: isComic ? 18 : 13,
                fontWeight: FontWeight.w900,
                letterSpacing: isComic ? 2 : 3,
                shadows: isComic
                    ? [
                        Shadow(
                          color: C.contrastTextOn(C.primaryHi) ==
                                  Colors.white
                              ? Colors.black
                              : Colors.white,
                          offset: const Offset(1, 1),
                          blurRadius: 0,
                        ),
                      ]
                    : null,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════
// HALFTONE PAINTER
// ═══════════════════════════════════════════════════════════
class _HalftonePainter extends CustomPainter {
  final Color color;
  _HalftonePainter({required this.color});

  @override
  void paint(Canvas canvas, Size size) {
    const spacing = 22.0;
    final paint = Paint()..color = color;
    for (double x = 0; x < size.width + spacing; x += spacing) {
      for (double y = 0; y < size.height + spacing; y += spacing) {
        canvas.drawCircle(Offset(x, y), 2.5, paint);
      }
    }
  }

  @override
  bool shouldRepaint(_HalftonePainter old) => old.color != color;
}