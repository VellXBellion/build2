// lib/vinyl_music_page.dart — SKEUOMORPHIC VINYL PLAYER (Support Style Switcher)
import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:audioplayers/audioplayers.dart';
import 'app_theme.dart';

// ═══════════════════════════════════════════════════════════
// TRACK MODEL
// ═══════════════════════════════════════════════════════════
class VinylTrack {
  final String title;
  final String artist;
  final String assetPath;
  final String coverAsset;

  const VinylTrack({
    required this.title,
    required this.artist,
    required this.assetPath,
    required this.coverAsset,
  });
}

final List<VinylTrack> kVinylPlaylist = [
  const VinylTrack(
    title: 'BREAKBEAT DREAM',
    artist: 'VELL x MANTA',
    assetPath: 'audio/breakbeat.mp3',
    coverAsset: 'images/logo.png',
  ),
  const VinylTrack(
    title: 'MIDNIGHT RUN',
    artist: 'VELL',
    assetPath: 'audio/midnight.mp3',
    coverAsset: 'images/logo.png',
  ),
  const VinylTrack(
    title: 'CYBER PULSE',
    artist: 'MANTA',
    assetPath: 'audio/cyber.mp3',
    coverAsset: 'images/logo.png',
  ),
];

// ═══════════════════════════════════════════════════════════
// GLOBAL PULSE
// ═══════════════════════════════════════════════════════════
class _Pulse {
  static final ValueNotifier<double> v = ValueNotifier<double>(0);
  static bool _started = false;
  static void ensureStarted() {
    if (_started) return;
    _started = true;
    _run();
  }
  static Future<void> _run() async {
    final sw = Stopwatch()..start();
    while (true) {
      await Future<void>.delayed(const Duration(milliseconds: 80));
      final t = (sw.elapsedMilliseconds % 1600) / 1600.0;
      v.value = t < 0.5 ? t * 2 : (1 - t) * 2;
    }
  }
}

class _Led extends StatelessWidget {
  final Color color;
  final double size;
  final bool blink;
  const _Led({required this.color, this.size = 8, this.blink = false});

  @override
  Widget build(BuildContext context) {
    final isComic = AppTheme.currentStyle.value == ThemeStyle.comic3d;
    if (isComic) {
      return Container(
        width: size, height: size,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          color: color,
          border: Border.all(color: Colors.black, width: size * 0.18)),
      );
    }
    if (!blink) return _dot(1.0);
    return ValueListenableBuilder<double>(
      valueListenable: _Pulse.v,
      builder: (_, v, __) => _dot(0.45 + v * 0.55));
  }

  Widget _dot(double opacity) => Container(
        width: size, height: size,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          gradient: RadialGradient(
            center: const Alignment(-0.35, -0.35),
            colors: [
              Colors.white.withOpacity(0.85 * opacity),
              color.withOpacity(opacity),
              color.withOpacity(0.55 * opacity),
            ],
            stops: const [0.0, 0.4, 1.0]),
          border: Border.all(
              color: Colors.black.withOpacity(0.85),
              width: size * 0.1),
          boxShadow: [
            BoxShadow(color: color.withOpacity(0.75 * opacity),
                blurRadius: size * 1.4, spreadRadius: size * 0.2),
            BoxShadow(color: color.withOpacity(0.35 * opacity),
                blurRadius: size * 2.6, spreadRadius: size * 0.4),
          ]),
      );
}

class _Screw extends StatelessWidget {
  final AppPalette C;
  final double size;
  const _Screw({required this.C, this.size = 14});
  @override
  Widget build(BuildContext context) {
    if (AppTheme.currentStyle.value == ThemeStyle.comic3d) {
      return const SizedBox.shrink();
    }
    return Container(
      width: size, height: size,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        gradient: RadialGradient(
          center: const Alignment(-0.35, -0.35),
          colors: [C.text, C.textSub, C.bg, C.bgDark],
          stops: const [0.0, 0.35, 0.7, 1.0]),
        boxShadow: [
          BoxShadow(color: Colors.black.withOpacity(0.9),
              offset: const Offset(0.8, 1.5), blurRadius: 2.5),
        ]),
      child: Center(
        child: Transform.rotate(
          angle: 0.785,
          child: Container(
            width: size * 0.7, height: size * 0.11,
            color: Colors.black.withOpacity(0.9)),
        ),
      ),
    );
  }
}

class _Rivet extends StatelessWidget {
  final AppPalette C;
  final double size;
  const _Rivet({required this.C, this.size = 10});
  @override
  Widget build(BuildContext context) {
    if (AppTheme.currentStyle.value == ThemeStyle.comic3d) {
      return const SizedBox.shrink();
    }
    return Container(
      width: size, height: size,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        gradient: RadialGradient(
          center: const Alignment(-0.35, -0.35),
          colors: [C.accentShine, C.accentHi, C.accent, C.primaryLo],
          stops: const [0.0, 0.3, 0.65, 1.0]),
        boxShadow: [
          BoxShadow(color: Colors.black.withOpacity(0.9),
              offset: const Offset(0.5, 1), blurRadius: 1.5),
        ]),
    );
  }
}

class _MetalPlate extends StatelessWidget {
  final AppPalette C;
  final Widget child;
  final EdgeInsets padding;
  final bool brass;
  final double radius;
  const _MetalPlate({
    required this.C,
    required this.child,
    this.padding = const EdgeInsets.all(16),
    this.brass = false,
    this.radius = 16,
  });

  @override
  Widget build(BuildContext context) {
    final isComic = AppTheme.currentStyle.value == ThemeStyle.comic3d;
    if (isComic) {
      return Container(
        padding: padding,
        decoration: BoxDecoration(
          color: brass ? C.primaryHi : C.bgDark,
          borderRadius: BorderRadius.circular(radius + 4),
          border: Border.all(color: Colors.black, width: 4),
          boxShadow: const [
            BoxShadow(color: Colors.black, offset: Offset(6, 6),
                blurRadius: 0),
          ]),
        child: child,
      );
    }
    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(radius),
        gradient: LinearGradient(
          begin: Alignment.topLeft, end: Alignment.bottomRight,
          colors: brass
              ? [C.accentHi, C.accent, C.primary, C.primaryLo]
              : [C.text, C.bg, C.bgDark, C.bgDeep],
          stops: const [0.0, 0.4, 0.7, 1.0]),
        boxShadow: [
          BoxShadow(color: Colors.black.withOpacity(0.75),
              offset: const Offset(0, 6), blurRadius: 12),
          const BoxShadow(color: Colors.white12,
              offset: Offset(-1, -1), blurRadius: 3),
        ],
      ),
      padding: const EdgeInsets.all(3),
      child: Container(
        padding: padding,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(radius - 3),
          gradient: LinearGradient(
            begin: Alignment.topCenter, end: Alignment.bottomCenter,
            colors: [C.bg, C.bgDark, C.bgDeep]),
          border: Border.all(color: Colors.black.withOpacity(0.5)),
        ),
        child: child,
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════
// VINYL MUSIC PAGE
// ═══════════════════════════════════════════════════════════
class VinylMusicPage extends StatefulWidget {
  const VinylMusicPage({super.key});

  @override
  State<VinylMusicPage> createState() => _VinylMusicPageState();
}

class _VinylMusicPageState extends State<VinylMusicPage>
    with TickerProviderStateMixin {
  final AudioPlayer _player = AudioPlayer();

  late AnimationController _spinCtrl;
  late AnimationController _tonearmCtrl;
  late AnimationController _waveCtrl;
  late AnimationController _glowCtrl;

  int _currentIndex = 0;
  bool _isPlaying = false;
  bool _isLoading = false;
  Duration _position = Duration.zero;
  Duration _duration = Duration.zero;

  VinylTrack get _currentTrack => kVinylPlaylist[_currentIndex];

  @override
  void initState() {
    super.initState();
    _Pulse.ensureStarted();

    _spinCtrl = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 3));
    _tonearmCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 800));
    _waveCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 600))..repeat();
    _glowCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 2000))..repeat(reverse: true);

    _player.onPositionChanged.listen((p) {
      if (mounted) setState(() => _position = p);
    });
    _player.onDurationChanged.listen((d) {
      if (mounted) setState(() => _duration = d);
    });
    _player.onPlayerComplete.listen((_) {
      if (mounted) _nextTrack();
    });
    _player.onPlayerStateChanged.listen((state) {
      if (mounted) {
        final playing = state == PlayerState.playing;
        if (playing != _isPlaying) {
          setState(() => _isPlaying = playing);
          if (playing) {
            _spinCtrl.repeat();
            _tonearmCtrl.forward();
          } else {
            _spinCtrl.stop();
            _tonearmCtrl.reverse();
          }
        }
      }
    });
  }

  @override
  void dispose() {
    _player.dispose();
    _spinCtrl.dispose();
    _tonearmCtrl.dispose();
    _waveCtrl.dispose();
    _glowCtrl.dispose();
    super.dispose();
  }

  Future<void> _playTrack(int index) async {
    if (index < 0 || index >= kVinylPlaylist.length) return;

    setState(() {
      _currentIndex = index;
      _isLoading = true;
      _position = Duration.zero;
      _duration = Duration.zero;
    });

    try {
      await _player.stop();
      await _player.play(AssetSource(_currentTrack.assetPath));
      HapticFeedback.mediumImpact();
    } catch (e) {
      _showSnack('Gagal memutar: ${_currentTrack.title}');
      setState(() => _isLoading = false);
    }
  }

  Future<void> _togglePlayPause() async {
    HapticFeedback.selectionClick();
    if (_isPlaying) {
      await _player.pause();
    } else {
      if (_player.state == PlayerState.paused) {
        await _player.resume();
      } else {
        await _playTrack(_currentIndex);
      }
    }
  }

  Future<void> _nextTrack() async {
    final next = (_currentIndex + 1) % kVinylPlaylist.length;
    await _playTrack(next);
  }

  Future<void> _prevTrack() async {
    final prev = (_currentIndex - 1 + kVinylPlaylist.length) %
        kVinylPlaylist.length;
    await _playTrack(prev);
  }

  Future<void> _seekTo(double value) async {
    final ms = (value * _duration.inMilliseconds).round();
    await _player.seek(Duration(milliseconds: ms));
  }

  void _showSnack(String msg) {
    final C = AppTheme.current.value;
    final isComic = AppTheme.currentStyle.value == ThemeStyle.comic3d;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Row(
          children: [
            _Led(color: C.primaryHi, size: 8, blink: !isComic),
            const SizedBox(width: 10),
            Expanded(
              child: Text(msg,
                  style: TextStyle(
                    color: C.text,
                    fontWeight: FontWeight.w700,
                    fontSize: isComic ? 13 : 12,
                    fontFamily:
                        isComic ? 'ComicNeue' : 'ShareTechMono')),
            ),
          ],
        ),
        backgroundColor: C.bgDark,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(isComic ? 12 : 8),
          side: BorderSide(
              color: C.primaryHi, width: isComic ? 3 : 1.5)),
        margin: const EdgeInsets.all(16),
      ),
    );
  }

  String _fmt(Duration d) {
    final m = d.inMinutes;
    final s = d.inSeconds % 60;
    return '$m:${s.toString().padLeft(2, '0')}';
  }

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<AppPalette>(
      valueListenable: AppTheme.current,
      builder: (context, C, _) {
        return ValueListenableBuilder<ThemeStyle>(
          valueListenable: AppTheme.currentStyle,
          builder: (context, style, __) {
            final isComic = style == ThemeStyle.comic3d;

            return Scaffold(
              backgroundColor: C.bgDeep,
              body: Container(
                decoration: isComic
                    ? BoxDecoration(color: C.bg)
                    : BoxDecoration(
                        gradient: RadialGradient(
                          center: const Alignment(-0.3, -0.3),
                          radius: 1.2,
                          colors: [C.bg, C.bgDark, C.bgDeep],
                          stops: const [0.0, 0.6, 1.0])),
                child: Stack(
                  children: [
                    if (isComic)
                      Positioned.fill(
                        child: IgnorePointer(
                          child: CustomPaint(
                            painter: _ComicHalftonePainter(
                                color: C.primaryLo.withOpacity(0.12))))),
                    SafeArea(
                      child: Column(
                        children: [
                          const SizedBox(height: 8),
                          _buildTopBar(C, isComic),
                          const SizedBox(height: 16),
                          Expanded(
                            child: Center(
                              child: SingleChildScrollView(
                                physics: const BouncingScrollPhysics(),
                                child: Column(
                                  mainAxisSize: MainAxisSize.min,
                                  children: [
                                    _buildVinylPlayer(C, isComic),
                                    const SizedBox(height: 20),
                                    _buildTrackInfo(C, isComic),
                                    const SizedBox(height: 14),
                                    _buildVisualizer(C, isComic),
                                    const SizedBox(height: 14),
                                    _buildProgressBar(C, isComic),
                                    const SizedBox(height: 18),
                                    _buildControls(C, isComic),
                                  ],
                                ),
                              ),
                            ),
                          ),
                          const SizedBox(height: 8),
                          _buildPlaylistStrip(C, isComic),
                          const SizedBox(height: 12),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            );
          },
        );
      },
    );
  }

  Widget _buildTopBar(AppPalette C, bool isComic) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 14),
      child: _MetalPlate(
        C: C,
        padding: const EdgeInsets.all(12),
        child: Row(
          children: [
            GestureDetector(
              onTap: () => Navigator.pop(context),
              child: Container(
                width: 36, height: 36,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(8),
                  gradient: isComic ? null
                      : LinearGradient(
                          begin: Alignment.topLeft,
                          end: Alignment.bottomRight,
                          colors: [C.text, C.bg, C.bgDark]),
                  color: isComic ? C.accent : null,
                  border: Border.all(
                      color: isComic ? Colors.black : C.primaryLo,
                      width: isComic ? 3 : 1.5)),
                child: Icon(Icons.arrow_back_ios_new_rounded,
                    color: isComic ? Colors.white : C.accent, size: 16),
              ),
            ),
            const SizedBox(width: 12),
            Container(
              width: 36, height: 36,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: isComic ? null
                    : RadialGradient(
                        center: const Alignment(-0.3, -0.3),
                        colors: [C.accentHi, C.accent, C.primaryLo]),
                color: isComic ? C.primaryHi : null,
                border: Border.all(
                    color: isComic ? Colors.black : C.accentShine,
                    width: isComic ? 3 : 1.5)),
              child: Icon(Icons.album_rounded,
                  color: isComic ? Colors.white : C.bgDeep, size: 18),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('VINYL PLAYER',
                      style: TextStyle(
                        color: isComic ? Colors.black : C.accent,
                        fontFamily: isComic ? 'Bangers' : 'Orbitron',
                        fontWeight: FontWeight.w900,
                        fontSize: isComic ? 18 : 13,
                        letterSpacing: isComic ? 1.5 : 2.5)),
                  const SizedBox(height: 2),
                  Row(
                    children: [
                      _Led(
                          color: _isPlaying ? C.primaryHi : C.textSub,
                          size: 4,
                          blink: _isPlaying && !isComic),
                      const SizedBox(width: 6),
                      Text(
                          _isPlaying
                              ? 'NOW PLAYING'
                              : 'PAUSED · READY',
                          style: TextStyle(
                            color: isComic
                                ? Colors.black.withOpacity(0.5)
                                : C.text.withOpacity(0.55),
                            fontFamily: isComic
                                ? 'ComicNeue'
                                : 'ShareTechMono',
                            fontWeight: FontWeight.w700,
                            fontSize: 8,
                            letterSpacing: 1.2)),
                    ],
                  ),
                ],
              ),
            ),
            if (!isComic) _Screw(C: C, size: 12),
          ],
        ),
      ),
    );
  }

  Widget _buildVinylPlayer(AppPalette C, bool isComic) {
    return AnimatedBuilder(
      animation: Listenable.merge([_spinCtrl, _tonearmCtrl, _glowCtrl]),
      builder: (_, __) {
        return _MetalPlate(
          C: C,
          padding: const EdgeInsets.all(14),
          child: SizedBox(
            width: 300, height: 300,
            child: Stack(
              alignment: Alignment.center,
              children: [
                if (!isComic)
                  Container(
                    width: 260, height: 260,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      boxShadow: [
                        BoxShadow(
                          color: (_isPlaying ? C.accent : C.primaryHi)
                              .withOpacity(0.15 + _glowCtrl.value * 0.2),
                          blurRadius: 60,
                          spreadRadius: 8),
                      ]),
                  ),
                Transform.rotate(
                  angle: _spinCtrl.value * 2 * math.pi,
                  child: _buildVinylDisc(C, isComic)),
                Container(
                  width: 90, height: 90,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    gradient: isComic ? null
                        : RadialGradient(colors: [C.bgDark, C.bgDeep]),
                    color: isComic ? Colors.white : null,
                    border: Border.all(
                        color: isComic ? Colors.black : C.accent.withOpacity(0.6),
                        width: isComic ? 4 : 2)),
                  child: ClipOval(
                    child: Padding(
                      padding: const EdgeInsets.all(4),
                      child: ClipOval(
                        child: Image.asset(
                          _currentTrack.coverAsset,
                          fit: BoxFit.cover,
                          errorBuilder: (_, __, ___) => Center(
                            child: Icon(Icons.music_note_rounded,
                                color: isComic ? Colors.black : C.accent,
                                size: 40)),
                        ),
                      ),
                    ),
                  ),
                ),
                Container(
                  width: 10, height: 10,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    gradient: isComic ? null
                        : RadialGradient(
                            colors: [C.text, C.textSub, C.bgDark]),
                    color: isComic ? C.bgDeep : null,
                    border: isComic
                        ? Border.all(color: Colors.black, width: 2)
                        : null),
                ),
                Positioned(
                  top: 20, right: 20,
                  child: _buildTonearm(C, isComic)),
                Positioned(
                  bottom: 8, left: 12,
                  child: Row(
                    children: [
                      _Led(
                          color: _isPlaying ? C.primaryHi : C.textSub,
                          size: 5,
                          blink: _isPlaying && !isComic),
                      const SizedBox(width: 6),
                      Text('33½ RPM · SYNC',
                          style: TextStyle(
                            color: isComic
                                ? Colors.black.withOpacity(0.6)
                                : (_isPlaying
                                    ? C.primaryHi
                                    : C.text.withOpacity(0.4)),
                            fontSize: isComic ? 10 : 8,
                            fontFamily: isComic
                                ? 'Bangers'
                                : 'ShareTechMono',
                            fontWeight: FontWeight.w900,
                            letterSpacing: 1.5)),
                    ],
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _buildVinylDisc(AppPalette C, bool isComic) {
    return Container(
      width: 250, height: 250,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        gradient: isComic ? null
            : RadialGradient(
                colors: const [
                  Color(0xFF0A0A0A),
                  Color(0xFF1A1A1A),
                  Color(0xFF000000),
                ],
                stops: const [0.0, 0.5, 1.0]),
        color: isComic ? Colors.black : null,
        border: isComic
            ? Border.all(color: Colors.black, width: 5)
            : null,
        boxShadow: isComic
            ? null
            : [
                BoxShadow(
                  color: Colors.black.withOpacity(0.9),
                  offset: const Offset(0, 8),
                  blurRadius: 20),
              ],
      ),
      child: CustomPaint(
        painter: _VinylGroovesPainter(
            color: isComic ? Colors.white : C.accent.withOpacity(0.08))),
    );
  }

  Widget _buildTonearm(AppPalette C, bool isComic) {
    final t = _tonearmCtrl.value;
    const startAngle = -0.5;
    const endAngle = 0.6;
    final angle = startAngle + (endAngle - startAngle) * t;

    return SizedBox(
      width: 130, height: 130,
      child: Stack(
        alignment: Alignment.topRight,
        children: [
          Container(
            width: 20, height: 20,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: isComic ? null
                  : RadialGradient(
                      colors: [C.text, C.textSub, C.bgDark]),
              color: isComic ? C.primaryHi : null,
              border: isComic
                  ? Border.all(color: Colors.black, width: 3)
                  : null,
              boxShadow: isComic
                  ? null
                  : [
                      BoxShadow(
                        color: Colors.black.withOpacity(0.9),
                        offset: const Offset(0, 2),
                        blurRadius: 4),
                    ]),
          ),
          Positioned(
            top: 10, right: 10,
            child: Transform.rotate(
              angle: angle,
              alignment: Alignment.topRight,
              child: SizedBox(
                width: 110, height: 6,
                child: Stack(
                  children: [
                    Container(
                      width: 100, height: 5,
                      margin: const EdgeInsets.only(right: 8),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(3),
                        gradient: isComic ? null
                            : const LinearGradient(
                                colors: [
                                  Color(0xFFE0E0E0),
                                  Color(0xFF9E9E9E),
                                  Color(0xFF616161),
                                ]),
                        color: isComic ? Colors.black : null),
                    ),
                    Positioned(
                      left: 0, top: -3,
                      child: Container(
                        width: 14, height: 11,
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(2),
                          gradient: isComic ? null
                              : LinearGradient(
                                  colors: [C.accent, C.primaryLo]),
                          color: isComic ? C.accent : null,
                          border: Border.all(
                              color: isComic
                                  ? Colors.black
                                  : C.accentShine,
                              width: isComic ? 2 : 1)),
                      ),
                    ),
                    Positioned(
                      left: 4, bottom: -6,
                      child: Container(
                        width: 3, height: 8,
                        decoration: BoxDecoration(
                          color: isComic ? Colors.white : C.accentShine,
                          borderRadius: BorderRadius.circular(2)),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildTrackInfo(AppPalette C, bool isComic) {
    return Column(
      children: [
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(isComic ? 10 : 20),
            color: isComic ? Colors.white : C.bgDeep,
            border: Border.all(
                color: isComic
                    ? Colors.black
                    : (_isPlaying ? C.primaryHi : C.textSub)
                        .withOpacity(0.5),
                width: isComic ? 3 : 1)),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              _Led(
                  color: _isPlaying ? C.primaryHi : C.textSub,
                  size: 5,
                  blink: _isPlaying && !isComic),
              const SizedBox(width: 8),
              Text(
                  _isLoading
                      ? 'LOADING...'
                      : _isPlaying
                          ? 'SEDANG DIPUTAR'
                          : 'PAUSED',
                  style: TextStyle(
                    color: isComic
                        ? Colors.black
                        : (_isPlaying ? C.primaryHi : C.textSub),
                    fontSize: isComic ? 12 : 9,
                    fontFamily: isComic ? 'Bangers' : 'Orbitron',
                    fontWeight: FontWeight.w900,
                    letterSpacing: 2)),
            ],
          ),
        ),
        const SizedBox(height: 10),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 20),
          child: Text(
            _currentTrack.title.toUpperCase(),
            textAlign: TextAlign.center,
            style: TextStyle(
              color: isComic ? Colors.black : C.text,
              fontSize: isComic ? 24 : 22,
              fontWeight: FontWeight.w900,
              fontFamily: isComic ? 'Bangers' : 'Orbitron',
              letterSpacing: isComic ? 2 : 2,
              shadows: isComic
                  ? const [
                      Shadow(color: Colors.black26,
                          offset: Offset(2, 2), blurRadius: 0),
                    ]
                  : [
                      Shadow(
                        color: C.accent.withOpacity(0.5),
                        blurRadius: 10),
                      const Shadow(
                        color: Colors.black,
                        offset: Offset(0, 2),
                        blurRadius: 4),
                    ]),
            maxLines: 1,
            overflow: TextOverflow.ellipsis),
        ),
        const SizedBox(height: 4),
        Text(
          _currentTrack.artist,
          style: TextStyle(
            color: isComic
                ? Colors.black.withOpacity(0.6)
                : C.text.withOpacity(0.55),
            fontSize: isComic ? 12 : 11,
            fontFamily: isComic ? 'ComicNeue' : 'ShareTechMono',
            fontWeight: FontWeight.w700,
            letterSpacing: 1)),
      ],
    );
  }

  Widget _buildVisualizer(AppPalette C, bool isComic) {
    return _MetalPlate(
      C: C,
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
      child: SizedBox(
        height: 40,
        child: AnimatedBuilder(
          animation: _waveCtrl,
          builder: (_, __) => CustomPaint(
            size: const Size(double.infinity, 40),
            painter: _WaveVisualizerPainter(
              progress: _waveCtrl.value,
              isPlaying: _isPlaying,
              colorStart: isComic ? C.primaryHi : C.primaryHi,
              colorMid: isComic ? C.accent : C.accent,
              colorEnd: isComic ? C.accentShine : C.accentShine,
            )),
        ),
      ),
    );
  }

  Widget _buildProgressBar(AppPalette C, bool isComic) {
    final total =
        _duration.inMilliseconds == 0 ? 1 : _duration.inMilliseconds;
    final progress = (_position.inMilliseconds / total).clamp(0.0, 1.0);

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 24),
      child: Column(
        children: [
          SliderTheme(
            data: SliderTheme.of(context).copyWith(
              trackHeight: isComic ? 6 : 4,
              activeTrackColor:
                  isComic ? C.primaryHi : C.accent,
              inactiveTrackColor:
                  isComic ? Colors.white : C.bgDeep,
              thumbColor: isComic ? Colors.black : C.accentShine,
              overlayColor:
                  (isComic ? C.primaryHi : C.accent).withOpacity(0.2),
              thumbShape: RoundSliderThumbShape(
                  enabledThumbRadius: isComic ? 9 : 6),
              overlayShape:
                  const RoundSliderOverlayShape(overlayRadius: 14)),
            child: Slider(value: progress, onChanged: (v) => _seekTo(v)),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 8),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(_fmt(_position),
                    style: TextStyle(
                      color: isComic ? Colors.black : C.accent,
                      fontSize: isComic ? 13 : 10,
                      fontFamily:
                          isComic ? 'Bangers' : 'ShareTechMono',
                      fontWeight: FontWeight.w900,
                      letterSpacing: 1)),
                Text(_fmt(_duration),
                    style: TextStyle(
                      color: isComic
                          ? Colors.black.withOpacity(0.6)
                          : C.text.withOpacity(0.5),
                      fontSize: isComic ? 13 : 10,
                      fontFamily:
                          isComic ? 'Bangers' : 'ShareTechMono',
                      fontWeight: FontWeight.w900,
                      letterSpacing: 1)),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildControls(AppPalette C, bool isComic) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        _buildCircleButton(C, isComic,
            icon: Icons.skip_previous_rounded,
            size: 52, iconSize: 26, onTap: _prevTrack),
        const SizedBox(width: 18),
        _buildCircleButton(C, isComic,
            icon: _isPlaying
                ? Icons.pause_rounded
                : Icons.play_arrow_rounded,
            size: 72, iconSize: 38,
            onTap: _togglePlayPause, primary: true),
        const SizedBox(width: 18),
        _buildCircleButton(C, isComic,
            icon: Icons.skip_next_rounded,
            size: 52, iconSize: 26, onTap: _nextTrack),
      ],
    );
  }

  Widget _buildCircleButton(AppPalette C, bool isComic, {
    required IconData icon,
    required double size,
    required double iconSize,
    required VoidCallback onTap,
    bool primary = false,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: size, height: size,
        decoration: BoxDecoration(
          shape: isComic ? BoxShape.rectangle : BoxShape.circle,
          borderRadius:
              isComic ? BorderRadius.circular(size * 0.25) : null,
          gradient: isComic
              ? null
              : LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: primary
                      ? [C.accentHi, C.accent, C.primaryLo]
                      : [C.bg, C.bgDark, C.bgDeep]),
          color: isComic
              ? (primary ? C.primaryHi : C.bgDark)
              : null,
          border: Border.all(
              color: isComic
                  ? Colors.black
                  : (primary
                      ? C.accentShine
                      : C.accent.withOpacity(0.5)),
              width: isComic ? 4 : (primary ? 2 : 1.5)),
          boxShadow: isComic
              ? const [
                  BoxShadow(color: Colors.black,
                      offset: Offset(5, 5), blurRadius: 0),
                ]
              : [
                  BoxShadow(
                    color: primary
                        ? C.accent.withOpacity(0.5)
                        : Colors.black.withOpacity(0.6),
                    blurRadius: primary ? 20 : 10,
                    offset: const Offset(0, 4)),
                  const BoxShadow(
                    color: Colors.white12,
                    offset: Offset(-1, -1),
                    blurRadius: 3),
                ],
        ),
        child: Icon(
          icon,
          color: isComic
              ? Colors.white
              : (primary ? C.bgDeep : C.accent),
          size: iconSize,
          shadows: primary && !isComic
              ? const [
                  Shadow(
                    color: Colors.black54,
                    offset: Offset(0, 1),
                    blurRadius: 2),
                ]
              : null),
      ),
    );
  }

  Widget _buildPlaylistStrip(AppPalette C, bool isComic) {
    return _MetalPlate(
      C: C,
      radius: 14,
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: SizedBox(
        height: 72,
        child: ListView.separated(
          scrollDirection: Axis.horizontal,
          physics: const BouncingScrollPhysics(),
          padding: const EdgeInsets.symmetric(horizontal: 10),
          itemCount: kVinylPlaylist.length,
          separatorBuilder: (_, __) => const SizedBox(width: 8),
          itemBuilder: (_, i) {
            final track = kVinylPlaylist[i];
            final isActive = i == _currentIndex;
            return GestureDetector(
              onTap: () => _playTrack(i),
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 200),
                width: 160,
                padding: const EdgeInsets.symmetric(
                    horizontal: 10, vertical: 6),
                decoration: BoxDecoration(
                  borderRadius:
                      BorderRadius.circular(isComic ? 10 : 8),
                  gradient: isComic
                      ? null
                      : LinearGradient(
                          begin: Alignment.topLeft,
                          end: Alignment.bottomRight,
                          colors: isActive
                              ? [C.accentHi, C.accent, C.primaryLo]
                              : [C.bg, C.bgDark, C.bgDeep]),
                  color: isComic
                      ? (isActive ? C.primaryHi : C.bgDark)
                      : null,
                  border: Border.all(
                      color: isComic
                          ? Colors.black
                          : (isActive
                              ? C.accentShine
                              : C.textSub.withOpacity(0.3)),
                      width: isComic ? 3.5 : (isActive ? 1.5 : 1)),
                  boxShadow: isComic
                      ? const [
                          BoxShadow(color: Colors.black,
                              offset: Offset(3, 3), blurRadius: 0),
                        ]
                      : [
                          BoxShadow(
                            color: isActive
                                ? C.accent.withOpacity(0.5)
                                : Colors.black.withOpacity(0.5),
                            blurRadius: isActive ? 10 : 4,
                            offset: const Offset(0, 3)),
                        ]),
                child: Row(
                  children: [
                    ClipRRect(
                      borderRadius:
                          BorderRadius.circular(isComic ? 6 : 6),
                      child: Image.asset(
                        track.coverAsset,
                        width: 40, height: 40, fit: BoxFit.cover,
                        errorBuilder: (_, __, ___) => Container(
                            width: 40, height: 40,
                            color: C.bgDeep,
                            child: Icon(Icons.music_note,
                                color: isComic
                                    ? Colors.white
                                    : C.accent,
                                size: 18))),
                    ),
                    const SizedBox(width: 8),
                    Expanded(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(track.title,
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: TextStyle(
                                color: isComic
                                    ? (isActive
                                        ? Colors.white
                                        : Colors.black)
                                    : (isActive ? C.bgDeep : C.text),
                                fontSize: isComic ? 12 : 10,
                                fontWeight: FontWeight.w900,
                                fontFamily: isComic
                                    ? 'Bangers'
                                    : 'Orbitron',
                                letterSpacing: 0.5)),
                          const SizedBox(height: 2),
                          Text(track.artist,
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: TextStyle(
                                color: isComic
                                    ? (isActive
                                        ? Colors.white
                                            .withOpacity(0.8)
                                        : Colors.black
                                            .withOpacity(0.6))
                                    : (isActive
                                        ? C.bgDeep.withOpacity(0.7)
                                        : C.text.withOpacity(0.5)),
                                fontSize: isComic ? 10 : 8,
                                fontWeight: FontWeight.w700,
                                fontFamily: isComic
                                    ? 'ComicNeue'
                                    : 'ShareTechMono')),
                        ],
                      ),
                    ),
                    if (isActive)
                      _Led(color: isComic ? Colors.white : C.bgDeep,
                          size: 6,
                          blink: _isPlaying && !isComic),
                  ],
                ),
              ),
            );
          },
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════
// VINYL GROOVES PAINTER
// ═══════════════════════════════════════════════════════════
class _VinylGroovesPainter extends CustomPainter {
  final Color color;
  _VinylGroovesPainter({required this.color});

  @override
  void paint(Canvas canvas, Size size) {
    final ctr = Offset(size.width / 2, size.height / 2);
    final maxR = size.width / 2;

    final groovePaint = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 0.8
      ..color = color;

    for (double r = 40; r < maxR - 8; r += 2.5) {
      canvas.drawCircle(ctr, r, groovePaint);
    }

    final shinePaint = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.5
      ..color = Colors.white.withOpacity(0.03);

    for (double r = 42; r < maxR - 10; r += 5) {
      canvas.drawCircle(ctr, r, shinePaint);
    }
  }

  @override
  bool shouldRepaint(_VinylGroovesPainter old) => old.color != color;
}

// ═══════════════════════════════════════════════════════════
// WAVE VISUALIZER PAINTER
// ═══════════════════════════════════════════════════════════
class _WaveVisualizerPainter extends CustomPainter {
  final double progress;
  final bool isPlaying;
  final Color colorStart;
  final Color colorMid;
  final Color colorEnd;

  _WaveVisualizerPainter({
    required this.progress,
    required this.isPlaying,
    required this.colorStart,
    required this.colorMid,
    required this.colorEnd,
  });

  @override
  void paint(Canvas canvas, Size size) {
    const barCount = 32;
    const gap = 2.0;
    final barWidth = (size.width - (barCount - 1) * gap) / barCount;
    final centerY = size.height / 2;

    for (int i = 0; i < barCount; i++) {
      final phase = (i / barCount) * math.pi * 2;
      final wave = math.sin(progress * math.pi * 2 + phase);
      final amp = isPlaying ? (0.3 + wave.abs() * 0.7) : 0.1;
      final barHeight = size.height * amp;

      final x = i * (barWidth + gap);
      final rect = Rect.fromLTWH(
          x, centerY - barHeight / 2, barWidth, barHeight);

      final t = i / barCount;
      final color = t < 0.5
          ? Color.lerp(colorStart, colorMid, t * 2)!
          : Color.lerp(colorMid, colorEnd, (t - 0.5) * 2)!;

      final paint = Paint()
        ..shader = LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [
            color.withOpacity(0.3),
            color,
            color.withOpacity(0.3),
          ]).createShader(rect);

      canvas.drawRRect(
        RRect.fromRectAndRadius(rect, const Radius.circular(2)),
        paint,
      );
    }
  }

  @override
  bool shouldRepaint(_WaveVisualizerPainter old) =>
      old.progress != progress || old.isPlaying != isPlaying;
}

// ═══════════════════════════════════════════════════════════
// COMIC HALFTONE PAINTER
// ═══════════════════════════════════════════════════════════
class _ComicHalftonePainter extends CustomPainter {
  final Color color;
  const _ComicHalftonePainter({required this.color});

  @override
  void paint(Canvas canvas, Size size) {
    const spacing = 22.0;
    final paint = Paint()..color = color;
    for (double x = 0; x < size.width + spacing; x += spacing) {
      for (double y = 0; y < size.height + spacing; y += spacing) {
        canvas.drawCircle(Offset(x, y), 2.5, paint);
      }
    }
  }

  @override
  bool shouldRepaint(_ComicHalftonePainter old) => old.color != color;
}